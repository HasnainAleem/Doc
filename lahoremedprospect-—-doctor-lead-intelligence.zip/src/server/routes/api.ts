import { Router, type Response } from 'express';
import { desc, eq, inArray } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '../../db/index.ts';
import {
  appSettings,
  auditLogs,
  automationJobs,
  clinics,
  doctors,
  leadActivities,
  websiteAudits,
} from '../../db/schema.ts';
import { requireAuth, type AuthRequest } from '../../middleware/auth.ts';
import { adminAuth } from '../../lib/firebase-admin.ts';
import {
  buildClinicNormalizedName,
  buildDoctorDedupeKey,
  normalizePakistanPhone,
  normalizeWebsiteUrl,
} from '../../lib/normalization.ts';
import { calculateLeadScore } from '../../lib/scoring.ts';
import { buildSampleDataset } from '../../lib/sampleData.ts';
import {
  DEFAULT_AUTOMATION_CONFIG,
  DEFAULT_SCORING_RULES,
  DOCTOR_STATUSES,
  LEAD_STATUSES,
  WEBSITE_CLASSIFICATIONS,
  type ScoringRulesConfig,
} from '../../types/domain.ts';
import { discoverViaGooglePlaces, discoverViaOverpass } from '../services/discovery.ts';
import { discoverViaOladoc, runLahoreOladocDirectorySync } from '../services/oladocScraper.ts';
import { runLiveWebsiteAudit } from '../services/websiteAnalyzer.ts';
import { runGeminiMultiTurnChat } from '../services/geminiChat.ts';

export const apiRouter = Router();

// Public client configuration endpoint (never exposes server secrets)
apiRouter.get('/public-config', (_req, res: Response) => {
  const mapsApiKey = process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || '';
  res.json({
    googleMapsConfigured: Boolean(mapsApiKey),
    googleMapsClientKey: mapsApiKey,
    firebaseConfigured: true,
    postgresConfigured: Boolean(process.env.SQL_HOST && process.env.SQL_DB_NAME),
  });
});

const aiChatSchema = z.object({
  roleId: z.enum(['outreach_strategist', 'website_analyst', 'crm_advisor']),
  message: z.string().trim().min(1).max(4000),
  history: z
    .array(
      z.object({
        role: z.enum(['user', 'model']),
        text: z.string().max(12000),
      })
    )
    .max(40)
    .default([]),
  doctorContext: z.string().max(4000).nullable().optional(),
  workspaceSummary: z.string().max(1000).nullable().optional(),
});

// Multi-turn Gemini chat proxy (keeps GEMINI_API_KEY strictly server-side; accessible in Sample & Auth modes)
apiRouter.post('/ai/chat', async (req, res: Response) => {
  const parsed = aiChatSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid chat request payload', details: parsed.error.flatten() });
  }

  try {
    const result = await runGeminiMultiTurnChat({
      roleId: parsed.data.roleId,
      message: parsed.data.message,
      history: parsed.data.history,
      doctorContext: parsed.data.doctorContext,
      workspaceSummary: parsed.data.workspaceSummary,
    });
    return res.json(result);
  } catch (error) {
    const rawMessage = error instanceof Error ? error.message : 'Gemini chat request failed.';
    console.error('Gemini chat endpoint error:', error);

    let cleanMessage = rawMessage;
    try {
      const parsedErr = JSON.parse(rawMessage);
      if (parsedErr?.error?.message) {
        cleanMessage = String(parsedErr.error.message);
      }
    } catch {
      // Raw message is already plain text
    }

    const lower = `${rawMessage} ${cleanMessage}`.toLowerCase();
    if (lower.includes('not configured') || lower.includes('api_key_invalid') || lower.includes('api key')) {
      return res.status(503).json({
        error: 'Gemini API key is unavailable or invalid. Please check the API key in the Settings > Secrets panel.',
      });
    }
    if (lower.includes('429') || lower.includes('quota') || lower.includes('resource_exhausted') || lower.includes('rate limit')) {
      return res.status(429).json({
        error: 'Gemini API rate limit or quota reached. Please wait a moment or check your billing/quota in Settings > Secrets.',
      });
    }
    if (lower.includes('504') || lower.includes('deadline_exceeded') || lower.includes('deadline expired') || lower.includes('timeout')) {
      return res.status(504).json({
        error: 'Gemini service timed out before completing the response (504 Deadline Exceeded). Please retry in a moment.',
      });
    }
    return res.status(502).json({ error: cleanMessage });
  }
});

// Public directory discovery endpoint (oladoc.com & OpenStreetMap Overpass) for both Sample & Authenticated modes
apiRouter.post('/discover/public', async (req, res: Response) => {
  const schema = z.object({
    provider: z.enum(['oladoc', 'osm_overpass']),
    area: z.string().min(2),
    speciality: z.string().min(2),
    query: z.string().optional(),
    maxPages: z.number().int().min(1).max(15).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid discovery search parameters' });
  }

  try {
    const result =
      parsed.data.provider === 'oladoc'
        ? await discoverViaOladoc(parsed.data)
        : await discoverViaOverpass(parsed.data);

    return res.json({
      ...result,
      prospects: result.prospects.map((p) => ({
        ...p,
        alreadyInDb: false,
      })),
    });
  } catch (error) {
    console.error('Public discovery error:', error);
    return res.status(500).json({ error: 'Discovery provider request failed.' });
  }
});

// Streaming full/paginated Lahore doctor directory sync from https://oladoc.com/
apiRouter.post('/oladoc/sync', async (req, res: Response) => {
  const schema = z.object({
    scope: z.enum(['quick', 'standard', 'full']).default('quick'),
    area: z.string().optional(),
    specialities: z.array(z.string()).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid oladoc sync parameters' });
  }

  let authedEmail: string | null = null;
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split('Bearer ')[1];
    try {
      const decoded = await adminAuth.verifyIdToken(token);
      authedEmail = decoded.email || decoded.uid;
    } catch {
      return res.status(401).json({ error: 'Invalid or expired authentication token' });
    }
  }

  res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const abortController = new AbortController();
  res.on('close', () => {
    if (!res.writableEnded) {
      abortController.abort();
    }
  });

  try {
    const scoringRules = authedEmail
      ? (await getScoringAndAutomationConfig()).scoringRules
      : DEFAULT_SCORING_RULES;

    let totalSaved = 0;
    let totalDuplicatesSkipped = 0;

    const summary = await runLahoreOladocDirectorySync({
      scope: parsed.data.scope,
      area: parsed.data.area,
      specialities: parsed.data.specialities,
      signal: abortController.signal,
      onBatch: async ({
        speciality,
        specIndex,
        specTotal,
        page,
        totalClaimedInSpec,
        batch,
      }) => {
        let batchSaved = 0;
        let batchDupes = 0;

        if (authedEmail) {
          for (const rec of batch) {
            try {
              const ins = await upsertClinicAndInsertDoctor(
                {
                  fullName: rec.fullName,
                  speciality: rec.speciality,
                  clinicName: rec.clinicName,
                  practiceType: rec.practiceType,
                  doctorStatus: rec.doctorStatus,
                  pmdcVerified: rec.pmdcVerified,
                  availability: rec.availability,
                  experienceYears: rec.experienceYears,
                  qualifications: rec.qualifications,
                  consultationFeePkr: rec.consultationFeePkr,
                  rating: rec.rating,
                  reviewCount: rec.reviewCount,
                  patientSatisfaction: rec.patientSatisfaction,
                  waitTime: rec.waitTime,
                  videoConsultation: rec.videoConsultation,
                  phone: rec.phone,
                  email: rec.email,
                  website: rec.website,
                  address: rec.address,
                  area: rec.area,
                  lat: rec.lat,
                  lng: rec.lng,
                  googleMapsUrl: rec.googleMapsUrl,
                  googlePlaceId: rec.googlePlaceId,
                  profileUrl: rec.profileUrl,
                  dataSource: rec.dataSource,
                  sourceUrl: rec.sourceUrl,
                  dataOrigin: 'verified',
                  leadStatus: 'New',
                  notes: rec.notes || null,
                },
                scoringRules
              );
              if (ins.status === 'created') batchSaved++;
              else batchDupes++;
            } catch {
              batchDupes++;
            }
          }
          totalSaved += batchSaved;
          totalDuplicatesSkipped += batchDupes;
        }

        if (!res.writableEnded) {
          res.write(
            `${JSON.stringify({
              type: 'batch',
              speciality,
              specIndex,
              specTotal,
              page,
              totalClaimedInSpec,
              savedCount: batchSaved,
              duplicatesSkipped: batchDupes,
              persistedToDb: Boolean(authedEmail),
              prospects: batch,
            })}\n`
          );
        }
      },
    });

    if (authedEmail) {
      await logAdminAudit(
        authedEmail,
        'SYNC_OLADOC_LAHORE',
        'doctors',
        null,
        `Synced oladoc.com Lahore directory (${parsed.data.scope}): fetched ${summary.totalFetched}, added ${totalSaved}, skipped ${totalDuplicatesSkipped} duplicates`
      );
    }

    if (!res.writableEnded) {
      res.write(
        `${JSON.stringify({
          type: 'done',
          totalFetched: summary.totalFetched,
          pagesFetched: summary.pagesFetched,
          totalSaved,
          totalDuplicatesSkipped,
          rateLimited: summary.rateLimited,
          persistedToDb: Boolean(authedEmail),
        })}\n`
      );
      res.end();
    }
  } catch (error) {
    console.error('Oladoc directory sync error:', error);
    if (!res.writableEnded) {
      res.write(
        `${JSON.stringify({
          type: 'error',
          error: error instanceof Error ? error.message : 'oladoc.com directory sync failed.',
        })}\n`
      );
      res.end();
    }
  }
});

// Protect all PostgreSQL & prospecting routes with Firebase Admin ID Token verification
apiRouter.use(requireAuth);

async function getScoringAndAutomationConfig() {
  const rows = await db.select().from(appSettings).where(eq(appSettings.key, 'default')).limit(1);
  if (rows.length > 0) {
    return {
      scoringRules: rows[0].scoringRules,
      automationConfig: rows[0].automationConfig,
    };
  }
  return {
    scoringRules: DEFAULT_SCORING_RULES,
    automationConfig: DEFAULT_AUTOMATION_CONFIG,
  };
}

async function logAdminAudit(
  actorEmail: string,
  action: string,
  entityType: string,
  entityId: string | null,
  details: string
) {
  try {
    await db.insert(auditLogs).values({
      actorEmail,
      action,
      entityType,
      entityId,
      details,
    });
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}

// Bootstrap workspace data (doctors, clinics, audits, activities, jobs, settings, audit logs)
apiRouter.get('/workspace', async (_req: AuthRequest, res: Response) => {
  try {
    const [doctorRows, clinicRows, auditRows, activityRows, jobRows, logRows, config] =
      await Promise.all([
        db.select().from(doctors).orderBy(desc(doctors.leadScore), desc(doctors.updatedAt)),
        db.select().from(clinics).orderBy(clinics.name),
        db.select().from(websiteAudits).orderBy(desc(websiteAudits.checkedAt)),
        db.select().from(leadActivities).orderBy(desc(leadActivities.createdAt)),
        db.select().from(automationJobs).orderBy(desc(automationJobs.startedAt)).limit(50),
        db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(100),
        getScoringAndAutomationConfig(),
      ]);

    const latestAuditByDoctor: Record<number, (typeof auditRows)[number]> = {};
    for (const a of auditRows) {
      if (!latestAuditByDoctor[a.doctorId]) {
        latestAuditByDoctor[a.doctorId] = a;
      }
    }

    const activitiesByDoctor: Record<number, Array<(typeof activityRows)[number]>> = {};
    for (const act of activityRows) {
      if (!activitiesByDoctor[act.doctorId]) {
        activitiesByDoctor[act.doctorId] = [];
      }
      activitiesByDoctor[act.doctorId].push(act);
    }

    const doctorCountByClinic: Record<number, number> = {};
    for (const d of doctorRows) {
      if (d.clinicId) {
        doctorCountByClinic[d.clinicId] = (doctorCountByClinic[d.clinicId] || 0) + 1;
      }
    }

    res.json({
      doctors: doctorRows.map((d) => ({
        ...d,
        latestAudit: latestAuditByDoctor[d.id] || null,
        activities: activitiesByDoctor[d.id] || [],
      })),
      clinics: clinicRows.map((c) => ({
        ...c,
        doctorCount: doctorCountByClinic[c.id] || 0,
      })),
      jobs: jobRows,
      auditLogs: logRows,
      scoringRules: config.scoringRules,
      automationConfig: config.automationConfig,
    });
  } catch (error) {
    console.error('Database query failed in /api/workspace:', error);
    res.status(500).json({ error: 'Failed to load workspace data from PostgreSQL.' });
  }
});

// Explicit seed sample endpoint for development testing
apiRouter.post('/seed-sample', async (req: AuthRequest, res: Response) => {
  try {
    const sample = buildSampleDataset();
    const { scoringRules } = await getScoringAndAutomationConfig();
    let added = 0;
    let skipped = 0;

    const clinicIdMap: Record<string, number> = {};
    const existingClinics = await db.select().from(clinics);
    for (const c of existingClinics) {
      clinicIdMap[c.normalizedName] = c.id;
    }

    for (const c of sample.clinics) {
      if (!clinicIdMap[c.normalizedName]) {
        const inserted = await db
          .insert(clinics)
          .values({
            name: c.name,
            normalizedName: c.normalizedName,
            area: c.area,
            address: c.address,
            phone: c.phone,
            website: c.website,
            googleMapsUrl: c.googleMapsUrl,
            googlePlaceId: c.googlePlaceId,
            lat: c.lat,
            lng: c.lng,
            practiceType: c.practiceType,
            dataSource: c.dataSource,
            dataOrigin: 'sample',
            lastVerifiedAt: c.lastVerifiedAt ? new Date(c.lastVerifiedAt) : null,
          })
          .onConflictDoNothing()
          .returning();
        if (inserted[0]) {
          clinicIdMap[c.normalizedName] = inserted[0].id;
        }
      }
    }

    for (const d of sample.doctors) {
      const normClinic = buildClinicNormalizedName(d.clinicName, d.area);
      const clinicId = clinicIdMap[normClinic] || null;
      const score = calculateLeadScore(
        {
          website: d.website,
          websiteClassification: d.websiteClassification,
          practiceType: d.practiceType,
          phone: d.phone,
          email: d.email,
          latestAudit: d.latestAudit,
        },
        scoringRules
      );

      const inserted = await db
        .insert(doctors)
        .values({
          fullName: d.fullName,
          speciality: d.speciality,
          clinicId,
          clinicName: d.clinicName,
          practiceType: d.practiceType,
          doctorStatus: d.doctorStatus,
          pmdcVerified: d.pmdcVerified,
          availability: d.availability,
          experienceYears: d.experienceYears,
          qualifications: d.qualifications,
          consultationFeePkr: d.consultationFeePkr,
          rating: d.rating,
          reviewCount: d.reviewCount,
          patientSatisfaction: d.patientSatisfaction,
          waitTime: d.waitTime,
          videoConsultation: d.videoConsultation,
          phone: d.phone,
          email: d.email,
          website: d.website,
          address: d.address,
          area: d.area,
          lat: d.lat,
          lng: d.lng,
          googleMapsUrl: d.googleMapsUrl,
          googlePlaceId: d.googlePlaceId,
          profileUrl: d.profileUrl,
          socialLinks: d.socialLinks,
          dataSource: d.dataSource,
          sourceUrl: d.sourceUrl,
          dataOrigin: 'sample',
          lastVerifiedAt: d.lastVerifiedAt ? new Date(d.lastVerifiedAt) : null,
          websiteClassification: d.websiteClassification,
          leadScore: score.score,
          leadPriority: score.priority,
          leadStatus: d.leadStatus,
          opportunityValuePkr: d.opportunityValuePkr,
          nextFollowUpAt: d.nextFollowUpAt ? new Date(d.nextFollowUpAt) : null,
          notes: d.notes,
          dedupeKey: d.dedupeKey,
        })
        .onConflictDoNothing()
        .returning();

      if (inserted[0]) {
        added++;
        if (d.latestAudit) {
          await db.insert(websiteAudits).values({
            doctorId: inserted[0].id,
            websiteUrl: d.latestAudit.websiteUrl,
            classification: d.latestAudit.classification,
            httpStatus: d.latestAudit.httpStatus,
            sslValid: d.latestAudit.sslValid,
            mobileResponsive: d.latestAudit.mobileResponsive,
            loadTimeMs: d.latestAudit.loadTimeMs,
            hasAppointmentBooking: d.latestAudit.hasAppointmentBooking,
            hasDoctorProfile: d.latestAudit.hasDoctorProfile,
            hasSeoFundamentals: d.latestAudit.hasSeoFundamentals,
            improvementOpportunities: d.latestAudit.improvementOpportunities,
          });
        }
      } else {
        skipped++;
      }
    }

    await logAdminAudit(
      req.user?.email || 'admin',
      'SEED_SAMPLE_DATA',
      'doctors',
      null,
      `Seeded ${added} development sample doctor records (${skipped} duplicates skipped)`
    );

    res.json({ added, skipped });
  } catch (error) {
    console.error('Database query failed in /api/seed-sample:', error);
    res.status(500).json({ error: 'Failed to seed sample development dataset.' });
  }
});

const doctorInputSchema = z.object({
  fullName: z.string().min(2).max(200),
  speciality: z.string().min(2).max(120),
  clinicName: z.string().min(2).max(200),
  practiceType: z.enum(['independent', 'hospital_affiliated', 'clinic_group']).default('independent'),
  doctorStatus: z.enum(DOCTOR_STATUSES).optional(),
  pmdcVerified: z.boolean().optional(),
  availability: z.string().max(240).nullable().optional(),
  experienceYears: z.number().int().min(0).max(80).nullable().optional(),
  qualifications: z.string().max(240).nullable().optional(),
  consultationFeePkr: z.number().int().nonnegative().nullable().optional(),
  rating: z.number().min(0).max(5).nullable().optional(),
  reviewCount: z.number().int().nonnegative().nullable().optional(),
  patientSatisfaction: z.string().max(40).nullable().optional(),
  waitTime: z.string().max(80).nullable().optional(),
  videoConsultation: z.boolean().optional(),
  phone: z.string().nullable().optional(),
  email: z.string().email().nullable().optional().or(z.literal('')),
  website: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  area: z.string().min(2).max(120),
  lat: z.number().nullable().optional(),
  lng: z.number().nullable().optional(),
  googleMapsUrl: z.string().nullable().optional(),
  googlePlaceId: z.string().nullable().optional(),
  profileUrl: z.string().nullable().optional(),
  socialLinks: z
    .object({
      facebook: z.string().nullable().optional(),
      instagram: z.string().nullable().optional(),
      linkedin: z.string().nullable().optional(),
    })
    .optional(),
  dataSource: z.string().default('Manual Entry'),
  sourceUrl: z.string().nullable().optional(),
  dataOrigin: z.enum(['verified', 'sample']).default('verified'),
  websiteClassification: z.enum(WEBSITE_CLASSIFICATIONS).optional(),
  leadStatus: z.enum(LEAD_STATUSES).default('New'),
  opportunityValuePkr: z.number().int().nonnegative().nullable().optional(),
  nextFollowUpAt: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

async function upsertClinicAndInsertDoctor(
  parsed: z.infer<typeof doctorInputSchema>,
  scoringRules: ScoringRulesConfig
) {
  const normPhone = normalizePakistanPhone(parsed.phone);
  const normWebsite = normalizeWebsiteUrl(parsed.website);
  const cleanEmail = parsed.email && parsed.email.trim() ? parsed.email.trim() : null;
  const dedupeKey = buildDoctorDedupeKey({
    fullName: parsed.fullName,
    speciality: parsed.speciality,
    clinicName: parsed.clinicName,
    area: parsed.area,
  });

  const existing = await db
    .select({ id: doctors.id })
    .from(doctors)
    .where(eq(doctors.dedupeKey, dedupeKey))
    .limit(1);

  if (existing.length > 0) {
    return { status: 'duplicate' as const, existingId: existing[0].id };
  }

  const normClinicName = buildClinicNormalizedName(parsed.clinicName, parsed.area);
  let clinicRow = (
    await db.select().from(clinics).where(eq(clinics.normalizedName, normClinicName)).limit(1)
  )[0];

  if (!clinicRow) {
    const insertedClinic = await db
      .insert(clinics)
      .values({
        name: parsed.clinicName,
        normalizedName: normClinicName,
        area: parsed.area,
        address: parsed.address || null,
        phone: normPhone,
        website: normWebsite,
        googleMapsUrl: parsed.googleMapsUrl || null,
        googlePlaceId: parsed.googlePlaceId || null,
        lat: parsed.lat ?? null,
        lng: parsed.lng ?? null,
        practiceType: parsed.practiceType,
        dataSource: parsed.dataSource,
        dataOrigin: parsed.dataOrigin,
        lastVerifiedAt: new Date(),
      })
      .returning();
    clinicRow = insertedClinic[0];
  }

  const initialClassification =
    parsed.websiteClassification ||
    (normWebsite ? 'Professionally developed website' : 'No website found');

  const scoreResult = calculateLeadScore(
    {
      website: normWebsite,
      websiteClassification: initialClassification,
      practiceType: parsed.practiceType,
      phone: normPhone,
      email: cleanEmail,
    },
    scoringRules
  );

  const resolvedPmdcVerified = Boolean(parsed.pmdcVerified || parsed.doctorStatus === 'PMDC Verified');
  const resolvedDoctorStatus =
    parsed.doctorStatus || (resolvedPmdcVerified ? 'PMDC Verified' : 'Active Practice');

  const inserted = await db
    .insert(doctors)
    .values({
      fullName: parsed.fullName.trim(),
      speciality: parsed.speciality.trim(),
      clinicId: clinicRow.id,
      clinicName: parsed.clinicName.trim(),
      practiceType: parsed.practiceType,
      doctorStatus: resolvedDoctorStatus,
      pmdcVerified: resolvedPmdcVerified,
      availability: parsed.availability?.trim() || null,
      experienceYears: parsed.experienceYears ?? null,
      qualifications: parsed.qualifications?.trim() || null,
      consultationFeePkr: parsed.consultationFeePkr ?? null,
      rating: parsed.rating ?? null,
      reviewCount: parsed.reviewCount ?? null,
      patientSatisfaction: parsed.patientSatisfaction?.trim() || null,
      waitTime: parsed.waitTime?.trim() || null,
      videoConsultation: Boolean(parsed.videoConsultation),
      phone: normPhone,
      email: cleanEmail,
      website: normWebsite,
      address: parsed.address?.trim() || null,
      area: parsed.area.trim(),
      lat: parsed.lat ?? null,
      lng: parsed.lng ?? null,
      googleMapsUrl: parsed.googleMapsUrl || null,
      googlePlaceId: parsed.googlePlaceId || null,
      profileUrl: parsed.profileUrl || null,
      socialLinks: parsed.socialLinks || {},
      dataSource: parsed.dataSource,
      sourceUrl: parsed.sourceUrl || null,
      dataOrigin: parsed.dataOrigin,
      lastVerifiedAt: new Date(),
      websiteClassification: initialClassification,
      leadScore: scoreResult.score,
      leadPriority: scoreResult.priority,
      leadStatus: parsed.leadStatus,
      opportunityValuePkr: parsed.opportunityValuePkr ?? null,
      nextFollowUpAt: parsed.nextFollowUpAt ? new Date(parsed.nextFollowUpAt) : null,
      notes: parsed.notes || null,
      dedupeKey,
    })
    .returning();

  return { status: 'created' as const, doctor: inserted[0] };
}

apiRouter.post('/doctors', async (req: AuthRequest, res: Response) => {
  const parsed = doctorInputSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid doctor payload', details: parsed.error.flatten() });
  }

  try {
    const { scoringRules } = await getScoringAndAutomationConfig();
    const result = await upsertClinicAndInsertDoctor(parsed.data, scoringRules);
    if (result.status === 'duplicate') {
      return res.status(409).json({
        error: 'Duplicate doctor detected with matching normalized name, speciality, clinic, and area.',
        existingId: result.existingId,
      });
    }

    await logAdminAudit(
      req.user?.email || 'admin',
      'CREATE_DOCTOR',
      'doctor',
      String(result.doctor.id),
      `Added ${result.doctor.fullName} (${result.doctor.clinicName}, ${result.doctor.area})`
    );

    res.status(201).json({ ...result.doctor, latestAudit: null, activities: [] });
  } catch (error) {
    console.error('Database query failed in POST /api/doctors:', error);
    res.status(500).json({ error: 'Failed to save doctor record.' });
  }
});

const bulkDoctorUpdateSchema = z
  .object({
    ids: z.array(z.number().int().positive()).min(1).max(200),
    leadStatus: z.enum(LEAD_STATUSES).optional(),
    leadPriority: z.enum(['High', 'Medium', 'Low']).optional(),
  })
  .refine((v) => Boolean(v.leadStatus || v.leadPriority), {
    message: 'At least one field (leadStatus or leadPriority) must be provided.',
  });

apiRouter.post('/doctors/bulk', async (req: AuthRequest, res: Response) => {
  const parsed = bulkDoctorUpdateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid bulk update payload', details: parsed.error.flatten() });
  }

  const { ids, leadStatus, leadPriority } = parsed.data;

  try {
    const existingRows = await db
      .select()
      .from(doctors)
      .where(inArray(doctors.id, ids));

    if (existingRows.length === 0) {
      return res.status(404).json({ error: 'No matching doctor records found.' });
    }

    const updateSet: {
      leadStatus?: string;
      leadPriority?: string;
      updatedAt: Date;
    } = { updatedAt: new Date() };
    if (leadStatus) updateSet.leadStatus = leadStatus;
    if (leadPriority) updateSet.leadPriority = leadPriority;

    const updatedRows = await db
      .update(doctors)
      .set(updateSet)
      .where(inArray(doctors.id, ids))
      .returning();

    const actor = req.user?.email || 'admin';
    const activityInserts: Array<{
      doctorId: number;
      type: string;
      summary: string;
      details: string;
      createdBy: string;
    }> = [];

    for (const prev of existingRows) {
      if (leadStatus && leadStatus !== prev.leadStatus) {
        activityInserts.push({
          doctorId: prev.id,
          type: 'status_change',
          summary: `Bulk status updated to ${leadStatus}`,
          details: `Previous status: ${prev.leadStatus}`,
          createdBy: actor,
        });
      }
      if (leadPriority && leadPriority !== prev.leadPriority) {
        activityInserts.push({
          doctorId: prev.id,
          type: 'status_change',
          summary: `Bulk priority set to ${leadPriority}`,
          details: `Previous priority: ${prev.leadPriority}`,
          createdBy: actor,
        });
      }
    }

    if (activityInserts.length > 0) {
      await db.insert(leadActivities).values(activityInserts);
    }

    const changeParts: string[] = [];
    if (leadStatus) changeParts.push(`status=${leadStatus}`);
    if (leadPriority) changeParts.push(`priority=${leadPriority}`);

    await logAdminAudit(
      actor,
      'BULK_UPDATE_DOCTORS',
      'doctors',
      ids.join(','),
      `Bulk updated ${updatedRows.length} doctors (${changeParts.join(', ')})`
    );

    res.json({ updatedCount: updatedRows.length });
  } catch (error) {
    console.error('Database query failed in POST /api/doctors/bulk:', error);
    res.status(500).json({ error: 'Failed to bulk update doctor records.' });
  }
});

const doctorPatchSchema = z.object({
  fullName: z.string().min(2).max(200).optional(),
  speciality: z.string().min(2).max(120).optional(),
  clinicName: z.string().min(2).max(200).optional(),
  practiceType: z.enum(['independent', 'hospital_affiliated', 'clinic_group']).optional(),
  doctorStatus: z.enum(DOCTOR_STATUSES).optional(),
  pmdcVerified: z.boolean().optional(),
  availability: z.string().max(240).nullable().optional(),
  experienceYears: z.number().int().min(0).max(80).nullable().optional(),
  qualifications: z.string().max(240).nullable().optional(),
  consultationFeePkr: z.number().int().nonnegative().nullable().optional(),
  rating: z.number().min(0).max(5).nullable().optional(),
  reviewCount: z.number().int().nonnegative().nullable().optional(),
  patientSatisfaction: z.string().max(40).nullable().optional(),
  waitTime: z.string().max(80).nullable().optional(),
  videoConsultation: z.boolean().optional(),
  phone: z.string().nullable().optional(),
  email: z.string().email().nullable().optional().or(z.literal('')),
  website: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  area: z.string().min(2).max(120).optional(),
  googleMapsUrl: z.string().nullable().optional(),
  profileUrl: z.string().nullable().optional(),
  socialLinks: z
    .object({
      facebook: z.string().nullable().optional(),
      instagram: z.string().nullable().optional(),
      linkedin: z.string().nullable().optional(),
    })
    .optional(),
  leadStatus: z.enum(LEAD_STATUSES).optional(),
  opportunityValuePkr: z.number().int().nonnegative().nullable().optional(),
  nextFollowUpAt: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

apiRouter.patch('/doctors/:id', async (req: AuthRequest, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: 'Invalid doctor ID' });
  }

  const parsed = doctorPatchSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid update payload', details: parsed.error.flatten() });
  }

  try {
    const existingRows = await db.select().from(doctors).where(eq(doctors.id, id)).limit(1);
    if (existingRows.length === 0) {
      return res.status(404).json({ error: 'Doctor record not found' });
    }
    const current = existingRows[0];
    const data = parsed.data;

    const nextFullName = data.fullName?.trim() || current.fullName;
    const nextSpeciality = data.speciality?.trim() || current.speciality;
    const nextClinicName = data.clinicName?.trim() || current.clinicName;
    const nextArea = data.area?.trim() || current.area;
    const nextPhone = data.phone !== undefined ? normalizePakistanPhone(data.phone) : current.phone;
    const nextEmail =
      data.email !== undefined ? (data.email?.trim() || null) : current.email;
    const nextWebsite =
      data.website !== undefined ? normalizeWebsiteUrl(data.website) : current.website;
    const nextPracticeType = (data.practiceType || current.practiceType) as
      | 'independent'
      | 'hospital_affiliated'
      | 'clinic_group';

    const latestAuditRows = await db
      .select()
      .from(websiteAudits)
      .where(eq(websiteAudits.doctorId, id))
      .orderBy(desc(websiteAudits.checkedAt))
      .limit(1);

    const nextClassification =
      nextWebsite === null
        ? 'No website found'
        : (current.websiteClassification === 'No website found'
            ? 'Professionally developed website'
            : current.websiteClassification);

    const { scoringRules } = await getScoringAndAutomationConfig();
    const scoreResult = calculateLeadScore(
      {
        website: nextWebsite,
        websiteClassification: nextClassification as (typeof WEBSITE_CLASSIFICATIONS)[number],
        practiceType: nextPracticeType,
        phone: nextPhone,
        email: nextEmail,
        latestAudit: latestAuditRows[0]
          ? {
              hasAppointmentBooking: latestAuditRows[0].hasAppointmentBooking,
              mobileResponsive: latestAuditRows[0].mobileResponsive,
            }
          : null,
      },
      scoringRules
    );

    const updated = await db
      .update(doctors)
      .set({
        fullName: nextFullName,
        speciality: nextSpeciality,
        clinicName: nextClinicName,
        practiceType: nextPracticeType,
        doctorStatus: data.doctorStatus || current.doctorStatus,
        pmdcVerified:
          data.pmdcVerified !== undefined
            ? data.pmdcVerified
            : data.doctorStatus === 'PMDC Verified'
            ? true
            : current.pmdcVerified,
        availability:
          data.availability !== undefined ? data.availability?.trim() || null : current.availability,
        experienceYears:
          data.experienceYears !== undefined ? data.experienceYears : current.experienceYears,
        qualifications:
          data.qualifications !== undefined
            ? data.qualifications?.trim() || null
            : current.qualifications,
        consultationFeePkr:
          data.consultationFeePkr !== undefined
            ? data.consultationFeePkr
            : current.consultationFeePkr,
        rating: data.rating !== undefined ? data.rating : current.rating,
        reviewCount: data.reviewCount !== undefined ? data.reviewCount : current.reviewCount,
        patientSatisfaction:
          data.patientSatisfaction !== undefined
            ? data.patientSatisfaction?.trim() || null
            : current.patientSatisfaction,
        waitTime: data.waitTime !== undefined ? data.waitTime?.trim() || null : current.waitTime,
        videoConsultation:
          data.videoConsultation !== undefined ? data.videoConsultation : current.videoConsultation,
        phone: nextPhone,
        email: nextEmail,
        website: nextWebsite,
        address: data.address !== undefined ? data.address : current.address,
        area: nextArea,
        googleMapsUrl:
          data.googleMapsUrl !== undefined ? data.googleMapsUrl : current.googleMapsUrl,
        profileUrl: data.profileUrl !== undefined ? data.profileUrl : current.profileUrl,
        socialLinks: data.socialLinks !== undefined ? data.socialLinks : current.socialLinks,
        websiteClassification: nextClassification,
        leadScore: scoreResult.score,
        leadPriority: scoreResult.priority,
        leadStatus: data.leadStatus || current.leadStatus,
        opportunityValuePkr:
          data.opportunityValuePkr !== undefined
            ? data.opportunityValuePkr
            : current.opportunityValuePkr,
        nextFollowUpAt:
          data.nextFollowUpAt !== undefined
            ? data.nextFollowUpAt
              ? new Date(data.nextFollowUpAt)
              : null
            : current.nextFollowUpAt,
        notes: data.notes !== undefined ? data.notes : current.notes,
        dedupeKey: buildDoctorDedupeKey({
          fullName: nextFullName,
          speciality: nextSpeciality,
          clinicName: nextClinicName,
          area: nextArea,
        }),
        updatedAt: new Date(),
      })
      .where(eq(doctors.id, id))
      .returning();

    if (data.leadStatus && data.leadStatus !== current.leadStatus) {
      await db.insert(leadActivities).values({
        doctorId: id,
        type: 'status_change',
        summary: `Lead status updated to ${data.leadStatus}`,
        details: `Previous status: ${current.leadStatus}`,
        createdBy: req.user?.email || 'admin',
      });
    }

    await logAdminAudit(
      req.user?.email || 'admin',
      'UPDATE_DOCTOR',
      'doctor',
      String(id),
      `Updated ${nextFullName}`
    );

    res.json(updated[0]);
  } catch (error) {
    console.error('Database query failed in PATCH /api/doctors/:id:', error);
    res.status(500).json({ error: 'Failed to update doctor record.' });
  }
});

apiRouter.delete('/doctors/:id', async (req: AuthRequest, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: 'Invalid doctor ID' });
  }

  try {
    const deleted = await db.delete(doctors).where(eq(doctors.id, id)).returning();
    if (deleted.length === 0) {
      return res.status(404).json({ error: 'Doctor record not found' });
    }
    await logAdminAudit(
      req.user?.email || 'admin',
      'DELETE_DOCTOR',
      'doctor',
      String(id),
      `Deleted ${deleted[0].fullName}`
    );
    res.json({ deletedId: id });
  } catch (error) {
    console.error('Database query failed in DELETE /api/doctors/:id:', error);
    res.status(500).json({ error: 'Failed to delete doctor record.' });
  }
});

const activitySchema = z.object({
  type: z.enum(['note', 'call', 'email', 'whatsapp', 'meeting', 'status_change', 'audit']),
  summary: z.string().min(2).max(300),
  details: z.string().nullable().optional(),
  followUpDate: z.string().nullable().optional(),
});

apiRouter.post('/doctors/:id/activities', async (req: AuthRequest, res: Response) => {
  const doctorId = Number(req.params.id);
  if (!Number.isInteger(doctorId) || doctorId <= 0) {
    return res.status(400).json({ error: 'Invalid doctor ID' });
  }

  const parsed = activitySchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid activity payload' });
  }

  try {
    const inserted = await db
      .insert(leadActivities)
      .values({
        doctorId,
        type: parsed.data.type,
        summary: parsed.data.summary,
        details: parsed.data.details || null,
        followUpDate: parsed.data.followUpDate ? new Date(parsed.data.followUpDate) : null,
        createdBy: req.user?.email || 'admin',
      })
      .returning();

    if (parsed.data.followUpDate) {
      await db
        .update(doctors)
        .set({ nextFollowUpAt: new Date(parsed.data.followUpDate), updatedAt: new Date() })
        .where(eq(doctors.id, doctorId));
    }

    res.status(201).json(inserted[0]);
  } catch (error) {
    console.error('Database query failed in POST /api/doctors/:id/activities:', error);
    res.status(500).json({ error: 'Failed to log communication activity.' });
  }
});

// Live Website Analysis Engine endpoint
apiRouter.post('/doctors/:id/audit', async (req: AuthRequest, res: Response) => {
  const doctorId = Number(req.params.id);
  if (!Number.isInteger(doctorId) || doctorId <= 0) {
    return res.status(400).json({ error: 'Invalid doctor ID' });
  }

  try {
    const existingRows = await db.select().from(doctors).where(eq(doctors.id, doctorId)).limit(1);
    if (existingRows.length === 0) {
      return res.status(404).json({ error: 'Doctor record not found' });
    }
    const doctor = existingRows[0];
    const targetUrl =
      typeof req.body?.websiteUrl === 'string' ? req.body.websiteUrl : doctor.website;

    const { scoringRules, automationConfig } = await getScoringAndAutomationConfig();
    const auditResult = await runLiveWebsiteAudit(targetUrl, automationConfig.requestTimeoutMs);

    const insertedAudit = await db
      .insert(websiteAudits)
      .values({
        doctorId,
        websiteUrl: auditResult.websiteUrl,
        classification: auditResult.classification,
        httpStatus: auditResult.httpStatus,
        sslValid: auditResult.sslValid,
        mobileResponsive: auditResult.mobileResponsive,
        loadTimeMs: auditResult.loadTimeMs,
        hasAppointmentBooking: auditResult.hasAppointmentBooking,
        hasDoctorProfile: auditResult.hasDoctorProfile,
        hasSeoFundamentals: auditResult.hasSeoFundamentals,
        improvementOpportunities: auditResult.improvementOpportunities,
      })
      .returning();

    const scoreResult = calculateLeadScore(
      {
        website: auditResult.websiteUrl,
        websiteClassification: auditResult.classification,
        practiceType: doctor.practiceType as 'independent' | 'hospital_affiliated' | 'clinic_group',
        phone: doctor.phone,
        email: doctor.email,
        latestAudit: auditResult,
      },
      scoringRules
    );

    const updatedDoctor = await db
      .update(doctors)
      .set({
        website: auditResult.websiteUrl,
        websiteClassification: auditResult.classification,
        leadScore: scoreResult.score,
        leadPriority: scoreResult.priority,
        lastVerifiedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(doctors.id, doctorId))
      .returning();

    await db.insert(leadActivities).values({
      doctorId,
      type: 'audit',
      summary: `Website audit completed: ${auditResult.classification}`,
      details:
        auditResult.improvementOpportunities.length > 0
          ? auditResult.improvementOpportunities.join('; ')
          : 'All core website checks passed.',
      createdBy: req.user?.email || 'admin',
    });

    res.json({
      audit: insertedAudit[0],
      doctor: updatedDoctor[0],
    });
  } catch (error) {
    console.error('Website audit failed:', error);
    res.status(500).json({ error: 'Failed to complete website analysis.' });
  }
});

// Real Doctor Discovery endpoint (oladoc.com, Google Places API New & OpenStreetMap Overpass)
apiRouter.post('/discover', async (req: AuthRequest, res: Response) => {
  const schema = z.object({
    provider: z.enum(['google_places', 'osm_overpass', 'oladoc']),
    area: z.string().min(2),
    speciality: z.string().min(2),
    query: z.string().optional(),
    maxPages: z.number().int().min(1).max(15).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid discovery search parameters' });
  }

  try {
    const result =
      parsed.data.provider === 'google_places'
        ? await discoverViaGooglePlaces(parsed.data)
        : parsed.data.provider === 'oladoc'
        ? await discoverViaOladoc(parsed.data)
        : await discoverViaOverpass(parsed.data);

    const existingKeys = new Set(
      (await db.select({ dedupeKey: doctors.dedupeKey }).from(doctors)).map((r) => r.dedupeKey)
    );

    await logAdminAudit(
      req.user?.email || 'admin',
      'RUN_DISCOVERY',
      'discovery',
      null,
      `Searched ${parsed.data.provider} for ${parsed.data.speciality} in ${parsed.data.area} (${result.prospects.length} results)`
    );

    res.json({
      ...result,
      prospects: result.prospects.map((p) => ({
        ...p,
        alreadyInDb: existingKeys.has(p.dedupeKey),
      })),
    });
  } catch (error) {
    console.error('Discovery error:', error);
    res.status(500).json({ error: 'Discovery provider request failed.' });
  }
});

// Batch CSV/Excel import with deduplication and normalization
apiRouter.post('/doctors/import', async (req: AuthRequest, res: Response) => {
  const schema = z.object({
    records: z.array(doctorInputSchema).min(1).max(500),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid import payload', details: parsed.error.flatten() });
  }

  try {
    const { scoringRules } = await getScoringAndAutomationConfig();
    let added = 0;
    let duplicatesSkipped = 0;
    const errors: string[] = [];

    for (const rec of parsed.data.records) {
      try {
        const result = await upsertClinicAndInsertDoctor(rec, scoringRules);
        if (result.status === 'created') {
          added++;
        } else {
          duplicatesSkipped++;
        }
      } catch (err) {
        errors.push(`${rec.fullName}: ${err instanceof Error ? err.message : 'Insert failed'}`);
      }
    }

    await logAdminAudit(
      req.user?.email || 'admin',
      'IMPORT_DOCTORS',
      'doctors',
      null,
      `Imported ${added} records, skipped ${duplicatesSkipped} duplicates`
    );

    res.json({ added, duplicatesSkipped, errors });
  } catch (error) {
    console.error('Bulk import failed:', error);
    res.status(500).json({ error: 'Bulk import operation failed.' });
  }
});

// Settings & Lead Score Recalculation
apiRouter.post('/settings', async (req: AuthRequest, res: Response) => {
  const schema = z.object({
    scoringRules: z.object({
      noWebsiteWeight: z.number().int().min(0).max(100),
      outdatedWebsiteWeight: z.number().int().min(0).max(100),
      missingAppointmentWeight: z.number().int().min(0).max(100),
      poorMobileWeight: z.number().int().min(0).max(100),
      independentPracticeWeight: z.number().int().min(0).max(100),
      publicContactWeight: z.number().int().min(0).max(100),
      highPriorityThreshold: z.number().int().min(1).max(100),
      mediumPriorityThreshold: z.number().int().min(0).max(99),
    }),
    automationConfig: z.object({
      requestsPerMinute: z.number().int().min(1).max(120),
      maxRetries: z.number().int().min(0).max(5),
      requestTimeoutMs: z.number().int().min(1000).max(30000),
      batchSize: z.number().int().min(1).max(50),
      respectRobotsTxt: z.boolean(),
    }),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid settings payload' });
  }

  try {
    await db
      .insert(appSettings)
      .values({
        key: 'default',
        scoringRules: parsed.data.scoringRules,
        automationConfig: parsed.data.automationConfig,
        updatedBy: req.user?.email || 'admin',
      })
      .onConflictDoUpdate({
        target: appSettings.key,
        set: {
          scoringRules: parsed.data.scoringRules,
          automationConfig: parsed.data.automationConfig,
          updatedBy: req.user?.email || 'admin',
          updatedAt: new Date(),
        },
      });

    // Recalculate scores for all doctors
    const allDoctors = await db.select().from(doctors);
    const allAudits = await db
      .select()
      .from(websiteAudits)
      .orderBy(desc(websiteAudits.checkedAt));
    const latestAuditMap: Record<number, (typeof allAudits)[number]> = {};
    for (const a of allAudits) {
      if (!latestAuditMap[a.doctorId]) latestAuditMap[a.doctorId] = a;
    }

    for (const doc of allDoctors) {
      const scoreResult = calculateLeadScore(
        {
          website: doc.website,
          websiteClassification: doc.websiteClassification as (typeof WEBSITE_CLASSIFICATIONS)[number],
          practiceType: doc.practiceType as 'independent' | 'hospital_affiliated' | 'clinic_group',
          phone: doc.phone,
          email: doc.email,
          latestAudit: latestAuditMap[doc.id]
            ? {
                hasAppointmentBooking: latestAuditMap[doc.id].hasAppointmentBooking,
                mobileResponsive: latestAuditMap[doc.id].mobileResponsive,
              }
            : null,
        },
        parsed.data.scoringRules
      );

      await db
        .update(doctors)
        .set({
          leadScore: scoreResult.score,
          leadPriority: scoreResult.priority,
        })
        .where(eq(doctors.id, doc.id));
    }

    await logAdminAudit(
      req.user?.email || 'admin',
      'UPDATE_SETTINGS',
      'settings',
      'default',
      `Updated scoring rules & recalculated ${allDoctors.length} lead scores`
    );

    res.json({
      scoringRules: parsed.data.scoringRules,
      automationConfig: parsed.data.automationConfig,
      recalculatedCount: allDoctors.length,
    });
  } catch (error) {
    console.error('Settings update failed:', error);
    res.status(500).json({ error: 'Failed to save configuration settings.' });
  }
});

// Background Automation Job Runner
apiRouter.post('/jobs/run', async (req: AuthRequest, res: Response) => {
  const schema = z.object({
    jobType: z.enum([
      'discover_clinics',
      'sync_oladoc_lahore',
      'refresh_records',
      'verify_websites',
      'deduplicate_scan',
      'batch_website_audit',
    ]),
    targetArea: z.string().nullable().optional(),
    targetSpeciality: z.string().nullable().optional(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid automation job parameters' });
  }

  try {
    const { scoringRules, automationConfig } = await getScoringAndAutomationConfig();
    const { jobType, targetArea, targetSpeciality } = parsed.data;
    const logs: string[] = [];
    let recordsProcessed = 0;
    let recordsAdded = 0;
    let recordsUpdated = 0;
    let duplicatesSkipped = 0;
    let errorCount = 0;

    if (jobType === 'discover_clinics') {
      const area = targetArea || 'Gulberg';
      const spec = targetSpeciality || 'Dermatologists';
      logs.push(`Starting OpenStreetMap Overpass discovery for ${spec} in ${area}...`);
      const result = await discoverViaOverpass({ area, speciality: spec });
      recordsProcessed = result.prospects.length;
      if (result.message) logs.push(result.message);

      for (const p of result.prospects.slice(0, automationConfig.batchSize)) {
        const resInsert = await upsertClinicAndInsertDoctor(
          {
            ...p,
            leadStatus: 'New',
          },
          scoringRules
        );
        if (resInsert.status === 'created') recordsAdded++;
        else duplicatesSkipped++;
      }
      logs.push(
        `Discovery finished: ${recordsAdded} new records saved, ${duplicatesSkipped} duplicates skipped.`
      );
    } else if (jobType === 'sync_oladoc_lahore') {
      logs.push('Starting paginated Lahore doctor directory crawl on https://oladoc.com/...');
      const syncResult = await runLahoreOladocDirectorySync({
        scope: 'quick',
        area: targetArea && targetArea !== 'All Lahore Areas' ? targetArea : 'All Lahore',
        specialities:
          targetSpeciality && targetSpeciality !== 'All Specialities'
            ? [targetSpeciality]
            : undefined,
        onBatch: async ({ speciality, page, batch }) => {
          recordsProcessed += batch.length;
          for (const p of batch) {
            const resInsert = await upsertClinicAndInsertDoctor(
              {
                ...p,
                leadStatus: 'New',
              },
              scoringRules
            );
            if (resInsert.status === 'created') recordsAdded++;
            else duplicatesSkipped++;
          }
          logs.push(`Fetched ${speciality} (page ${page}): ${batch.length} parsed.`);
        },
      });
      logs.push(
        `oladoc.com sync finished (${syncResult.pagesFetched} pages): ${recordsAdded} new Lahore doctors saved, ${duplicatesSkipped} duplicates skipped.`
      );
    } else if (jobType === 'verify_websites' || jobType === 'batch_website_audit') {
      const candidates = await db
        .select()
        .from(doctors)
        .limit(automationConfig.batchSize);

      const withWebsite = candidates.filter((d) => Boolean(d.website));
      logs.push(`Auditing ${withWebsite.length} clinic websites (timeout ${automationConfig.requestTimeoutMs}ms)...`);

      for (const doc of withWebsite) {
        recordsProcessed++;
        const audit = await runLiveWebsiteAudit(doc.website, automationConfig.requestTimeoutMs);
        await db.insert(websiteAudits).values({
          doctorId: doc.id,
          websiteUrl: audit.websiteUrl,
          classification: audit.classification,
          httpStatus: audit.httpStatus,
          sslValid: audit.sslValid,
          mobileResponsive: audit.mobileResponsive,
          loadTimeMs: audit.loadTimeMs,
          hasAppointmentBooking: audit.hasAppointmentBooking,
          hasDoctorProfile: audit.hasDoctorProfile,
          hasSeoFundamentals: audit.hasSeoFundamentals,
          improvementOpportunities: audit.improvementOpportunities,
        });

        const score = calculateLeadScore(
          {
            website: audit.websiteUrl,
            websiteClassification: audit.classification,
            practiceType: doc.practiceType as 'independent' | 'hospital_affiliated' | 'clinic_group',
            phone: doc.phone,
            email: doc.email,
            latestAudit: audit,
          },
          scoringRules
        );

        await db
          .update(doctors)
          .set({
            websiteClassification: audit.classification,
            leadScore: score.score,
            leadPriority: score.priority,
            lastVerifiedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(doctors.id, doc.id));

        if (audit.classification === 'Website unavailable') errorCount++;
        recordsUpdated++;
      }
      logs.push(`Completed audit across ${recordsUpdated} clinics (${errorCount} unreachable).`);
    } else if (jobType === 'deduplicate_scan') {
      const allDocs = await db.select().from(doctors);
      recordsProcessed = allDocs.length;
      const seen = new Map<string, number>();
      const dupeIds: number[] = [];
      for (const d of allDocs) {
        const key = buildDoctorDedupeKey({
          fullName: d.fullName,
          speciality: d.speciality,
          clinicName: d.clinicName,
          area: d.area,
        });
        if (seen.has(key)) {
          dupeIds.push(d.id);
        } else {
          seen.set(key, d.id);
        }
      }
      if (dupeIds.length > 0) {
        await db.delete(doctors).where(inArray(doctors.id, dupeIds));
        recordsUpdated = dupeIds.length;
      }
      logs.push(`Scanned ${recordsProcessed} records; removed ${dupeIds.length} duplicate entries.`);
    } else if (jobType === 'refresh_records') {
      const allDocs = await db.select().from(doctors).limit(automationConfig.batchSize);
      for (const d of allDocs) {
        recordsProcessed++;
        const normPhone = normalizePakistanPhone(d.phone);
        const normWeb = normalizeWebsiteUrl(d.website);
        await db
          .update(doctors)
          .set({
            phone: normPhone,
            website: normWeb,
            lastVerifiedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(doctors.id, d.id));
        recordsUpdated++;
      }
      logs.push(`Normalized phone/URL fields and refreshed timestamps for ${recordsUpdated} records.`);
    }

    const insertedJob = await db
      .insert(automationJobs)
      .values({
        jobType,
        status: 'completed',
        targetArea: targetArea || 'All Lahore Areas',
        targetSpeciality: targetSpeciality || 'All Specialities',
        recordsProcessed,
        recordsAdded,
        recordsUpdated,
        duplicatesSkipped,
        errorCount,
        logs,
        completedAt: new Date(),
      })
      .returning();

    await logAdminAudit(
      req.user?.email || 'admin',
      'RUN_AUTOMATION_JOB',
      'automation_job',
      String(insertedJob[0].id),
      `${jobType}: processed ${recordsProcessed}, added ${recordsAdded}, updated ${recordsUpdated}`
    );

    res.status(201).json(insertedJob[0]);
  } catch (error) {
    console.error('Automation job failed:', error);
    res.status(500).json({ error: 'Automation job execution failed.' });
  }
});
