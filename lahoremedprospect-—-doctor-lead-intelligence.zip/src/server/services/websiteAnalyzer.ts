import { analyzeWebsiteHtml, isSafePublicHttpUrl, type HtmlAnalysisOutput } from '../../lib/audit.ts';
import { normalizeWebsiteUrl } from '../../lib/normalization.ts';

export async function runLiveWebsiteAudit(
  rawUrl: string | null | undefined,
  timeoutMs = 8000
): Promise<HtmlAnalysisOutput & { websiteUrl: string | null }> {
  const normalizedUrl = normalizeWebsiteUrl(rawUrl);

  if (!normalizedUrl) {
    return {
      websiteUrl: null,
      classification: 'No website found',
      httpStatus: null,
      sslValid: false,
      mobileResponsive: false,
      loadTimeMs: null,
      hasAppointmentBooking: false,
      hasDoctorProfile: false,
      hasSeoFundamentals: false,
      improvementOpportunities: [
        'No official clinic website URL is on record',
        'Build a mobile-first Lahore clinic website with online appointment booking and Google Maps SEO',
      ],
    };
  }

  if (!isSafePublicHttpUrl(normalizedUrl)) {
    return {
      websiteUrl: normalizedUrl,
      classification: 'Website unavailable',
      httpStatus: null,
      sslValid: false,
      mobileResponsive: false,
      loadTimeMs: null,
      hasAppointmentBooking: false,
      hasDoctorProfile: false,
      hasSeoFundamentals: false,
      improvementOpportunities: ['URL points to a non-public or unsupported host'],
    };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const start = Date.now();

  try {
    const response = await fetch(normalizedUrl, {
      method: 'GET',
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        'User-Agent': 'LahoreMedProspect-SiteAudit/1.0 (Public Business Quality Check)',
        Accept: 'text/html,application/xhtml+xml',
      },
    });

    const loadTimeMs = Date.now() - start;
    const finalUrl = response.url || normalizedUrl;
    const sslValid = finalUrl.startsWith('https://');
    const html = await response.text();

    const analysis = analyzeWebsiteHtml({
      url: finalUrl,
      httpStatus: response.status,
      loadTimeMs,
      sslValid,
      html,
    });

    return {
      websiteUrl: normalizedUrl,
      ...analysis,
    };
  } catch (error) {
    const loadTimeMs = Date.now() - start;
    const analysis = analyzeWebsiteHtml({
      url: normalizedUrl,
      httpStatus: null,
      loadTimeMs,
      sslValid: normalizedUrl.startsWith('https://'),
      html: null,
      fetchError: error instanceof Error ? error.message : 'Request failed',
    });

    return {
      websiteUrl: normalizedUrl,
      ...analysis,
    };
  } finally {
    clearTimeout(timer);
  }
}
