import {
  OLADOC_SPECIALITY_SLUGS,
  buildOladocListingUrl,
  extractOladocTotalCount,
  parseOladocListingPage,
  type ParsedOladocDoctor,
} from '../../lib/oladocParser.ts';
import { MEDICAL_SPECIALITIES } from '../../types/domain.ts';
import type { DiscoveredProspect, DiscoveryResult } from './discovery.ts';

const PAGE_SIZE = 10;
const REQUEST_TIMEOUT_MS = 12000;

async function fetchOladocPage(
  url: string,
  externalSignal?: AbortSignal
): Promise<{ status: number; html: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  const onExternalAbort = () => controller.abort();
  externalSignal?.addEventListener('abort', onExternalAbort, { once: true });

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'LahoreMedProspect/1.0 (B2B Lahore Clinic Directory Research)',
        Accept: 'text/html,application/xhtml+xml',
      },
    });
    const html = await res.text();
    return { status: res.status, html };
  } finally {
    clearTimeout(timer);
    externalSignal?.removeEventListener('abort', onExternalAbort);
  }
}

function toDiscoveredProspect(doc: ParsedOladocDoctor): DiscoveredProspect {
  return {
    fullName: doc.fullName,
    speciality: doc.speciality,
    clinicName: doc.clinicName,
    practiceType: doc.practiceType,
    phone: doc.phone,
    email: doc.email,
    website: doc.website,
    address: doc.address,
    area: doc.area,
    lat: doc.lat,
    lng: doc.lng,
    googleMapsUrl: doc.googleMapsUrl,
    googlePlaceId: doc.googlePlaceId,
    profileUrl: doc.profileUrl,
    dataSource: doc.dataSource,
    sourceUrl: doc.sourceUrl,
    dataOrigin: doc.dataOrigin,
    lastVerifiedAt: doc.lastVerifiedAt,
    dedupeKey: doc.dedupeKey,
    notes: doc.notes,
  };
}

export async function discoverViaOladoc(params: {
  area: string;
  speciality: string;
  query?: string;
  maxPages?: number;
}): Promise<DiscoveryResult> {
  const maxPages = Math.min(Math.max(params.maxPages ?? 3, 1), 15);
  const cleanQuery = params.query?.trim().toLowerCase() || '';
  const targetSpecs =
    params.speciality === 'All'
      ? MEDICAL_SPECIALITIES.slice(0, 4)
      : [params.speciality];

  const prospects: DiscoveredProspect[] = [];
  const seenKeys = new Set<string>();
  let totalListed = 0;

  try {
    for (const spec of targetSpecs) {
      const pagesToFetch = params.speciality === 'All' ? 1 : maxPages;
      for (let page = 0; page < pagesToFetch; page++) {
        const offset = page * PAGE_SIZE;
        const url = buildOladocListingUrl({
          speciality: spec,
          area: params.area,
          offset,
        });

        const { status, html } = await fetchOladocPage(url);
        if (status === 429) {
          return {
            provider: 'oladoc',
            configured: true,
            message: 'oladoc.com rate limit reached. Returning partial results retrieved so far.',
            prospects,
          };
        }
        if (status >= 400) break;

        if (page === 0) {
          totalListed += extractOladocTotalCount(html);
        }

        const parsed = parseOladocListingPage(html, url, {
          fallbackSpeciality: spec,
          fallbackArea: params.area === 'All Lahore' ? undefined : params.area,
        });

        if (parsed.length === 0) break;

        for (const item of parsed) {
          if (seenKeys.has(item.dedupeKey)) continue;
          if (cleanQuery) {
            const haystack = `${item.fullName} ${item.clinicName} ${item.area} ${item.notes || ''}`.toLowerCase();
            if (!haystack.includes(cleanQuery)) continue;
          }
          seenKeys.add(item.dedupeKey);
          prospects.push(toDiscoveredProspect(item));
        }

        if (parsed.length < PAGE_SIZE) break;
        if (page + 1 < pagesToFetch) {
          await new Promise((r) => setTimeout(r, 100));
        }
      }
    }

    const message =
      totalListed > 0
        ? `Retrieved ${prospects.length} live verified doctors from oladoc.com (${totalListed.toLocaleString()} total listed for this Lahore search).`
        : undefined;

    return {
      provider: 'oladoc',
      configured: true,
      message,
      prospects,
    };
  } catch (error) {
    return {
      provider: 'oladoc',
      configured: true,
      message: error instanceof Error ? error.message : 'Failed to fetch from oladoc.com',
      prospects,
    };
  }
}

export type OladocSyncScope = 'quick' | 'standard' | 'full';

export async function runLahoreOladocDirectorySync(params: {
  scope: OladocSyncScope;
  area?: string;
  specialities?: string[];
  signal?: AbortSignal;
  onBatch: (payload: {
    speciality: string;
    specIndex: number;
    specTotal: number;
    page: number;
    totalClaimedInSpec: number;
    batch: DiscoveredProspect[];
  }) => Promise<void> | void;
}): Promise<{
  totalFetched: number;
  pagesFetched: number;
  rateLimited: boolean;
}> {
  const maxPagesPerSpec =
    params.scope === 'quick' ? 2 : params.scope === 'standard' ? 6 : 85;

  const targetSpecs =
    params.specialities && params.specialities.length > 0
      ? params.specialities.filter((s) => s in OLADOC_SPECIALITY_SLUGS || s.length > 0)
      : [...MEDICAL_SPECIALITIES];

  const seenKeys = new Set<string>();
  let totalFetched = 0;
  let pagesFetched = 0;
  let rateLimited = false;

  for (let specIdx = 0; specIdx < targetSpecs.length; specIdx++) {
    if (params.signal?.aborted) break;
    const spec = targetSpecs[specIdx];
    let totalClaimedInSpec = 0;

    for (let page = 0; page < maxPagesPerSpec; page++) {
      if (params.signal?.aborted) break;

      const offset = page * PAGE_SIZE;
      if (page > 0 && totalClaimedInSpec > 0 && offset >= totalClaimedInSpec) {
        break;
      }

      const url = buildOladocListingUrl({
        speciality: spec,
        area: params.area,
        offset,
      });

      const { status, html } = await fetchOladocPage(url, params.signal);
      pagesFetched++;

      if (status === 429) {
        rateLimited = true;
        break;
      }
      if (status >= 400) break;

      if (page === 0) {
        totalClaimedInSpec = extractOladocTotalCount(html);
      }

      const parsed = parseOladocListingPage(html, url, {
        fallbackSpeciality: spec,
        fallbackArea: params.area && params.area !== 'All Lahore' ? params.area : undefined,
      });

      if (parsed.length === 0) break;

      const uniqueBatch: DiscoveredProspect[] = [];
      for (const item of parsed) {
        if (seenKeys.has(item.dedupeKey)) continue;
        seenKeys.add(item.dedupeKey);
        uniqueBatch.push(toDiscoveredProspect(item));
      }

      totalFetched += uniqueBatch.length;
      await params.onBatch({
        speciality: spec,
        specIndex: specIdx + 1,
        specTotal: targetSpecs.length,
        page: page + 1,
        totalClaimedInSpec,
        batch: uniqueBatch,
      });

      if (parsed.length < PAGE_SIZE) break;
      await new Promise((r) => setTimeout(r, 90));
    }

    if (rateLimited) break;
  }

  return { totalFetched, pagesFetched, rateLimited };
}
