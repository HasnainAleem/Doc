import { LAHORE_AREA_COORDS } from '../../lib/sampleData.ts';
import {
  buildDoctorDedupeKey,
  inferLahoreArea,
  inferSpeciality,
  normalizePakistanPhone,
  normalizeWebsiteUrl,
} from '../../lib/normalization.ts';
import type { DataOrigin, DoctorStatus, PracticeType } from '../../types/domain.ts';

export interface DiscoveredProspect {
  fullName: string;
  speciality: string;
  clinicName: string;
  practiceType: PracticeType;
  doctorStatus?: DoctorStatus;
  pmdcVerified?: boolean;
  availability?: string | null;
  experienceYears?: number | null;
  qualifications?: string | null;
  consultationFeePkr?: number | null;
  rating?: number | null;
  reviewCount?: number | null;
  patientSatisfaction?: string | null;
  waitTime?: string | null;
  videoConsultation?: boolean;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  area: string;
  lat: number | null;
  lng: number | null;
  googleMapsUrl: string | null;
  googlePlaceId: string | null;
  profileUrl: string | null;
  dataSource: string;
  sourceUrl: string | null;
  dataOrigin: DataOrigin;
  lastVerifiedAt: string;
  dedupeKey: string;
  notes?: string | null;
}

export interface DiscoveryResult {
  provider: 'google_places' | 'osm_overpass' | 'oladoc';
  configured: boolean;
  quotaExceeded?: boolean;
  message?: string;
  prospects: DiscoveredProspect[];
}

export async function discoverViaGooglePlaces(params: {
  area: string;
  speciality: string;
  query?: string;
}): Promise<DiscoveryResult> {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY;
  if (!apiKey) {
    return {
      provider: 'google_places',
      configured: false,
      message:
        'Google Places API key is not present in runtime environment variables. Set GOOGLE_MAPS_API_KEY or use OpenStreetMap Overpass discovery.',
      prospects: [],
    };
  }

  const coords = LAHORE_AREA_COORDS[params.area] || { lat: 31.5204, lng: 74.3587 };
  const textQuery = params.query?.trim()
    ? `${params.query.trim()} ${params.area} Lahore Pakistan`
    : `${params.speciality} clinic in ${params.area}, Lahore, Pakistan`;

  const fieldMask = [
    'places.id',
    'places.displayName',
    'places.formattedAddress',
    'places.location',
    'places.nationalPhoneNumber',
    'places.internationalPhoneNumber',
    'places.websiteUri',
    'places.googleMapsUri',
    'places.primaryTypeDisplayName',
  ].join(',');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);

  try {
    const response = await fetch('https://places.googleapis.com/v1/places:searchText', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': fieldMask,
        'X-Goog-Maps-Solution-ID': 'gmp_mcp_codeassist_v1_aistudio',
      },
      body: JSON.stringify({
        textQuery,
        languageCode: 'en',
        regionCode: 'PK',
        pageSize: 15,
        locationBias: {
          circle: {
            center: { latitude: coords.lat, longitude: coords.lng },
            radius: 4500.0,
          },
        },
      }),
    });

    if (response.status === 429) {
      return {
        provider: 'google_places',
        configured: true,
        quotaExceeded: true,
        message: 'Google Maps Platform quota reached for Places Text Search.',
        prospects: [],
      };
    }

    if (!response.ok) {
      const errBody = await response.text();
      if (errBody.includes('RESOURCE_EXHAUSTED')) {
        return {
          provider: 'google_places',
          configured: true,
          quotaExceeded: true,
          message: 'Google Maps Platform quota reached for Places Text Search.',
          prospects: [],
        };
      }
      return {
        provider: 'google_places',
        configured: true,
        message: `Places API returned HTTP ${response.status}. Try OpenStreetMap Overpass or adjust query.`,
        prospects: [],
      };
    }

    const payload = (await response.json()) as { places?: Array<Record<string, any>> };
    const places = Array.isArray(payload.places) ? payload.places : [];
    const now = new Date().toISOString();

    const prospects: DiscoveredProspect[] = places.map((place) => {
      const displayName: string = place.displayName?.text || 'Unnamed Medical Clinic';
      const address: string | null = place.formattedAddress || null;
      const resolvedArea = inferLahoreArea(address || params.area);
      const rawPhone: string | null =
        place.internationalPhoneNumber || place.nationalPhoneNumber || null;
      const phone = normalizePakistanPhone(rawPhone);
      const website = normalizeWebsiteUrl(place.websiteUri || null);
      const isDr = /\bdr\.?\s/i.test(displayName);
      const fullName = isDr ? displayName : `${displayName} (Lead Specialist)`;

      return {
        fullName,
        speciality: params.speciality || inferSpeciality(displayName),
        clinicName: displayName,
        practiceType: displayName.toLowerCase().includes('hospital')
          ? 'hospital_affiliated'
          : 'independent',
        phone,
        email: null, // Places API does not return business emails; never invent
        website,
        address,
        area: resolvedArea,
        lat: typeof place.location?.latitude === 'number' ? place.location.latitude : null,
        lng: typeof place.location?.longitude === 'number' ? place.location.longitude : null,
        googleMapsUrl: place.googleMapsUri || null,
        googlePlaceId: place.id || null,
        profileUrl: null,
        dataSource: 'Google Places API (New)',
        sourceUrl: place.googleMapsUri || null,
        dataOrigin: 'verified',
        lastVerifiedAt: now,
        dedupeKey: buildDoctorDedupeKey({
          fullName,
          speciality: params.speciality,
          clinicName: displayName,
          area: resolvedArea,
        }),
      };
    });

    return {
      provider: 'google_places',
      configured: true,
      prospects,
    };
  } catch (error) {
    return {
      provider: 'google_places',
      configured: true,
      message: error instanceof Error ? error.message : 'Google Places request failed',
      prospects: [],
    };
  } finally {
    clearTimeout(timeout);
  }
}

export async function discoverViaOverpass(params: {
  area: string;
  speciality: string;
}): Promise<DiscoveryResult> {
  const coords = LAHORE_AREA_COORDS[params.area] || { lat: 31.5204, lng: 74.3587 };
  const radiusMeters = 3500;

  const overpassQuery = `
    [out:json][timeout:10];
    (
      node["amenity"~"clinic|doctors|dentist"](around:${radiusMeters},${coords.lat},${coords.lng});
      way["amenity"~"clinic|doctors|dentist"](around:${radiusMeters},${coords.lat},${coords.lng});
      node["healthcare"](around:${radiusMeters},${coords.lat},${coords.lng});
    );
    out center 25;
  `;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 11000);

  try {
    const response = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'User-Agent': 'LahoreMedProspect/1.0 (B2B Medical Directory Research)',
      },
      body: `data=${encodeURIComponent(overpassQuery)}`,
    });

    if (!response.ok) {
      return {
        provider: 'osm_overpass',
        configured: true,
        message: `OpenStreetMap Overpass API returned HTTP ${response.status}. Rate limit may be active; retry shortly.`,
        prospects: [],
      };
    }

    const data = (await response.json()) as { elements?: Array<Record<string, any>> };
    const elements = Array.isArray(data.elements) ? data.elements : [];
    const now = new Date().toISOString();

    const prospects: DiscoveredProspect[] = [];
    for (const el of elements) {
      const tags = el.tags || {};
      const name: string | undefined = tags.name || tags['name:en'];
      if (!name) continue;

      const lat = typeof el.lat === 'number' ? el.lat : el.center?.lat ?? null;
      const lng = typeof el.lon === 'number' ? el.lon : el.center?.lon ?? null;
      const rawAddress = [tags['addr:housenumber'], tags['addr:street'], tags['addr:suburb'], tags['addr:city']]
        .filter(Boolean)
        .join(', ');
      const address = rawAddress || `${params.area}, Lahore, Pakistan`;
      const resolvedArea = inferLahoreArea(rawAddress || params.area);

      const phone = normalizePakistanPhone(tags.phone || tags['contact:phone'] || null);
      const email = (tags.email || tags['contact:email'] || '').trim() || null;
      const website = normalizeWebsiteUrl(tags.website || tags['contact:website'] || null);

      const inferredSpec =
        params.speciality && params.speciality !== 'All'
          ? params.speciality
          : inferSpeciality(`${name} ${tags['healthcare:speciality'] || ''} ${tags.amenity || ''}`);

      const isDr = /\bdr\.?\s/i.test(name);
      const fullName = isDr ? name : `${name} (Lead Specialist)`;

      const osmUrl = `https://www.openstreetmap.org/${el.type}/${el.id}`;

      prospects.push({
        fullName,
        speciality: inferredSpec,
        clinicName: name,
        practiceType: tags.amenity === 'hospital' ? 'hospital_affiliated' : 'independent',
        phone,
        email,
        website,
        address,
        area: resolvedArea,
        lat,
        lng,
        googleMapsUrl: lat && lng ? `https://maps.google.com/?q=${lat},${lng}` : null,
        googlePlaceId: null,
        profileUrl: null,
        dataSource: 'OpenStreetMap Overpass API',
        sourceUrl: osmUrl,
        dataOrigin: 'verified',
        lastVerifiedAt: now,
        dedupeKey: buildDoctorDedupeKey({
          fullName,
          speciality: inferredSpec,
          clinicName: name,
          area: resolvedArea,
        }),
      });
    }

    return {
      provider: 'osm_overpass',
      configured: true,
      prospects,
    };
  } catch (error) {
    return {
      provider: 'osm_overpass',
      configured: true,
      message: error instanceof Error ? error.message : 'Overpass API request timed out',
      prospects: [],
    };
  } finally {
    clearTimeout(timeout);
  }
}
