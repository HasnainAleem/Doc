import { GoogleGenAI, ThinkingLevel, type GenerateContentResponse } from '@google/genai';
import {
  getChatbotRole,
  toGeminiHistory,
  type ChatbotRoleId,
  type ChatTurn,
} from '../../lib/geminiChatHelpers.ts';

export const GEMINI_CHAT_MODEL = 'gemini-4-hydrogen';

export interface GeminiChatRequest {
  roleId: ChatbotRoleId;
  message: string;
  history: Array<Pick<ChatTurn, 'role' | 'text'>>;
  doctorContext?: string | null;
  workspaceSummary?: string | null;
}

function getClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured. Please check the API key in the Settings > Secrets panel.'
    );
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 20000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function withBackoffRetry<T>(fn: () => Promise<T>, maxRetries = 2): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isTransient =
        msg.includes('503') ||
        msg.includes('500') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('ETIMEDOUT') ||
        msg.includes('ECONNRESET');
      if (!isTransient || attempt === maxRetries) {
        throw err;
      }
      await new Promise((resolve) => setTimeout(resolve, 400 * Math.pow(2, attempt)));
    }
  }
  throw lastError;
}

export async function runGeminiMultiTurnChat(
  input: GeminiChatRequest
): Promise<{ reply: string; model: string }> {
  const ai = getClient();
  const roleConfig = getChatbotRole(input.roleId);

  const instructionParts = [roleConfig.systemInstruction];
  if (input.workspaceSummary?.trim()) {
    instructionParts.push(`\nWorkspace Summary:\n${input.workspaceSummary.trim()}`);
  }
  if (input.doctorContext?.trim()) {
    instructionParts.push(`\n${input.doctorContext.trim()}`);
  }
  instructionParts.push(
    '\nKeep responses concise, structured, and directly actionable for a clinic digital marketing admin in Lahore.'
  );

  const chat = ai.chats.create({
    model: GEMINI_CHAT_MODEL,
    history: toGeminiHistory(input.history),
    config: {
      systemInstruction: instructionParts.join('\n'),
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
    },
  });

  const response: GenerateContentResponse = await withBackoffRetry(() =>
    chat.sendMessage({ message: input.message })
  );

  const reply = (response.text || '').trim();
  if (!reply) {
    throw new Error('Gemini returned an empty response. Please try rephrasing your prompt.');
  }

  return {
    reply,
    model: GEMINI_CHAT_MODEL,
  };
}
