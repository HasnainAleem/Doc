export const LAHORE_AREAS = [
  'Gulberg',
  'DHA',
  'Johar Town',
  'Model Town',
  'Garden Town',
  'Faisal Town',
  'Bahria Town',
  'Township',
  'Wapda Town',
  'Muslim Town',
  'Cavalry Ground',
  'Allama Iqbal Town',
  'Shadman',
  'Ichhra',
  'Cantt',
] as const;

export type LahoreArea = (typeof LAHORE_AREAS)[number];

export const MEDICAL_SPECIALITIES = [
  'Dermatologists',
  'Cardiologists',
  'Dentists',
  'Gynecologists',
  'Neurologists',
  'Orthopedic surgeons',
  'General physicians',
  'Pediatricians',
  'Psychiatrists',
  'Plastic surgeons',
  'Physiotherapists',
  'Ophthalmologists',
  'ENT specialists',
  'Urologists',
  'Gastroenterologists',
  'Aesthetic physicians',
] as const;

export type MedicalSpeciality = (typeof MEDICAL_SPECIALITIES)[number];

export const LEAD_STATUSES = [
  'New',
  'Researching',
  'Contacted',
  'Follow-up required',
  'Interested',
  'Meeting scheduled',
  'Proposal sent',
  'Negotiating',
  'Converted',
  'Not interested',
] as const;

export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const WEBSITE_CLASSIFICATIONS = [
  'No website found',
  'Website unavailable',
  'Outdated website',
  'Poor mobile responsiveness',
  'Slow website',
  'Missing appointment functionality',
  'Missing doctor profile',
  'Missing SEO fundamentals',
  'Professionally developed website',
] as const;

export type WebsiteClassification = (typeof WEBSITE_CLASSIFICATIONS)[number];

export const DOCTOR_STATUSES = [
  'PMDC Verified',
  'Active Practice',
  'Online Video Only',
  'Temporarily Unavailable',
] as const;

export type DoctorStatus = (typeof DOCTOR_STATUSES)[number];

export type LeadPriority = 'High' | 'Medium' | 'Low';
export type PracticeType = 'independent' | 'hospital_affiliated' | 'clinic_group';
export type DataOrigin = 'verified' | 'sample';

export interface ScoringRulesConfig {
  noWebsiteWeight: number;
  outdatedWebsiteWeight: number;
  missingAppointmentWeight: number;
  poorMobileWeight: number;
  independentPracticeWeight: number;
  publicContactWeight: number;
  highPriorityThreshold: number;
  mediumPriorityThreshold: number;
}

export const DEFAULT_SCORING_RULES: ScoringRulesConfig = {
  noWebsiteWeight: 45,
  outdatedWebsiteWeight: 25,
  missingAppointmentWeight: 15,
  poorMobileWeight: 10,
  independentPracticeWeight: 10,
  publicContactWeight: 5,
  highPriorityThreshold: 80,
  mediumPriorityThreshold: 60,
};

export interface AutomationConfig {
  requestsPerMinute: number;
  maxRetries: number;
  requestTimeoutMs: number;
  batchSize: number;
  respectRobotsTxt: boolean;
}

export const DEFAULT_AUTOMATION_CONFIG: AutomationConfig = {
  requestsPerMinute: 20,
  maxRetries: 2,
  requestTimeoutMs: 8000,
  batchSize: 15,
  respectRobotsTxt: true,
};

export interface WebsiteAuditReport {
  id?: number;
  doctorId: number;
  websiteUrl: string | null;
  classification: WebsiteClassification;
  httpStatus: number | null;
  sslValid: boolean | null;
  mobileResponsive: boolean | null;
  loadTimeMs: number | null;
  hasAppointmentBooking: boolean | null;
  hasDoctorProfile: boolean | null;
  hasSeoFundamentals: boolean | null;
  improvementOpportunities: string[];
  checkedAt: string;
}

export interface LeadActivity {
  id: number;
  doctorId: number;
  type: 'note' | 'call' | 'email' | 'whatsapp' | 'meeting' | 'status_change' | 'audit';
  summary: string;
  details: string | null;
  followUpDate: string | null;
  createdBy: string;
  createdAt: string;
}

export interface ClinicRecord {
  id: number;
  name: string;
  normalizedName: string;
  area: string;
  address: string | null;
  phone: string | null;
  website: string | null;
  googleMapsUrl: string | null;
  googlePlaceId: string | null;
  lat: number | null;
  lng: number | null;
  practiceType: PracticeType;
  dataSource: string;
  dataOrigin: DataOrigin;
  lastVerifiedAt: string | null;
  doctorCount?: number;
}

export interface DoctorRecord {
  id: number;
  fullName: string;
  speciality: string;
  clinicId: number | null;
  clinicName: string;
  practiceType: PracticeType;
  doctorStatus: DoctorStatus;
  pmdcVerified: boolean;
  availability: string | null;
  experienceYears: number | null;
  qualifications: string | null;
  consultationFeePkr: number | null;
  rating: number | null;
  reviewCount: number | null;
  patientSatisfaction: string | null;
  waitTime: string | null;
  videoConsultation: boolean;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  area: string;
  lat: number | null;
  lng: number | null;
  googleMapsUrl: string | null;
  googlePlaceId: string | null;
  profileUrl: string | null;
  socialLinks: {
    facebook?: string | null;
    instagram?: string | null;
    linkedin?: string | null;
  };
  dataSource: string;
  sourceUrl: string | null;
  dataOrigin: DataOrigin;
  lastVerifiedAt: string | null;
  websiteClassification: WebsiteClassification;
  leadScore: number;
  leadPriority: LeadPriority;
  leadStatus: LeadStatus;
  opportunityValuePkr: number | null;
  nextFollowUpAt: string | null;
  notes: string | null;
  dedupeKey: string;
  createdAt: string;
  updatedAt: string;
  latestAudit?: WebsiteAuditReport | null;
  activities?: LeadActivity[];
}

export interface AutomationJobRecord {
  id: number;
  jobType:
    | 'discover_clinics'
    | 'sync_oladoc_lahore'
    | 'refresh_records'
    | 'verify_websites'
    | 'deduplicate_scan'
    | 'batch_website_audit';
  status: 'queued' | 'running' | 'completed' | 'failed';
  targetArea: string | null;
  targetSpeciality: string | null;
  recordsProcessed: number;
  recordsAdded: number;
  recordsUpdated: number;
  duplicatesSkipped: number;
  errorCount: number;
  logs: string[];
  startedAt: string;
  completedAt: string | null;
}

export interface AuditLogEntry {
  id: number;
  actorEmail: string;
  action: string;
  entityType: string;
  entityId: string | null;
  details: string;
  createdAt: string;
}

export type NavSection =
  | 'dashboard'
  | 'discover'
  | 'doctors'
  | 'clinics'
  | 'website-audit'
  | 'leads'
  | 'map'
  | 'import-export'
  | 'automation'
  | 'settings';
