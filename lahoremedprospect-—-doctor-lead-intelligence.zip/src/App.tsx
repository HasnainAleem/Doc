import { useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { ThemeProvider } from './context/ThemeContext';
import { WorkspaceProvider, useWorkspace } from './context/WorkspaceContext';
import { AuthGate } from './components/AuthGate';
import { SidebarShell } from './components/SidebarShell';
import { DashboardView } from './components/DashboardView';
import { DiscoverDoctorsView } from './components/DiscoverDoctorsView';
import { DoctorDatabaseView } from './components/DoctorDatabaseView';
import { ClinicsView } from './components/ClinicsView';
import { WebsiteAuditView } from './components/WebsiteAuditView';
import { LeadManagementView } from './components/LeadManagementView';
import { LahoreMapView } from './components/LahoreMapView';
import { ImportExportView } from './components/ImportExportView';
import { AutomationJobsView } from './components/AutomationJobsView';
import { SettingsView } from './components/SettingsView';
import { AddDoctorModal } from './components/AddDoctorModal';
import { GeminiChatbotDrawer } from './components/GeminiChatbotDrawer';
import type { DoctorRecord } from './types/domain';

function MainAppRouter() {
  const { authLoading, workspaceReady, activeNav, publicConfig } = useWorkspace();
  const [addDoctorOpen, setAddDoctorOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatPrefilledPrompt, setChatPrefilledPrompt] = useState<string | null>(null);
  const [chatDoctorId, setChatDoctorId] = useState<number | null>(null);

  const handleAskAiForDraft = (doctor: DoctorRecord, subject: string, body: string) => {
    setChatDoctorId(doctor.id);
    setChatPrefilledPrompt(
      `Refine this ${doctor.leadStatus} outreach email for ${doctor.fullName} (${doctor.clinicName}, ${doctor.area}). Make it concise, warm, and persuasive without sounding spammy.\n\nCurrent Subject: ${subject}\n\nCurrent Draft:\n${body}`
    );
    setChatOpen(true);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">
          Initializing LahoreMedProspect workspace...
        </div>
      </div>
    );
  }

  if (!workspaceReady) {
    return <AuthGate />;
  }

  const renderSection = () => {
    switch (activeNav) {
      case 'dashboard':
        return <DashboardView onOpenAddDoctor={() => setAddDoctorOpen(true)} />;
      case 'discover':
        return <DiscoverDoctorsView />;
      case 'doctors':
        return (
          <DoctorDatabaseView
            onOpenAddDoctor={() => setAddDoctorOpen(true)}
            onAskAiForDraft={handleAskAiForDraft}
          />
        );
      case 'clinics':
        return <ClinicsView />;
      case 'website-audit':
        return <WebsiteAuditView />;
      case 'leads':
        return <LeadManagementView onAskAiForDraft={handleAskAiForDraft} />;
      case 'map':
        return <LahoreMapView />;
      case 'import-export':
        return <ImportExportView />;
      case 'automation':
        return <AutomationJobsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView onOpenAddDoctor={() => setAddDoctorOpen(true)} />;
    }
  };

  const content = (
    <>
      <SidebarShell
        onOpenAddDoctor={() => setAddDoctorOpen(true)}
        onOpenAssistant={() => setChatOpen(true)}
      >
        {renderSection()}
      </SidebarShell>
      <AddDoctorModal open={addDoctorOpen} onClose={() => setAddDoctorOpen(false)} />
      <GeminiChatbotDrawer
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        prefilledPrompt={chatPrefilledPrompt}
        prefilledDoctorId={chatDoctorId}
        onClearPrefilledPrompt={() => setChatPrefilledPrompt(null)}
      />
    </>
  );

  if (publicConfig.googleMapsClientKey) {
    return (
      <APIProvider apiKey={publicConfig.googleMapsClientKey} libraries={['marker']}>
        {content}
      </APIProvider>
    );
  }

  return content;
}

export default function App() {
  return (
    <ThemeProvider>
      <WorkspaceProvider>
        <MainAppRouter />
      </WorkspaceProvider>
    </ThemeProvider>
  );
}
