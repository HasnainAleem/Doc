import { relations } from 'drizzle-orm';
import {
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';
import type {
  AutomationConfig,
  ScoringRulesConfig,
} from '../types/domain.ts';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  displayName: text('display_name'),
  role: text('role').notNull().default('admin'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const clinics = pgTable('clinics', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  normalizedName: text('normalized_name').notNull().unique(),
  area: text('area').notNull(),
  address: text('address'),
  phone: text('phone'),
  website: text('website'),
  googleMapsUrl: text('google_maps_url'),
  googlePlaceId: text('google_place_id'),
  lat: doublePrecision('lat'),
  lng: doublePrecision('lng'),
  practiceType: text('practice_type').notNull().default('independent'),
  dataSource: text('data_source').notNull().default('manual'),
  dataOrigin: text('data_origin').notNull().default('sample'),
  lastVerifiedAt: timestamp('last_verified_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const doctors = pgTable('doctors', {
  id: serial('id').primaryKey(),
  fullName: text('full_name').notNull(),
  speciality: text('speciality').notNull(),
  clinicId: integer('clinic_id').references(() => clinics.id, { onDelete: 'set null' }),
  clinicName: text('clinic_name').notNull(),
  practiceType: text('practice_type').notNull().default('independent'),
  doctorStatus: text('doctor_status').notNull().default('Active Practice'),
  pmdcVerified: boolean('pmdc_verified').notNull().default(false),
  availability: text('availability'),
  experienceYears: integer('experience_years'),
  qualifications: text('qualifications'),
  consultationFeePkr: integer('consultation_fee_pkr'),
  rating: doublePrecision('rating'),
  reviewCount: integer('review_count'),
  patientSatisfaction: text('patient_satisfaction'),
  waitTime: text('wait_time'),
  videoConsultation: boolean('video_consultation').notNull().default(false),
  phone: text('phone'),
  email: text('email'),
  website: text('website'),
  address: text('address'),
  area: text('area').notNull(),
  lat: doublePrecision('lat'),
  lng: doublePrecision('lng'),
  googleMapsUrl: text('google_maps_url'),
  googlePlaceId: text('google_place_id'),
  profileUrl: text('profile_url'),
  socialLinks: jsonb('social_links')
    .$type<{ facebook?: string | null; instagram?: string | null; linkedin?: string | null }>()
    .notNull()
    .default({}),
  dataSource: text('data_source').notNull().default('manual'),
  sourceUrl: text('source_url'),
  dataOrigin: text('data_origin').notNull().default('sample'),
  lastVerifiedAt: timestamp('last_verified_at'),
  websiteClassification: text('website_classification').notNull().default('No website found'),
  leadScore: integer('lead_score').notNull().default(0),
  leadPriority: text('lead_priority').notNull().default('Low'),
  leadStatus: text('lead_status').notNull().default('New'),
  opportunityValuePkr: integer('opportunity_value_pkr'),
  nextFollowUpAt: timestamp('next_follow_up_at'),
  notes: text('notes'),
  dedupeKey: text('dedupe_key').notNull().unique(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const websiteAudits = pgTable('website_audits', {
  id: serial('id').primaryKey(),
  doctorId: integer('doctor_id')
    .references(() => doctors.id, { onDelete: 'cascade' })
    .notNull(),
  websiteUrl: text('website_url'),
  classification: text('classification').notNull(),
  httpStatus: integer('http_status'),
  sslValid: boolean('ssl_valid'),
  mobileResponsive: boolean('mobile_responsive'),
  loadTimeMs: integer('load_time_ms'),
  hasAppointmentBooking: boolean('has_appointment_booking'),
  hasDoctorProfile: boolean('has_doctor_profile'),
  hasSeoFundamentals: boolean('has_seo_fundamentals'),
  improvementOpportunities: jsonb('improvement_opportunities').$type<string[]>().notNull().default([]),
  checkedAt: timestamp('checked_at').defaultNow().notNull(),
});

export const leadActivities = pgTable('lead_activities', {
  id: serial('id').primaryKey(),
  doctorId: integer('doctor_id')
    .references(() => doctors.id, { onDelete: 'cascade' })
    .notNull(),
  type: text('type').notNull(),
  summary: text('summary').notNull(),
  details: text('details'),
  followUpDate: timestamp('follow_up_date'),
  createdBy: text('created_by').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const automationJobs = pgTable('automation_jobs', {
  id: serial('id').primaryKey(),
  jobType: text('job_type').notNull(),
  status: text('status').notNull().default('completed'),
  targetArea: text('target_area'),
  targetSpeciality: text('target_speciality'),
  recordsProcessed: integer('records_processed').notNull().default(0),
  recordsAdded: integer('records_added').notNull().default(0),
  recordsUpdated: integer('records_updated').notNull().default(0),
  duplicatesSkipped: integer('duplicates_skipped').notNull().default(0),
  errorCount: integer('error_count').notNull().default(0),
  logs: jsonb('logs').$type<string[]>().notNull().default([]),
  startedAt: timestamp('started_at').defaultNow().notNull(),
  completedAt: timestamp('completed_at'),
});

export const appSettings = pgTable('app_settings', {
  id: serial('id').primaryKey(),
  key: text('key').notNull().unique(),
  scoringRules: jsonb('scoring_rules').$type<ScoringRulesConfig>().notNull(),
  automationConfig: jsonb('automation_config').$type<AutomationConfig>().notNull(),
  updatedBy: text('updated_by'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  actorEmail: text('actor_email').notNull(),
  action: text('action').notNull(),
  entityType: text('entity_type').notNull(),
  entityId: text('entity_id'),
  details: text('details').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const clinicsRelations = relations(clinics, ({ many }) => ({
  doctors: many(doctors),
}));

export const doctorsRelations = relations(doctors, ({ one, many }) => ({
  clinic: one(clinics, {
    fields: [doctors.clinicId],
    references: [clinics.id],
  }),
  audits: many(websiteAudits),
  activities: many(leadActivities),
}));

export const websiteAuditsRelations = relations(websiteAudits, ({ one }) => ({
  doctor: one(doctors, {
    fields: [websiteAudits.doctorId],
    references: [doctors.id],
  }),
}));

export const leadActivitiesRelations = relations(leadActivities, ({ one }) => ({
  doctor: one(doctors, {
    fields: [leadActivities.doctorId],
    references: [doctors.id],
  }),
}));
