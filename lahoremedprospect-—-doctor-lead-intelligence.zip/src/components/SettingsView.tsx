import { useEffect, useState } from 'react';
import { Save, ShieldCheck } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  DEFAULT_AUTOMATION_CONFIG,
  DEFAULT_SCORING_RULES,
  type AutomationConfig,
  type ScoringRulesConfig,
} from '../types/domain';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';

export function SettingsView() {
  const { scoringRules, automationConfig, auditLogs, publicConfig, saveSettings } = useWorkspace();

  const [rules, setRules] = useState<ScoringRulesConfig>(scoringRules);
  const [autoCfg, setAutoCfg] = useState<AutomationConfig>(automationConfig);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setRules(scoringRules);
  }, [scoringRules]);

  useEffect(() => {
    setAutoCfg(automationConfig);
  }, [automationConfig]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await saveSettings(rules, autoCfg);
    setSaving(false);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Configurable Lead Scoring Rules (0–100)</CardTitle>
            <CardDescription>
              Adjust weights for digital readiness gaps. Changing rules automatically recalculates
              all lead scores and priority tiers.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="w-no-web" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                No Official Website Weight
              </label>
              <Input
                id="w-no-web"
                type="number"
                min={0}
                max={100}
                value={rules.noWebsiteWeight}
                onChange={(e) => setRules({ ...rules, noWebsiteWeight: Number(e.target.value) })}
              />
            </div>
            <div>
              <label htmlFor="w-outdated" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Outdated / Broken Website Weight
              </label>
              <Input
                id="w-outdated"
                type="number"
                min={0}
                max={100}
                value={rules.outdatedWebsiteWeight}
                onChange={(e) =>
                  setRules({ ...rules, outdatedWebsiteWeight: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label htmlFor="w-booking" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Missing Appointment Booking
              </label>
              <Input
                id="w-booking"
                type="number"
                min={0}
                max={100}
                value={rules.missingAppointmentWeight}
                onChange={(e) =>
                  setRules({ ...rules, missingAppointmentWeight: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label htmlFor="w-mobile" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Poor Mobile Experience
              </label>
              <Input
                id="w-mobile"
                type="number"
                min={0}
                max={100}
                value={rules.poorMobileWeight}
                onChange={(e) => setRules({ ...rules, poorMobileWeight: Number(e.target.value) })}
              />
            </div>
            <div>
              <label htmlFor="w-indep" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Independent Private Practice
              </label>
              <Input
                id="w-indep"
                type="number"
                min={0}
                max={100}
                value={rules.independentPracticeWeight}
                onChange={(e) =>
                  setRules({ ...rules, independentPracticeWeight: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label htmlFor="w-contact" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Public Contact Available
              </label>
              <Input
                id="w-contact"
                type="number"
                min={0}
                max={100}
                value={rules.publicContactWeight}
                onChange={(e) =>
                  setRules({ ...rules, publicContactWeight: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label htmlFor="t-high" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                High Priority Threshold (≥)
              </label>
              <Input
                id="t-high"
                type="number"
                min={1}
                max={100}
                value={rules.highPriorityThreshold}
                onChange={(e) =>
                  setRules({ ...rules, highPriorityThreshold: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label htmlFor="t-med" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Medium Priority Threshold (≥)
              </label>
              <Input
                id="t-med"
                type="number"
                min={0}
                max={99}
                value={rules.mediumPriorityThreshold}
                onChange={(e) =>
                  setRules({ ...rules, mediumPriorityThreshold: Number(e.target.value) })
                }
              />
            </div>

            <div className="sm:col-span-2 flex justify-between items-center pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                className="text-xs text-slate-600 dark:text-slate-400 hover:underline cursor-pointer"
                onClick={() => setRules(DEFAULT_SCORING_RULES)}
              >
                Reset to Recommended Defaults
              </button>
              <Button type="submit" disabled={saving}>
                <Save className="h-4 w-4" />
                {saving ? 'Saving...' : 'Save & Recalculate'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Automation Rate Limits &amp; Provider Configuration</CardTitle>
            <CardDescription>
              Respects source rate limits, timeouts, and robots.txt policies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="a-rpm" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Requests Per Minute Limit
                </label>
                <Input
                  id="a-rpm"
                  type="number"
                  min={1}
                  max={120}
                  value={autoCfg.requestsPerMinute}
                  onChange={(e) =>
                    setAutoCfg({ ...autoCfg, requestsPerMinute: Number(e.target.value) })
                  }
                />
              </div>
              <div>
                <label htmlFor="a-batch" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Batch Size Per Run
                </label>
                <Input
                  id="a-batch"
                  type="number"
                  min={1}
                  max={50}
                  value={autoCfg.batchSize}
                  onChange={(e) => setAutoCfg({ ...autoCfg, batchSize: Number(e.target.value) })}
                />
              </div>
              <div>
                <label htmlFor="a-timeout" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  HTTP Audit Timeout (ms)
                </label>
                <Input
                  id="a-timeout"
                  type="number"
                  min={1000}
                  max={30000}
                  value={autoCfg.requestTimeoutMs}
                  onChange={(e) =>
                    setAutoCfg({ ...autoCfg, requestTimeoutMs: Number(e.target.value) })
                  }
                />
              </div>
              <div>
                <label htmlFor="a-retries" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Max Retries
                </label>
                <Input
                  id="a-retries"
                  type="number"
                  min={0}
                  max={5}
                  value={autoCfg.maxRetries}
                  onChange={(e) => setAutoCfg({ ...autoCfg, maxRetries: Number(e.target.value) })}
                />
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 pt-1">
              <input
                type="checkbox"
                checked={autoCfg.respectRobotsTxt}
                onChange={(e) => setAutoCfg({ ...autoCfg, respectRobotsTxt: e.target.checked })}
              />
              Enforce robots.txt compliance &amp; public-only data collection rules
            </label>

            <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                Data Provider &amp; Security Readiness
              </div>
              <div>
                PostgreSQL (Cloud SQL): {publicConfig.postgresConfigured ? 'Connected' : 'Pending env'}
              </div>
              <div>
                Google Places &amp; Maps SDK:{' '}
                {publicConfig.googleMapsConfigured
                  ? 'API key configured'
                  : 'Set GOOGLE_MAPS_API_KEY / VITE_GOOGLE_MAPS_API_KEY in environment'}
              </div>
              <div>OpenStreetMap Overpass API: Active (no key required)</div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                className="text-xs text-slate-600 dark:text-slate-400 hover:underline cursor-pointer"
                onClick={() => setAutoCfg(DEFAULT_AUTOMATION_CONFIG)}
              >
                Reset Defaults
              </button>
              <Button type="submit" disabled={saving}>
                <Save className="h-4 w-4" />
                Save Automation Config
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>

      <Card>
        <CardHeader>
          <CardTitle>Security &amp; Compliance Audit Log</CardTitle>
          <CardDescription>
            Records every administrative create, update, delete, import, and discovery action
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-600 dark:text-slate-400">
                <th className="py-2 px-4">Timestamp</th>
                <th className="py-2 px-4">Actor</th>
                <th className="py-2 px-4">Action</th>
                <th className="py-2 px-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {auditLogs.slice(0, 20).map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="py-2 px-4 font-mono tabular-nums text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {log.createdAt.slice(0, 19).replace('T', ' ')}
                  </td>
                  <td className="py-2 px-4 text-slate-700 dark:text-slate-300">{log.actorEmail}</td>
                  <td className="py-2 px-4 font-mono text-slate-900 dark:text-slate-100">{log.action}</td>
                  <td className="py-2 px-4 text-slate-600 dark:text-slate-400">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
