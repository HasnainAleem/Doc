import { useMemo } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, Compass, Globe, Plus } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useWorkspace } from '../context/WorkspaceContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { StatusTag, getPriorityTone, getWebsiteTone } from './ui/status-tag';

const LIGHT_PIE_COLORS = ['#dc2626', '#d97706', '#2563eb', '#16a34a', '#64748b'];
const DARK_PIE_COLORS = ['#ef4444', '#f59e0b', '#3b82f6', '#22c55e', '#94a3b8'];

export function DashboardView({ onOpenAddDoctor }: { onOpenAddDoctor: () => void }) {
  const { isDark } = useTheme();
  const {
    doctors,
    clinics,
    loadingData,
    dataError,
    setActiveNav,
    setSelectedDoctorId,
    seedSampleIntoPostgres,
    user,
  } = useWorkspace();

  const metrics = useMemo(() => {
    const totalDoctors = doctors.length;
    const totalClinics = clinics.length;
    const noWebsite = doctors.filter((d) => !d.website || d.websiteClassification === 'No website found').length;
    const outdatedWebsite = doctors.filter(
      (d) =>
        d.websiteClassification === 'Outdated website' ||
        d.websiteClassification === 'Website unavailable' ||
        d.websiteClassification === 'Poor mobile responsiveness' ||
        d.websiteClassification === 'Slow website'
    ).length;
    const professionalWebsite = doctors.filter(
      (d) => d.websiteClassification === 'Professionally developed website'
    ).length;
    const verifiedPhones = doctors.filter((d) => Boolean(d.phone)).length;
    const verifiedEmails = doctors.filter((d) => Boolean(d.email)).length;

    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const newThisWeek = doctors.filter((d) => new Date(d.createdAt).getTime() >= sevenDaysAgo).length;

    const contacted = doctors.filter((d) =>
      ['Contacted', 'Follow-up required', 'Interested', 'Meeting scheduled', 'Proposal sent', 'Negotiating', 'Converted'].includes(
        d.leadStatus
      )
    ).length;
    const interested = doctors.filter((d) =>
      ['Interested', 'Meeting scheduled', 'Proposal sent', 'Negotiating'].includes(d.leadStatus)
    ).length;
    const converted = doctors.filter((d) => d.leadStatus === 'Converted').length;

    return {
      totalDoctors,
      totalClinics,
      noWebsite,
      outdatedWebsite,
      professionalWebsite,
      verifiedPhones,
      verifiedEmails,
      newThisWeek,
      contacted,
      interested,
      converted,
    };
  }, [clinics.length, doctors]);

  const bySpeciality = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const d of doctors) {
      counts[d.speciality] = (counts[d.speciality] || 0) + 1;
    }
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  }, [doctors]);

  const byArea = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const d of doctors) {
      counts[d.area] = (counts[d.area] || 0) + 1;
    }
    return Object.entries(counts)
      .map(([area, count]) => ({ area, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  }, [doctors]);

  const websiteAvailability = useMemo(() => {
    const buckets: Record<string, number> = {
      'No Website': 0,
      'Outdated / Broken': 0,
      'Needs Optimization': 0,
      Professional: 0,
    };
    for (const d of doctors) {
      if (!d.website || d.websiteClassification === 'No website found') {
        buckets['No Website']++;
      } else if (
        d.websiteClassification === 'Outdated website' ||
        d.websiteClassification === 'Website unavailable'
      ) {
        buckets['Outdated / Broken']++;
      } else if (d.websiteClassification === 'Professionally developed website') {
        buckets['Professional']++;
      } else {
        buckets['Needs Optimization']++;
      }
    }
    return Object.entries(buckets).map(([name, value]) => ({ name, value }));
  }, [doctors]);

  const acquisitionTrends = useMemo(() => {
    const byDay: Record<string, number> = {};
    for (const d of doctors) {
      const day = d.createdAt.slice(0, 10);
      byDay[day] = (byDay[day] || 0) + 1;
    }
    const sorted = Object.entries(byDay).sort(([a], [b]) => a.localeCompare(b));
    let cumulative = 0;
    return sorted.map(([date, added]) => {
      cumulative += added;
      return { date: date.slice(5), added, cumulative };
    });
  }, [doctors]);

  const conversionStages = useMemo(() => {
    const total = doctors.length || 1;
    const stages = [
      { stage: 'Discovered', count: doctors.length },
      {
        stage: 'Contacted',
        count: doctors.filter((d) =>
          ['Contacted', 'Follow-up required', 'Interested', 'Meeting scheduled', 'Proposal sent', 'Negotiating', 'Converted'].includes(
            d.leadStatus
          )
        ).length,
      },
      {
        stage: 'Interested',
        count: doctors.filter((d) =>
          ['Interested', 'Meeting scheduled', 'Proposal sent', 'Negotiating', 'Converted'].includes(
            d.leadStatus
          )
        ).length,
      },
      {
        stage: 'Proposal / Neg.',
        count: doctors.filter((d) =>
          ['Proposal sent', 'Negotiating', 'Converted'].includes(d.leadStatus)
        ).length,
      },
      {
        stage: 'Converted',
        count: doctors.filter((d) => d.leadStatus === 'Converted').length,
      },
    ];
    return stages.map((s) => ({
      ...s,
      rate: Math.round((s.count / total) * 100),
    }));
  }, [doctors]);

  const topOpportunities = useMemo(() => {
    return [...doctors]
      .filter((d) => d.leadStatus !== 'Converted' && d.leadStatus !== 'Not interested')
      .sort((a, b) => b.leadScore - a.leadScore)
      .slice(0, 6);
  }, [doctors]);

  const pieColors = isDark ? DARK_PIE_COLORS : LIGHT_PIE_COLORS;
  const chartColors = {
    grid: isDark ? '#1e293b' : '#e2e8f0',
    axisLabel: isDark ? '#cbd5e1' : '#334155',
    axisMuted: isDark ? '#94a3b8' : '#64748b',
    primaryBar: isDark ? '#3b82f6' : '#1d4ed8',
    secondaryBar: isDark ? '#38bdf8' : '#0f172a',
    funnelBar: isDark ? '#60a5fa' : '#2563eb',
    areaStroke: isDark ? '#60a5fa' : '#1d4ed8',
    areaFill: isDark ? 'rgba(59, 130, 246, 0.22)' : '#dbeafe',
    cursorFill: isDark ? 'rgba(148, 163, 184, 0.12)' : 'rgba(15, 23, 42, 0.05)',
  };

  const tooltipContentStyle = {
    backgroundColor: isDark ? '#0f172a' : '#ffffff',
    borderColor: isDark ? '#334155' : '#e2e8f0',
    borderRadius: '6px',
    color: isDark ? '#f8fafc' : '#0f172a',
    fontSize: '12px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.18)',
  };
  const tooltipLabelStyle = {
    color: isDark ? '#e2e8f0' : '#0f172a',
    fontWeight: 600,
    marginBottom: '2px',
  };
  const tooltipItemStyle = {
    color: isDark ? '#cbd5e1' : '#334155',
  };

  if (loadingData) {
    return (
      <div className="space-y-6" aria-busy="true">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-24 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse"
            />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-72 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
          <div className="h-72 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
        </div>
      </div>
    );
  }

  if (dataError) {
    return (
      <Card>
        <CardContent className="py-10 text-center space-y-3">
          <p className="text-sm font-medium text-red-700 dark:text-red-400">{dataError}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Verify PostgreSQL connectivity and Firebase Authentication session.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (doctors.length === 0) {
    return (
      <Card>
        <CardContent className="py-14 text-center max-w-lg mx-auto space-y-4">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
            Your Lahore Doctor Prospecting Database is Empty
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Start discovering real Lahore doctors and private clinics via Google Places API or
            OpenStreetMap Overpass, import an existing CSV/Excel sheet, or load the development
            sample dataset.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Button type="button" onClick={() => setActiveNav('discover')}>
              <Compass className="h-4 w-4" />
              Discover Doctors
            </Button>
            <Button type="button" variant="outline" onClick={onOpenAddDoctor}>
              <Plus className="h-4 w-4" />
              Add Doctor Manually
            </Button>
            {user && (
              <Button type="button" variant="secondary" onClick={() => void seedSampleIntoPostgres()}>
                Load Sample Dataset
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  const kpis: Array<{ label: string; value: number; sub: string }> = [
    { label: 'Total Doctors', value: metrics.totalDoctors, sub: 'Tracked in Lahore' },
    { label: 'Total Clinics', value: metrics.totalClinics, sub: 'Unique facilities' },
    { label: 'No Website', value: metrics.noWebsite, sub: 'Primary web leads' },
    { label: 'Outdated / Poor Web', value: metrics.outdatedWebsite, sub: 'Redesign targets' },
    { label: 'Professional Web', value: metrics.professionalWebsite, sub: 'SEO / ads upsell' },
    { label: 'Verified Phones', value: metrics.verifiedPhones, sub: 'Public business lines' },
    { label: 'Verified Emails', value: metrics.verifiedEmails, sub: 'Public contact emails' },
    { label: 'New This Week', value: metrics.newThisWeek, sub: 'Last 7 days' },
    { label: 'Leads Contacted', value: metrics.contacted, sub: 'Outreach initiated' },
    { label: 'Interested Prospects', value: metrics.interested, sub: 'Active pipeline' },
    { label: 'Converted Clients', value: metrics.converted, sub: 'Closed deals' },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Metrics Grid */}
      <section aria-label="Key performance metrics">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-3.5">
          {kpis.map((kpi) => (
            <div
              key={kpi.label}
              className="rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 px-4 py-3.5"
            >
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate">
                {kpi.label}
              </div>
              <div className="mt-1.5 text-2xl font-bold text-slate-900 dark:text-slate-100 font-mono tabular-nums">
                {kpi.value}
              </div>
              <div className="mt-1 text-xs text-slate-400 dark:text-slate-500 truncate">
                {kpi.sub}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Primary Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Doctors by Speciality</CardTitle>
            <CardDescription>Distribution across top medical specialities in Lahore</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={bySpeciality} layout="vertical" margin={{ left: 20, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} horizontal={false} />
                <XAxis
                  type="number"
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: chartColors.axisMuted }}
                  stroke={chartColors.grid}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={130}
                  tick={{ fontSize: 11, fill: chartColors.axisLabel }}
                  stroke={chartColors.grid}
                />
                <Tooltip
                  contentStyle={tooltipContentStyle}
                  labelStyle={tooltipLabelStyle}
                  itemStyle={tooltipItemStyle}
                  cursor={{ fill: chartColors.cursorFill }}
                />
                <Bar
                  dataKey="count"
                  name="Doctors"
                  fill={chartColors.primaryBar}
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Doctors by Lahore Area</CardTitle>
            <CardDescription>Geographic concentration across target commercial zones</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byArea} margin={{ left: 0, right: 16, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} vertical={false} />
                <XAxis
                  dataKey="area"
                  tick={{ fontSize: 11, fill: chartColors.axisLabel }}
                  stroke={chartColors.grid}
                  interval={0}
                  angle={-20}
                  textAnchor="end"
                  height={50}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: chartColors.axisMuted }}
                  stroke={chartColors.grid}
                />
                <Tooltip
                  contentStyle={tooltipContentStyle}
                  labelStyle={tooltipLabelStyle}
                  itemStyle={tooltipItemStyle}
                  cursor={{ fill: chartColors.cursorFill }}
                />
                <Bar
                  dataKey="count"
                  name="Doctors"
                  fill={chartColors.secondaryBar}
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Website Availability</CardTitle>
            <CardDescription>Prospect readiness by digital presence</CardDescription>
          </CardHeader>
          <CardContent className="h-64 flex flex-col">
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={websiteAvailability}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={2}
                    stroke={isDark ? '#0f172a' : '#ffffff'}
                    strokeWidth={2}
                  >
                    {websiteAvailability.map((_, i) => (
                      <Cell key={i} fill={pieColors[i % pieColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={tooltipContentStyle}
                    labelStyle={tooltipLabelStyle}
                    itemStyle={tooltipItemStyle}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
              {websiteAvailability.map((entry, idx) => (
                <div key={entry.name} className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 truncate">
                    <span
                      className="h-2.5 w-2.5 rounded-xs shrink-0"
                      style={{ backgroundColor: pieColors[idx % pieColors.length] }}
                    />
                    {entry.name}
                  </span>
                  <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                    {entry.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Lead Acquisition Trends</CardTitle>
            <CardDescription>Cumulative doctors discovered over recent days</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={acquisitionTrends} margin={{ left: -12, right: 12 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: chartColors.axisMuted }}
                  stroke={chartColors.grid}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: chartColors.axisMuted }}
                  stroke={chartColors.grid}
                />
                <Tooltip
                  contentStyle={tooltipContentStyle}
                  labelStyle={tooltipLabelStyle}
                  itemStyle={tooltipItemStyle}
                />
                <Area
                  type="monotone"
                  dataKey="cumulative"
                  name="Cumulative Leads"
                  stroke={chartColors.areaStroke}
                  fill={chartColors.areaFill}
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Lead Conversion Rates</CardTitle>
            <CardDescription>Funnel progression (% of total discovered)</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={conversionStages} margin={{ left: -12, right: 12 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} vertical={false} />
                <XAxis
                  dataKey="stage"
                  tick={{ fontSize: 10, fill: chartColors.axisLabel }}
                  stroke={chartColors.grid}
                />
                <YAxis
                  unit="%"
                  domain={[0, 100]}
                  tick={{ fontSize: 11, fill: chartColors.axisMuted }}
                  stroke={chartColors.grid}
                />
                <Tooltip
                  contentStyle={tooltipContentStyle}
                  labelStyle={tooltipLabelStyle}
                  itemStyle={tooltipItemStyle}
                  cursor={{ fill: chartColors.cursorFill }}
                  formatter={(val) => `${val ?? 0}%`}
                />
                <Bar
                  dataKey="rate"
                  name="Conversion Rate"
                  fill={chartColors.funnelBar}
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Priority Prospects Queue */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>High-Priority Outreach Queue</CardTitle>
            <CardDescription>
              Top scored prospects based on website gaps and contact availability (scoring aids
              prioritization only, not purchase intent).
            </CardDescription>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setActiveNav('doctors')}
          >
            View Full Database
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                <th className="py-2.5 px-4">Doctor</th>
                <th className="py-2.5 px-4">Clinic &amp; Area</th>
                <th className="py-2.5 px-4">Website Status</th>
                <th className="py-2.5 px-4">Public Contact</th>
                <th className="py-2.5 px-4 text-right">Lead Score</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {topOpportunities.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="py-2.5 px-4">
                    <div className="font-medium text-slate-900 dark:text-slate-100">
                      {doc.fullName}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {doc.speciality} · {doc.dataOrigin === 'sample' ? 'Sample' : 'Verified'}
                    </div>
                  </td>
                  <td className="py-2.5 px-4">
                    <div className="text-slate-800 dark:text-slate-200">{doc.clinicName}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {doc.area}, Lahore
                    </div>
                  </td>
                  <td className="py-2.5 px-4">
                    <StatusTag
                      label={doc.websiteClassification}
                      tone={getWebsiteTone(doc.websiteClassification)}
                    />
                  </td>
                  <td className="py-2.5 px-4 text-xs text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                    {doc.phone || 'No phone'}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <div className="inline-flex items-center gap-2">
                      <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {doc.leadScore}
                      </span>
                      <StatusTag
                        label={doc.leadPriority}
                        tone={getPriorityTone(doc.leadPriority)}
                      />
                    </div>
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedDoctorId(doc.id);
                        setActiveNav('doctors');
                      }}
                    >
                      <Globe className="h-3.5 w-3.5" />
                      Inspect
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
