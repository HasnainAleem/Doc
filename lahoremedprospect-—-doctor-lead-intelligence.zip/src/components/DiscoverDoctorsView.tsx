import { useRef, useState } from 'react';
import {
  Check,
  Compass,
  ExternalLink,
  Info,
  Plus,
  RefreshCw,
  Search,
  Square,
  UserCheck,
} from 'lucide-react';
import {
  useWorkspace,
  type DiscoveryCandidate,
  type OladocSyncProgress,
} from '../context/WorkspaceContext';
import { LAHORE_AREAS, MEDICAL_SPECIALITIES } from '../types/domain';
import { formatExperienceLabel } from '../lib/doctorMetadata';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input, Select } from './ui/input';
import { StatusTag, getDoctorStatusTone } from './ui/status-tag';

type DiscoveryProvider = 'oladoc' | 'osm_overpass' | 'google_places';
type SyncScope = 'quick' | 'standard' | 'full';

export function DiscoverDoctorsView() {
  const { discoverProspects, syncOladocLahore, createDoctor, notify, doctors } = useWorkspace();

  const [provider, setProvider] = useState<DiscoveryProvider>('oladoc');
  const [area, setArea] = useState<string>('Gulberg');
  const [speciality, setSpeciality] = useState<string>('Dermatologists');
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [results, setResults] = useState<DiscoveryCandidate[]>([]);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [savingAll, setSavingAll] = useState(false);

  const [syncScope, setSyncScope] = useState<SyncScope>('quick');
  const [syncArea, setSyncArea] = useState<string>('All Lahore');
  const [syncProgress, setSyncProgress] = useState<OladocSyncProgress | null>(null);
  const syncAbortRef = useRef<AbortController | null>(null);

  const existingKeys = new Set(doctors.map((d) => d.dedupeKey));
  const oladocCountInDb = doctors.filter((d) => d.dataSource === 'oladoc.com').length;

  const handleProviderChange = (next: DiscoveryProvider) => {
    setProvider(next);
    if (next !== 'oladoc') {
      if (area === 'All Lahore') setArea('Gulberg');
      if (speciality === 'All') setSpeciality('Dermatologists');
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearching(true);
    setStatusMessage(null);
    setHasSearched(true);
    try {
      const res = await discoverProspects({
        provider,
        area,
        speciality,
        query,
        maxPages: provider === 'oladoc' ? 2 : undefined,
      });
      setResults(res.prospects);
      if (res.message) {
        setStatusMessage(res.message);
      } else if (res.prospects.length === 0) {
        const providerLabel =
          provider === 'oladoc'
            ? 'oladoc.com Lahore Directory'
            : provider === 'google_places'
            ? 'Google Places API'
            : 'OpenStreetMap Overpass';
        setStatusMessage(
          `No public clinic entries returned for ${speciality} in ${area} from ${providerLabel}.`
        );
      }
    } catch (err) {
      setStatusMessage(err instanceof Error ? err.message : 'Discovery search failed');
    } finally {
      setSearching(false);
    }
  };

  const handleStartSync = async () => {
    if (syncProgress?.running) return;
    const controller = new AbortController();
    syncAbortRef.current = controller;
    setSyncProgress({
      running: true,
      speciality: 'Starting Lahore directory crawl...',
      specIndex: 0,
      specTotal: 16,
      page: 0,
      totalClaimedInSpec: 0,
      totalFetched: 0,
      added: 0,
      duplicatesSkipped: 0,
      rateLimited: false,
      error: null,
    });

    try {
      const summary = await syncOladocLahore({
        scope: syncScope,
        area: syncArea,
        signal: controller.signal,
        onProgress: (p) => setSyncProgress(p),
      });
      setSyncProgress((prev) =>
        prev
          ? {
              ...prev,
              running: false,
              speciality: 'Completed',
              totalFetched: summary.totalFetched,
              added: summary.added,
              duplicatesSkipped: summary.duplicatesSkipped,
            }
          : null
      );
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setSyncProgress((prev) =>
          prev
            ? {
                ...prev,
                running: false,
                speciality: 'Paused by admin',
                error: null,
              }
            : null
        );
        notify('info', 'oladoc.com sync stopped cleanly. Fetched doctors remain saved.');
      } else {
        const msg = err instanceof Error ? err.message : 'oladoc.com sync failed';
        setSyncProgress((prev) =>
          prev ? { ...prev, running: false, error: msg } : null
        );
        notify('error', msg);
      }
    } finally {
      syncAbortRef.current = null;
    }
  };

  const handleStopSync = () => {
    syncAbortRef.current?.abort();
  };

  const handleSaveOne = async (candidate: DiscoveryCandidate) => {
    setSavingKey(candidate.dedupeKey);
    const res = await createDoctor({
      fullName: candidate.fullName,
      speciality: candidate.speciality,
      clinicName: candidate.clinicName,
      practiceType: candidate.practiceType,
      doctorStatus: candidate.doctorStatus,
      pmdcVerified: candidate.pmdcVerified,
      availability: candidate.availability ?? null,
      experienceYears: candidate.experienceYears ?? null,
      qualifications: candidate.qualifications ?? null,
      consultationFeePkr: candidate.consultationFeePkr ?? null,
      rating: candidate.rating ?? null,
      reviewCount: candidate.reviewCount ?? null,
      patientSatisfaction: candidate.patientSatisfaction ?? null,
      waitTime: candidate.waitTime ?? null,
      videoConsultation: candidate.videoConsultation,
      phone: candidate.phone,
      email: candidate.email,
      website: candidate.website,
      address: candidate.address,
      area: candidate.area,
      lat: candidate.lat,
      lng: candidate.lng,
      googleMapsUrl: candidate.googleMapsUrl,
      googlePlaceId: candidate.googlePlaceId,
      profileUrl: candidate.profileUrl,
      dataSource: candidate.dataSource,
      sourceUrl: candidate.sourceUrl,
      dataOrigin: candidate.dataOrigin,
      leadStatus: 'New',
      notes: candidate.notes ?? null,
    });
    setSavingKey(null);
    if (!res.ok && res.error) {
      notify('error', res.error);
    }
  };

  const handleSaveAllNew = async () => {
    const newItems = results.filter((r) => !existingKeys.has(r.dedupeKey));
    if (newItems.length === 0) return;
    setSavingAll(true);
    let saved = 0;
    for (const item of newItems) {
      const res = await createDoctor({
        fullName: item.fullName,
        speciality: item.speciality,
        clinicName: item.clinicName,
        practiceType: item.practiceType,
        doctorStatus: item.doctorStatus,
        pmdcVerified: item.pmdcVerified,
        availability: item.availability ?? null,
        experienceYears: item.experienceYears ?? null,
        qualifications: item.qualifications ?? null,
        consultationFeePkr: item.consultationFeePkr ?? null,
        rating: item.rating ?? null,
        reviewCount: item.reviewCount ?? null,
        patientSatisfaction: item.patientSatisfaction ?? null,
        waitTime: item.waitTime ?? null,
        videoConsultation: item.videoConsultation,
        phone: item.phone,
        email: item.email,
        website: item.website,
        address: item.address,
        area: item.area,
        lat: item.lat,
        lng: item.lng,
        googleMapsUrl: item.googleMapsUrl,
        googlePlaceId: item.googlePlaceId,
        profileUrl: item.profileUrl,
        dataSource: item.dataSource,
        sourceUrl: item.sourceUrl,
        dataOrigin: item.dataOrigin,
        leadStatus: 'New',
        notes: item.notes ?? null,
      });
      if (res.ok) saved++;
    }
    setSavingAll(false);
    notify('success', `Saved ${saved} new Lahore doctor records with deduplication.`);
  };

  const unsavedCount = results.filter((r) => !existingKeys.has(r.dedupeKey)).length;
  const pct =
    syncProgress && syncProgress.specTotal > 0
      ? Math.min(100, Math.round((syncProgress.specIndex / syncProgress.specTotal) * 100))
      : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-4 w-4 text-blue-700 dark:text-blue-400" />
              Sync All Lahore Doctors from oladoc.com
            </CardTitle>
            <CardDescription>
              Polite, rate-limited public directory crawler covering all 16 Lahore specialities on
              oladoc.com (~5,000+ specialists). Stores verified profiles and leaves undisclosed direct
              phones strictly as null.
            </CardDescription>
          </div>
          {oladocCountInDb > 0 && (
            <StatusTag label={`${oladocCountInDb.toLocaleString()} oladoc doctors synced`} tone="green" />
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div className="md:col-span-2">
              <label
                htmlFor="oladoc-sync-scope"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Directory Crawl Depth (16 Specialities)
              </label>
              <Select
                id="oladoc-sync-scope"
                value={syncScope}
                disabled={Boolean(syncProgress?.running)}
                onChange={(e) => setSyncScope(e.target.value as SyncScope)}
              >
                <option value="quick">Quick Sync · 2 pages/speciality (~300 doctors)</option>
                <option value="standard">Standard Sync · 6 pages/speciality (~960 doctors)</option>
                <option value="full">Full Lahore Directory · All pages (5,000+ doctors)</option>
              </Select>
            </div>

            <div>
              <label
                htmlFor="oladoc-sync-area"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Area Scope
              </label>
              <Select
                id="oladoc-sync-area"
                value={syncArea}
                disabled={Boolean(syncProgress?.running)}
                onChange={(e) => setSyncArea(e.target.value)}
              >
                <option value="All Lahore">All Lahore (All 15+ Areas)</option>
                {LAHORE_AREAS.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </Select>
            </div>

            <div className="flex gap-2">
              {syncProgress?.running ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleStopSync}
                  className="w-full border-red-300 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950/50"
                >
                  <Square className="h-3.5 w-3.5" />
                  Stop Sync
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={() => void handleStartSync()}
                  className="w-full"
                >
                  <RefreshCw className="h-4 w-4" />
                  Sync Lahore Directory
                </Button>
              )}
            </div>
          </div>

          {syncProgress && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="font-medium text-slate-800 dark:text-slate-200">
                  {syncProgress.running ? (
                    <span>
                      Syncing <span className="text-blue-700 dark:text-blue-400">{syncProgress.speciality}</span>{' '}
                      (Speciality {syncProgress.specIndex}/{syncProgress.specTotal} · Page {syncProgress.page})
                    </span>
                  ) : syncProgress.error ? (
                    <span className="text-red-600 dark:text-red-400">{syncProgress.error}</span>
                  ) : (
                    <span className="text-emerald-700 dark:text-emerald-400">
                      {syncProgress.speciality} — integrated into Doctor Database &amp; Clinics
                    </span>
                  )}
                </div>
                <span className="font-mono tabular-nums text-slate-600 dark:text-slate-400">
                  {syncProgress.running ? `${pct}%` : '100%'}
                </span>
              </div>

              <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    syncProgress.error
                      ? 'bg-red-600'
                      : syncProgress.running
                      ? 'bg-blue-600'
                      : 'bg-emerald-600'
                  }`}
                  style={{ width: `${syncProgress.running ? Math.max(4, pct) : 100}%` }}
                />
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs">
                <div className="rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                  <div className="text-slate-500 dark:text-slate-400">Records Fetched</div>
                  <div className="text-base font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {syncProgress.totalFetched.toLocaleString()}
                  </div>
                </div>
                <div className="rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                  <div className="text-slate-500 dark:text-slate-400">New Leads Added</div>
                  <div className="text-base font-semibold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                    {syncProgress.added.toLocaleString()}
                  </div>
                </div>
                <div className="rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                  <div className="text-slate-500 dark:text-slate-400">Duplicates Skipped</div>
                  <div className="text-base font-semibold font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {syncProgress.duplicatesSkipped.toLocaleString()}
                  </div>
                </div>
              </div>

              {syncProgress.rateLimited && (
                <div className="text-xs text-amber-800 dark:text-amber-300">
                  oladoc.com returned HTTP 429 rate-limit — crawler stopped politely after saving all
                  records retrieved so far.
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Discover Doctors &amp; Private Clinics in Lahore</CardTitle>
          <CardDescription>
            Query oladoc.com, OpenStreetMap Overpass, or Google Places API (New). Missing contact
            details are stored strictly as null and never fabricated.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
            <div>
              <label
                htmlFor="discover-provider"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Data Provider
              </label>
              <Select
                id="discover-provider"
                value={provider}
                onChange={(e) => handleProviderChange(e.target.value as DiscoveryProvider)}
              >
                <option value="oladoc">oladoc.com (Lahore Directory)</option>
                <option value="osm_overpass">OpenStreetMap Overpass API</option>
                <option value="google_places">Google Places API (New)</option>
              </Select>
            </div>

            <div>
              <label
                htmlFor="discover-area"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Lahore Area
              </label>
              <Select
                id="discover-area"
                value={area}
                onChange={(e) => setArea(e.target.value)}
              >
                {provider === 'oladoc' && (
                  <option value="All Lahore">All Lahore (City-wide)</option>
                )}
                {LAHORE_AREAS.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label
                htmlFor="discover-speciality"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Speciality
              </label>
              <Select
                id="discover-speciality"
                value={speciality}
                onChange={(e) => setSpeciality(e.target.value)}
              >
                {provider === 'oladoc' && <option value="All">All Target Specialities</option>}
                {MEDICAL_SPECIALITIES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label
                htmlFor="discover-query"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Doctor / Clinic Filter (Optional)
              </label>
              <Input
                id="discover-query"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g. skin laser, Chughtai..."
              />
            </div>

            <div>
              <Button type="submit" disabled={searching} className="w-full">
                <Search className="h-4 w-4" />
                {searching ? 'Searching...' : 'Run Discovery'}
              </Button>
            </div>
          </form>

          {statusMessage && (
            <div className="mt-4 flex items-start gap-2.5 rounded-md border border-blue-200 bg-blue-50 px-4 py-3 text-xs text-blue-900 dark:border-blue-800 dark:bg-blue-950/50 dark:text-blue-200">
              <Info className="h-4 w-4 shrink-0 mt-0.5 text-blue-700 dark:text-blue-400" />
              <div>{statusMessage}</div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>Discovery Results</CardTitle>
            <CardDescription>
              {results.length > 0
                ? `${results.length} public records retrieved · ${unsavedCount} new`
                : 'Run a targeted query above or sync the full Lahore directory from oladoc.com'}
            </CardDescription>
          </div>
          {unsavedCount > 0 && (
            <Button
              type="button"
              size="sm"
              disabled={savingAll}
              onClick={() => void handleSaveAllNew()}
            >
              <Plus className="h-3.5 w-3.5" />
              {savingAll ? 'Saving...' : `Save All New (${unsavedCount})`}
            </Button>
          )}
        </CardHeader>

        <CardContent className="p-0">
          {!hasSearched ? (
            <div className="py-12 px-6 text-center space-y-2">
              <Compass className="h-8 w-8 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                Ready to Discover Lahore Doctors &amp; Clinics
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                Fetch individual specialities or areas from oladoc.com, OpenStreetMap Overpass, or
                Google Places API (New) while keeping every source URL auditable.
              </p>
            </div>
          ) : searching ? (
            <div className="p-6 space-y-3" aria-busy="true">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-12 rounded bg-slate-100 dark:bg-slate-800 animate-pulse" />
              ))}
            </div>
          ) : results.length === 0 ? (
            <div className="py-10 px-6 text-center text-sm text-slate-500 dark:text-slate-400">
              No records returned for this query. Try another Lahore area or switch providers.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                    <th className="py-2.5 px-2.5">Doctor &amp; Clinic</th>
                    <th className="py-2.5 px-2.5">Area &amp; Address</th>
                    <th className="py-2.5 px-2.5">Status &amp; Availability</th>
                    <th className="py-2.5 px-2.5 whitespace-nowrap">Exp. &amp; Fee</th>
                    <th className="py-2.5 px-2.5">Website</th>
                    <th className="py-2.5 px-2.5">Source</th>
                    <th className="py-2.5 px-2.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {results.map((item) => {
                    const saved = existingKeys.has(item.dedupeKey);
                    const statusLabel =
                      item.doctorStatus || (item.pmdcVerified ? 'PMDC Verified' : 'Active Practice');
                    return (
                      <tr key={item.dedupeKey} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="py-2.5 px-2.5 max-w-[230px]">
                          <div className="font-medium text-slate-900 dark:text-slate-100 truncate">
                            {item.fullName}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {item.speciality} · {item.clinicName}
                          </div>
                          {item.qualifications && (
                            <div className="text-[11px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                              {item.qualifications}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-2.5 max-w-[175px] text-xs">
                          <div className="text-slate-800 dark:text-slate-200 font-medium">{item.area}</div>
                          <div className="text-slate-500 dark:text-slate-400 truncate">
                            {item.address || 'Address not listed'}
                          </div>
                          {item.phone && (
                            <div className="font-mono tabular-nums text-[11px] text-slate-500 dark:text-slate-400">
                              {item.phone}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-2.5 max-w-[180px] text-xs">
                          <div className="flex items-center gap-1 flex-wrap">
                            <StatusTag label={statusLabel} tone={getDoctorStatusTone(statusLabel)} />
                            {item.videoConsultation && <StatusTag label="Video" tone="blue" />}
                          </div>
                          <div className="text-[11px] text-slate-600 dark:text-slate-300 truncate mt-1">
                            {item.availability || (
                              <span className="text-slate-400 dark:text-slate-500">Schedule not listed</span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-2.5 text-xs whitespace-nowrap">
                          <div className="font-medium font-mono tabular-nums text-slate-900 dark:text-slate-100">
                            {formatExperienceLabel(item.experienceYears)}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                            {item.consultationFeePkr
                              ? `Rs. ${item.consultationFeePkr.toLocaleString()}`
                              : 'Fee N/A'}
                            {item.rating ? ` · ${item.rating.toFixed(1)}★` : ''}
                          </div>
                        </td>
                        <td className="py-2.5 px-2.5 text-xs whitespace-nowrap">
                          {item.website ? (
                            <a
                              href={item.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                            >
                              {item.website.replace(/^https?:\/\//, '')}
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          ) : (
                            <StatusTag label="No website" tone="red" />
                          )}
                        </td>
                        <td className="py-2.5 px-2.5 text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                          {item.profileUrl || item.sourceUrl ? (
                            <a
                              href={item.profileUrl || item.sourceUrl || '#'}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                            >
                              {item.dataSource}
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          ) : (
                            item.dataSource
                          )}
                        </td>
                        <td className="py-2.5 px-2.5 text-right whitespace-nowrap">
                          {saved ? (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                              <Check className="h-3.5 w-3.5" />
                              In Database
                            </span>
                          ) : (
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              disabled={savingKey === item.dedupeKey}
                              onClick={() => void handleSaveOne(item)}
                            >
                              <Plus className="h-3.5 w-3.5" />
                              Save Lead
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
