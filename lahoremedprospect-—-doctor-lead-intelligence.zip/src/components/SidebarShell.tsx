import React, { useState } from 'react';
import {
  Activity,
  BarChart3,
  Bot,
  Building2,
  Compass,
  Database,
  FileSpreadsheet,
  Globe,
  Kanban,
  LogOut,
  MapPin,
  Menu,
  Plus,
  Settings,
  X,
} from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import type { NavSection } from '../types/domain';
import { ThemeToggle } from './ThemeToggle';
import { Button } from './ui/button';
import { cn } from '../lib/utils';

const NAV_ITEMS: Array<{ id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
  { id: 'discover', label: 'Discover Doctors', icon: Compass },
  { id: 'doctors', label: 'Doctor Database', icon: Database },
  { id: 'clinics', label: 'Clinics', icon: Building2 },
  { id: 'website-audit', label: 'Website Audit', icon: Globe },
  { id: 'leads', label: 'Lead Management', icon: Kanban },
  { id: 'map', label: 'Lahore Map', icon: MapPin },
  { id: 'import-export', label: 'Import / Export', icon: FileSpreadsheet },
  { id: 'automation', label: 'Automation Jobs', icon: Activity },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function SidebarShell({
  children,
  onOpenAddDoctor,
  onOpenAssistant,
}: {
  children: React.ReactNode;
  onOpenAddDoctor: () => void;
  onOpenAssistant?: () => void;
}) {
  const {
    user,
    isSampleMode,
    activeNav,
    setActiveNav,
    setSelectedDoctorId,
    logout,
    signInWithGoogle,
    seedSampleIntoPostgres,
    doctors,
    mapsQuotaExceeded,
    toast,
    dismissToast,
  } = useWorkspace();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentNavLabel = NAV_ITEMS.find((item) => item.id === activeNav)?.label || 'Dashboard';

  const handleSelectNav = (id: NavSection) => {
    setActiveNav(id);
    setSelectedDoctorId(null);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      {mapsQuotaExceeded && (
        <div className="bg-amber-50 dark:bg-amber-950/90 border-b border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 dark:text-amber-100 hover:text-amber-800 dark:hover:text-amber-300"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      <div className="flex flex-1 min-w-0">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="h-14 flex items-center gap-2.5 px-5 border-b border-slate-200 dark:border-slate-800">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-blue-700 dark:bg-blue-600 text-white shrink-0">
              <Building2 className="h-4 w-4" />
            </div>
            <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap">
              LahoreMedProspect
            </span>
          </div>

          <nav aria-label="Primary navigation" className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectNav(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={cn(
                    'w-full flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer',
                    isActive
                      ? 'bg-blue-50 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                  )}
                >
                  <Icon
                    className={cn(
                      'h-4 w-4 shrink-0',
                      isActive
                        ? 'text-blue-700 dark:text-blue-400'
                        : 'text-slate-400 dark:text-slate-500'
                    )}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="border-t border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="text-xs text-slate-600 dark:text-slate-400">
              <div className="font-medium text-slate-900 dark:text-slate-100 truncate">
                {user ? user.displayName || user.email : 'Development Preview'}
              </div>
              <div className="text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                {user ? 'PostgreSQL Synced' : 'Sample Dataset Mode'} · {doctors.length} records
              </div>
            </div>
            {user ? (
              <div className="flex items-center gap-2">
                {doctors.length === 0 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => void seedSampleIntoPostgres()}
                  >
                    Load Sample
                  </Button>
                )}
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => void logout()}
                  className="text-slate-600 dark:text-slate-300"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Sign out
                </Button>
              </div>
            ) : (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => void signInWithGoogle()}
              >
                Sign in with Google
              </Button>
            )}
          </div>
        </aside>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-900/40 dark:bg-black/70"
              onClick={() => setMobileMenuOpen(false)}
              aria-hidden="true"
            />
            <aside className="relative z-50 w-64 max-w-[80vw] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col h-full">
              <div className="h-14 flex items-center justify-between px-4 border-b border-slate-200 dark:border-slate-800">
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  LahoreMedProspect
                </span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close navigation menu"
                  className="p-1.5 rounded text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <nav aria-label="Mobile navigation" className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeNav === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectNav(item.id)}
                      className={cn(
                        'w-full flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer',
                        isActive
                          ? 'bg-blue-50 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                      )}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </aside>
          </div>
        )}

        {/* Main Viewport */}
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 lg:px-6 flex items-center justify-between gap-4 shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open navigation menu"
                className="lg:hidden p-1.5 rounded-md text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Menu className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-2 text-sm min-w-0">
                <span className="text-slate-500 dark:text-slate-400 hidden sm:inline">
                  Lahore Prospecting
                </span>
                <span className="text-slate-300 dark:text-slate-700 hidden sm:inline">/</span>
                <h1 className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                  {currentNavLabel}
                </h1>
                {isSampleMode && !user && (
                  <span className="hidden md:inline text-xs text-amber-700 dark:text-amber-400 font-medium whitespace-nowrap">
                    · Sample Workspace
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {onOpenAssistant && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  aria-label="Open Outreach Assistant"
                  onClick={onOpenAssistant}
                >
                  <Bot className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                  <span className="hidden sm:inline">Assistant</span>
                </Button>
              )}
              <ThemeToggle />
              <Button
                type="button"
                variant="default"
                size="sm"
                onClick={onOpenAddDoctor}
              >
                <Plus className="h-4 w-4" />
                Add Doctor
              </Button>
            </div>
          </header>

          {toast && (
            <div
              role="status"
              className={cn(
                'mx-4 lg:mx-6 mt-4 flex items-center justify-between gap-4 rounded-md border px-4 py-2.5 text-sm',
                toast.tone === 'error'
                  ? 'border-red-200 bg-red-50 text-red-900 dark:border-red-800 dark:bg-red-950/70 dark:text-red-200'
                  : toast.tone === 'success'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-200'
                  : 'border-blue-200 bg-blue-50 text-blue-900 dark:border-blue-800 dark:bg-blue-950/70 dark:text-blue-200'
              )}
            >
              <span>{toast.message}</span>
              <button
                type="button"
                onClick={dismissToast}
                aria-label="Dismiss notification"
                className="text-current opacity-70 hover:opacity-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">{children}</main>
        </div>
      </div>
    </div>
  );
}
