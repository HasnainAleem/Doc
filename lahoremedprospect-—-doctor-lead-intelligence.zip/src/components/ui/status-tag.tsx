import { cn } from '../../lib/utils';

type Tone = 'neutral' | 'blue' | 'green' | 'amber' | 'red';

const TONE_CLASSES: Record<Tone, string> = {
  neutral:
    'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200',
  blue: 'border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-800/80 dark:bg-blue-950/70 dark:text-blue-300',
  green:
    'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800/80 dark:bg-emerald-950/70 dark:text-emerald-300',
  amber:
    'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-800/80 dark:bg-amber-950/70 dark:text-amber-300',
  red: 'border-red-200 bg-red-50 text-red-800 dark:border-red-800/80 dark:bg-red-950/70 dark:text-red-300',
};

export function StatusTag({
  label,
  tone = 'neutral',
  className,
}: {
  label: string;
  tone?: Tone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded border px-2 py-0.5 text-xs font-medium whitespace-nowrap shrink-0',
        TONE_CLASSES[tone],
        className
      )}
    >
      {label}
    </span>
  );
}

export function getWebsiteTone(classification: string): Tone {
  if (classification === 'Professionally developed website') return 'green';
  if (classification === 'No website found' || classification === 'Website unavailable') return 'red';
  if (classification === 'Outdated website' || classification === 'Poor mobile responsiveness') return 'amber';
  return 'blue';
}

export function getPriorityTone(priority: string): Tone {
  if (priority === 'High') return 'red';
  if (priority === 'Medium') return 'amber';
  return 'neutral';
}

export function getLeadStatusTone(status: string): Tone {
  if (status === 'Converted') return 'green';
  if (status === 'Interested' || status === 'Meeting scheduled' || status === 'Proposal sent' || status === 'Negotiating') {
    return 'blue';
  }
  if (status === 'Follow-up required' || status === 'Contacted') return 'amber';
  if (status === 'Not interested') return 'red';
  return 'neutral';
}

export function getDoctorStatusTone(status: string): Tone {
  if (status === 'PMDC Verified') return 'green';
  if (status === 'Active Practice') return 'blue';
  if (status === 'Online Video Only') return 'amber';
  if (status === 'Temporarily Unavailable') return 'red';
  return 'neutral';
}
