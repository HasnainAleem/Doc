import { useMemo, useState } from 'react';
import {
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
} from '@vis.gl/react-google-maps';
import { ExternalLink, MapPin } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { useTheme } from '../context/ThemeContext';
import { LAHORE_AREAS, MEDICAL_SPECIALITIES, type DoctorRecord } from '../types/domain';
import { LAHORE_AREA_COORDS } from '../lib/sampleData';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select } from './ui/input';
import { StatusTag, getPriorityTone, getWebsiteTone } from './ui/status-tag';

export function LahoreMapView() {
  const { doctors, publicConfig, setSelectedDoctorId, setActiveNav } = useWorkspace();
  const { theme } = useTheme();

  const [specFilter, setSpecFilter] = useState('all');
  const [areaFilter, setAreaFilter] = useState('all');
  const [webFilter, setWebFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [contactFilter, setContactFilter] = useState('all');
  const [activeDoctor, setActiveDoctor] = useState<DoctorRecord | null>(null);

  const mappedDoctors = useMemo(() => {
    return doctors
      .filter((d) => {
        if (specFilter !== 'all' && d.speciality !== specFilter) return false;
        if (areaFilter !== 'all' && d.area !== areaFilter) return false;
        if (priorityFilter !== 'all' && d.leadPriority !== priorityFilter) return false;
        if (webFilter === 'none' && d.website) return false;
        if (webFilter === 'has_website' && !d.website) return false;
        if (contactFilter === 'has_phone' && !d.phone) return false;
        if (contactFilter === 'has_email' && !d.email) return false;
        return true;
      })
      .map((d) => {
        const fallback = LAHORE_AREA_COORDS[d.area] || { lat: 31.5204, lng: 74.3587 };
        return {
          ...d,
          resolvedLat: d.lat ?? fallback.lat,
          resolvedLng: d.lng ?? fallback.lng,
        };
      });
  }, [areaFilter, contactFilter, doctors, priorityFilter, specFilter, webFilter]);

  const pinColorForDoctor = (doc: DoctorRecord) => {
    if (doc.leadPriority === 'High') return { bg: '#dc2626', border: '#991b1b' };
    if (doc.leadPriority === 'Medium') return { bg: '#d97706', border: '#92400e' };
    return { bg: '#1d4ed8', border: '#1e3a8a' };
  };

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader>
          <CardTitle>Interactive Lahore Clinic Map</CardTitle>
          <CardDescription>
            Filter doctors across Lahore zones and click any map marker to inspect clinic profile
            and website status ({mappedDoctors.length} locations shown).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <Select aria-label="Map speciality filter" value={specFilter} onChange={(e) => setSpecFilter(e.target.value)}>
              <option value="all">All Specialities</option>
              {MEDICAL_SPECIALITIES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
            <Select aria-label="Map area filter" value={areaFilter} onChange={(e) => setAreaFilter(e.target.value)}>
              <option value="all">All Lahore Areas</option>
              {LAHORE_AREAS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>
            <Select aria-label="Map website filter" value={webFilter} onChange={(e) => setWebFilter(e.target.value)}>
              <option value="all">All Website States</option>
              <option value="none">No Website</option>
              <option value="has_website">Has Website</option>
            </Select>
            <Select aria-label="Map priority filter" value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
              <option value="all">All Priorities</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </Select>
            <Select aria-label="Map contact filter" value={contactFilter} onChange={(e) => setContactFilter(e.target.value)}>
              <option value="all">Any Contact Info</option>
              <option value="has_phone">Has Public Phone</option>
              <option value="has_email">Has Public Email</option>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 h-[520px] rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-100 dark:bg-slate-950">
              {publicConfig.googleMapsClientKey ? (
                <GoogleMap
                    defaultCenter={{ lat: 31.495, lng: 74.33 }}
                    defaultZoom={12}
                    mapId="DEMO_MAP_ID"
                    colorScheme={theme === 'dark' ? 'DARK' : 'LIGHT'}
                    gestureHandling="greedy"
                    internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                    onClick={() => setActiveDoctor(null)}
                  >
                    {mappedDoctors.map((doc) => {
                      const colors = pinColorForDoctor(doc);
                      return (
                        <AdvancedMarker
                          key={doc.id}
                          position={{ lat: doc.resolvedLat, lng: doc.resolvedLng }}
                          title={`${doc.fullName} — ${doc.clinicName}`}
                          onClick={() => setActiveDoctor(doc)}
                        >
                          <Pin
                            background={colors.bg}
                            borderColor={colors.border}
                            glyphColor="#ffffff"
                          />
                        </AdvancedMarker>
                      );
                    })}

                    {activeDoctor && (
                      <InfoWindow
                        position={{
                          lat:
                            activeDoctor.lat ??
                            (LAHORE_AREA_COORDS[activeDoctor.area]?.lat || 31.5204),
                          lng:
                            activeDoctor.lng ??
                            (LAHORE_AREA_COORDS[activeDoctor.area]?.lng || 74.3587),
                        }}
                        onCloseClick={() => setActiveDoctor(null)}
                      >
                        <div className="p-1 max-w-[240px] space-y-1.5 text-slate-900">
                          <div className="font-semibold text-sm">{activeDoctor.fullName}</div>
                          <div className="text-xs text-slate-600">
                            {activeDoctor.speciality} · {activeDoctor.clinicName}
                          </div>
                          <div className="text-xs text-slate-500">
                            {activeDoctor.area} · Score {activeDoctor.leadScore}
                          </div>
                          <button
                            type="button"
                            className="mt-1 inline-block text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
                            onClick={() => {
                              setSelectedDoctorId(activeDoctor.id);
                              setActiveNav('doctors');
                            }}
                          >
                            Open Full Doctor Profile →
                          </button>
                        </div>
                      </InfoWindow>
                    )}
                  </GoogleMap>
              ) : (
                <div className="h-full flex flex-col justify-between p-6 bg-slate-50 dark:bg-slate-950/80">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                      <MapPin className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                      Lahore Geospatial Distribution (Interactive Coordinate View)
                    </div>
                    <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
                      Google Maps JavaScript API key (`VITE_GOOGLE_MAPS_API_KEY`) is not exposed in
                      this browser bundle. Showing interactive Lahore area pins; click any clinic
                      below or open in Google Maps directly.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 my-4 overflow-y-auto max-h-80 pr-1">
                    {mappedDoctors.map((doc) => (
                      <button
                        key={doc.id}
                        type="button"
                        onClick={() => setActiveDoctor(doc)}
                        className={`text-left rounded border p-2.5 transition-colors cursor-pointer ${
                          activeDoctor?.id === doc.id
                            ? 'border-blue-600 bg-blue-50 dark:border-blue-500 dark:bg-blue-950/60'
                            : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {doc.fullName}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{doc.area}</div>
                        <div className="mt-1 font-mono tabular-nums text-[10px] text-slate-400 dark:text-slate-500">
                          {doc.resolvedLat.toFixed(4)}, {doc.resolvedLng.toFixed(4)}
                        </div>
                      </button>
                    ))}
                  </div>

                  {activeDoctor && (
                    <div className="rounded-md border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-900 p-3 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                          {activeDoctor.fullName}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {activeDoctor.clinicName} · {activeDoctor.area}
                        </div>
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        onClick={() => {
                          setSelectedDoctorId(activeDoctor.id);
                          setActiveNav('doctors');
                        }}
                      >
                        Open Profile
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Right Pin List */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-lg bg-white dark:bg-slate-900 flex flex-col h-[520px]">
              <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300">
                Filtered Clinics ({mappedDoctors.length})
              </div>
              <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                {mappedDoctors.map((doc) => (
                  <div
                    key={doc.id}
                    className={`p-3 space-y-1.5 ${
                      activeDoctor?.id === doc.id
                        ? 'bg-blue-50/70 dark:bg-blue-950/45'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveDoctor(doc)}
                        className="text-sm font-medium text-slate-900 dark:text-slate-100 hover:text-blue-700 dark:hover:text-blue-400 text-left cursor-pointer"
                      >
                        {doc.fullName}
                      </button>
                      <StatusTag label={doc.leadPriority} tone={getPriorityTone(doc.leadPriority)} />
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {doc.speciality} · {doc.clinicName} · {doc.area}
                    </div>
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <StatusTag
                        label={doc.websiteClassification}
                        tone={getWebsiteTone(doc.websiteClassification)}
                      />
                      <div className="flex items-center gap-2">
                        {doc.googleMapsUrl && (
                          <a
                            href={doc.googleMapsUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400"
                            aria-label={`Open ${doc.clinicName} in Google Maps`}
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedDoctorId(doc.id);
                            setActiveNav('doctors');
                          }}
                          className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                        >
                          Profile
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
