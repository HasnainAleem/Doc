import { useState } from 'react';
import { Play } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { LAHORE_AREAS, MEDICAL_SPECIALITIES, type AutomationJobRecord } from '../types/domain';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select } from './ui/input';
import { StatusTag } from './ui/status-tag';

const JOB_TYPES: Array<{
  id: AutomationJobRecord['jobType'];
  label: string;
  description: string;
}> = [
  {
    id: 'sync_oladoc_lahore',
    label: 'Sync All Lahore Doctors (oladoc.com)',
    description: 'Crawl paginated public Lahore doctor listings across target specialities from oladoc.com',
  },
  {
    id: 'discover_clinics',
    label: 'Discover Clinics (OSM Overpass)',
    description: 'Query new public medical clinics in target Lahore area with deduplication',
  },
  {
    id: 'verify_websites',
    label: 'Verify Website Availability',
    description: 'Check HTTP reachability and SSL status across stored clinic domains',
  },
  {
    id: 'batch_website_audit',
    label: 'Batch Website Analysis & Score',
    description: 'Run full mobile, booking, and SEO audit reports and recalculate lead scores',
  },
  {
    id: 'deduplicate_scan',
    label: 'Duplicate Record Scan',
    description: 'Scan normalized name, speciality, clinic, and area keys to prevent duplicates',
  },
  {
    id: 'refresh_records',
    label: 'Refresh Normalization & Timestamps',
    description: 'Re-normalize Pakistani phone numbers, URLs, and update verification dates',
  },
];

export function AutomationJobsView() {
  const { jobs, automationConfig, runAutomationJob } = useWorkspace();
  const [jobType, setJobType] = useState<AutomationJobRecord['jobType']>('verify_websites');
  const [targetArea, setTargetArea] = useState<string>('Gulberg');
  const [targetSpeciality, setTargetSpeciality] = useState<string>('Dermatologists');
  const [running, setRunning] = useState(false);

  const supportsScopeSelect = jobType === 'discover_clinics' || jobType === 'sync_oladoc_lahore';

  const handleJobTypeChange = (next: AutomationJobRecord['jobType']) => {
    setJobType(next);
    if (next === 'sync_oladoc_lahore') {
      setTargetArea('All Lahore Areas');
      setTargetSpeciality('All Specialities');
    } else if (next === 'discover_clinics') {
      if (targetArea === 'All Lahore Areas') setTargetArea('Gulberg');
      if (targetSpeciality === 'All Specialities') setTargetSpeciality('Dermatologists');
    }
  };

  const handleRun = async (e: React.FormEvent) => {
    e.preventDefault();
    setRunning(true);
    await runAutomationJob({
      jobType,
      targetArea: supportsScopeSelect ? targetArea : 'All Lahore Areas',
      targetSpeciality: supportsScopeSelect ? targetSpeciality : 'All Specialities',
    });
    setRunning(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Automated Data Collection &amp; Maintenance Jobs</CardTitle>
          <CardDescription>
            Rate-limited background workflows ({automationConfig.requestsPerMinute} req/min max,{' '}
            {automationConfig.maxRetries} retries, batch limit {automationConfig.batchSize} records)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRun} className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div className="md:col-span-2">
              <label htmlFor="job-type-select" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Job Type
              </label>
              <Select
                id="job-type-select"
                value={jobType}
                onChange={(e) => handleJobTypeChange(e.target.value as AutomationJobRecord['jobType'])}
              >
                {JOB_TYPES.map((j) => (
                  <option key={j.id} value={j.id}>
                    {j.label}
                  </option>
                ))}
              </Select>
            </div>

            {supportsScopeSelect ? (
              <>
                <div>
                  <label htmlFor="job-area" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Target Area
                  </label>
                  <Select
                    id="job-area"
                    value={targetArea}
                    onChange={(e) => setTargetArea(e.target.value)}
                  >
                    {jobType === 'sync_oladoc_lahore' && (
                      <option value="All Lahore Areas">All Lahore Areas</option>
                    )}
                    {LAHORE_AREAS.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <label htmlFor="job-spec" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Speciality
                  </label>
                  <Select
                    id="job-spec"
                    value={targetSpeciality}
                    onChange={(e) => setTargetSpeciality(e.target.value)}
                  >
                    {jobType === 'sync_oladoc_lahore' && (
                      <option value="All Specialities">All Specialities (16)</option>
                    )}
                    {MEDICAL_SPECIALITIES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </Select>
                </div>
              </>
            ) : (
              <div className="md:col-span-2 text-xs text-slate-500 dark:text-slate-400 pb-2">
                {JOB_TYPES.find((j) => j.id === jobType)?.description}
              </div>
            )}

            <div className="md:col-span-4 flex justify-end">
              <Button type="submit" disabled={running}>
                <Play className="h-4 w-4" />
                {running ? 'Running Job...' : 'Execute Automation Job'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Job Execution History &amp; Logs</CardTitle>
          <CardDescription>Audit trail of automated discovery, verification, and deduplication runs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {jobs.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">No automation jobs executed yet.</p>
          ) : (
            jobs.map((job) => (
              <div key={job.id} className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 p-4 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-slate-900 dark:text-slate-100">
                      {JOB_TYPES.find((j) => j.id === job.jobType)?.label || job.jobType}
                    </span>
                    <StatusTag
                      label={job.status}
                      tone={job.status === 'completed' ? 'green' : job.status === 'failed' ? 'red' : 'blue'}
                    />
                  </div>
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    {job.startedAt.slice(0, 19).replace('T', ' ')}
                  </span>
                </div>

                <div className="flex flex-wrap gap-4 text-xs text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                  <span>Processed: {job.recordsProcessed}</span>
                  <span>Added: {job.recordsAdded}</span>
                  <span>Updated: {job.recordsUpdated}</span>
                  <span>Duplicates skipped: {job.duplicatesSkipped}</span>
                  <span>Errors: {job.errorCount}</span>
                </div>

                {job.logs && job.logs.length > 0 && (
                  <ul className="border-t border-slate-100 dark:border-slate-800 pt-2 space-y-1 text-xs text-slate-600 dark:text-slate-400 font-mono">
                    {job.logs.map((line, i) => (
                      <li key={i}>· {line}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
