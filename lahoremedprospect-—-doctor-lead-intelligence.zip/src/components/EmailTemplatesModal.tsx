import { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Copy,
  ExternalLink,
  Mail,
  Plus,
  Search,
  Send,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  EMAIL_TEMPLATE_PLACEHOLDERS,
  PREDEFINED_EMAIL_TEMPLATES,
  buildMailtoHref,
  filterEmailTemplates,
  getTemplatesOrderedForStatus,
  isTemplateRecommendedForStatus,
  loadCustomEmailTemplates,
  renderEmailTemplate,
  saveCustomEmailTemplates,
  type EmailTemplate,
} from '../lib/emailTemplates';
import { LEAD_STATUSES, type DoctorRecord, type LeadStatus } from '../types/domain';
import { Button } from './ui/button';
import { Dialog } from './ui/dialog';
import { Input, Select, Textarea } from './ui/input';
import { StatusTag, getLeadStatusTone } from './ui/status-tag';

interface EmailTemplatesModalProps {
  open: boolean;
  onClose: () => void;
  doctor: DoctorRecord | null;
  initialTab?: 'compose' | 'library';
  onAskAiForDraft?: (doctor: DoctorRecord, subject: string, body: string) => void;
}

export function EmailTemplatesModal({
  open,
  onClose,
  doctor,
  initialTab = 'compose',
  onAskAiForDraft,
}: EmailTemplatesModalProps) {
  const { user, doctors, addActivity, updateDoctor, notify } = useWorkspace();

  const [customTemplates, setCustomTemplates] = useState<EmailTemplate[]>(() =>
    loadCustomEmailTemplates()
  );
  const allTemplates = useMemo(
    () => [...customTemplates, ...PREDEFINED_EMAIL_TEMPLATES],
    [customTemplates]
  );

  const [activeTab, setActiveTab] = useState<'compose' | 'library'>(
    doctor ? initialTab : 'library'
  );
  const [composeDoctorId, setComposeDoctorId] = useState<number | null>(doctor?.id ?? null);

  const activeDoctor = useMemo(() => {
    if (composeDoctorId !== null) {
      return doctors.find((d) => d.id === composeDoctorId) || doctor || doctors[0] || null;
    }
    return doctor || doctors[0] || null;
  }, [composeDoctorId, doctor, doctors]);

  const orderedTemplates = useMemo(() => {
    if (!activeDoctor) return allTemplates;
    return getTemplatesOrderedForStatus(activeDoctor.leadStatus, allTemplates);
  }, [activeDoctor, allTemplates]);

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [markContacted, setMarkContacted] = useState(false);
  const [followUpDate, setFollowUpDate] = useState('');
  const [copied, setCopied] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Library filter & custom template creator state
  const [libQuery, setLibQuery] = useState('');
  const [libStatusFilter, setLibStatusFilter] = useState<LeadStatus | 'all'>('all');
  const [creatingTemplate, setCreatingTemplate] = useState(false);
  const [newTplName, setNewTplName] = useState('');
  const [newTplCategory, setNewTplCategory] = useState('Custom Outreach');
  const [newTplStatus, setNewTplStatus] = useState<LeadStatus>('New');
  const [newTplSubject, setNewTplSubject] = useState('');
  const [newTplBody, setNewTplBody] = useState('');

  const senderName = user?.displayName || user?.email || 'LahoreMedProspect Outreach Team';

  useEffect(() => {
    if (!open) return;
    setActiveTab(doctor ? initialTab : 'library');
    setComposeDoctorId(doctor?.id ?? doctors[0]?.id ?? null);
    setCopied(false);
    setFollowUpDate('');
    setCreatingTemplate(false);
  }, [doctor, doctors, initialTab, open]);

  useEffect(() => {
    if (!open || !activeDoctor) return;
    const recommended = getTemplatesOrderedForStatus(activeDoctor.leadStatus, allTemplates);
    const chosen = recommended[0];
    if (chosen) {
      setSelectedTemplateId(chosen.id);
      const rendered = renderEmailTemplate(chosen, activeDoctor, senderName);
      setSubject(rendered.subject);
      setBody(rendered.body);
    }
    setRecipientEmail(activeDoctor.email || '');
    setMarkContacted(
      activeDoctor.leadStatus === 'New' || activeDoctor.leadStatus === 'Researching'
    );
  }, [activeDoctor?.id, open]);

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplateId(templateId);
    const tpl = allTemplates.find((t) => t.id === templateId);
    if (!tpl || !activeDoctor) return;
    const rendered = renderEmailTemplate(tpl, activeDoctor, senderName);
    setSubject(rendered.subject);
    setBody(rendered.body);
  };

  const handleCopy = async () => {
    const content = `Subject: ${subject}\n\n${body}`;
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      notify('success', 'Personalized outreach email copied to clipboard.');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      notify('error', 'Clipboard access unavailable in this browser.');
    }
  };

  const handleLogOutreach = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDoctor || !subject.trim() || !body.trim()) return;
    setSubmitting(true);
    const cleanEmail = recipientEmail.trim();
    const ok = await addActivity(activeDoctor.id, {
      type: 'email',
      summary: `Outreach email: ${subject.trim()}`,
      details: `${cleanEmail ? `To: ${cleanEmail}\n\n` : ''}${body.trim()}`,
      followUpDate: followUpDate ? new Date(followUpDate).toISOString() : null,
    });

    if (ok) {
      const patch: Parameters<typeof updateDoctor>[1] = {};
      if (markContacted && (activeDoctor.leadStatus === 'New' || activeDoctor.leadStatus === 'Researching')) {
        patch.leadStatus = 'Contacted';
      }
      if (cleanEmail && !activeDoctor.email) {
        patch.email = cleanEmail;
      }
      if (Object.keys(patch).length > 0) {
        await updateDoctor(activeDoctor.id, patch);
      }
      notify('success', `Outreach logged for ${activeDoctor.fullName}.`);
      onClose();
    }
    setSubmitting(false);
  };

  const handleCreateCustomTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTplName.trim() || !newTplSubject.trim() || !newTplBody.trim()) return;
    const nextTpl: EmailTemplate = {
      id: `custom-${Date.now()}`,
      name: newTplName.trim(),
      category: newTplCategory.trim() || 'Custom Outreach',
      targetStatuses: [newTplStatus],
      subject: newTplSubject.trim(),
      body: newTplBody.trim(),
      isCustom: true,
    };
    const updated = [nextTpl, ...customTemplates];
    setCustomTemplates(updated);
    saveCustomEmailTemplates(updated);
    setCreatingTemplate(false);
    setNewTplName('');
    setNewTplSubject('');
    setNewTplBody('');
    notify('success', `Saved custom template "${nextTpl.name}".`);
  };

  const handleDeleteCustomTemplate = (id: string) => {
    const updated = customTemplates.filter((t) => t.id !== id);
    setCustomTemplates(updated);
    saveCustomEmailTemplates(updated);
    notify('info', 'Custom template removed.');
  };

  const filteredLibrary = useMemo(
    () =>
      filterEmailTemplates(allTemplates, {
        query: libQuery,
        statusFilter: libStatusFilter,
      }),
    [allTemplates, libQuery, libStatusFilter]
  );

  const mailtoHref = buildMailtoHref(recipientEmail, subject, body);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="CRM Email Templates & Personalized Outreach"
      description="Select a status-matched template, customize placeholders, and log sent outreach directly to the doctor's CRM timeline."
      maxWidthClass="max-w-4xl"
    >
      <div className="space-y-4">
        {/* Mode Tabs */}
        <div
          role="tablist"
          aria-label="Email outreach views"
          className="flex items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3"
        >
          <div className="flex items-center gap-2">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'compose'}
              onClick={() => setActiveTab('compose')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                activeTab === 'compose'
                  ? 'bg-blue-700 text-white dark:bg-blue-600'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              Personalized Composer
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'library'}
              onClick={() => setActiveTab('library')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                activeTab === 'library'
                  ? 'bg-blue-700 text-white dark:bg-blue-600'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              Template Library ({allTemplates.length})
            </button>
          </div>

          {activeTab === 'library' && (
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => setCreatingTemplate((v) => !v)}
            >
              <Plus className="h-3.5 w-3.5" />
              {creatingTemplate ? 'Close Form' : 'New Template'}
            </Button>
          )}
        </div>

        {activeTab === 'compose' ? (
          activeDoctor ? (
            <form onSubmit={handleLogOutreach} className="space-y-4">
              {/* Target Lead & Status-Recommended Template Picker */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-3.5">
                <div>
                  <label
                    htmlFor="outreach-doctor-select"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Recipient Doctor / Lead
                  </label>
                  <Select
                    id="outreach-doctor-select"
                    value={activeDoctor.id}
                    onChange={(e) => setComposeDoctorId(Number(e.target.value))}
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.fullName} — {d.clinicName} ({d.leadStatus})
                      </option>
                    ))}
                  </Select>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <StatusTag
                      label={activeDoctor.leadStatus}
                      tone={getLeadStatusTone(activeDoctor.leadStatus)}
                    />
                    <span>
                      {activeDoctor.speciality} · {activeDoctor.area}
                    </span>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="outreach-template-select"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Email Template (Matched for "{activeDoctor.leadStatus}")
                  </label>
                  <Select
                    id="outreach-template-select"
                    value={selectedTemplateId}
                    onChange={(e) => handleSelectTemplate(e.target.value)}
                  >
                    {orderedTemplates.map((tpl) => {
                      const rec = isTemplateRecommendedForStatus(tpl, activeDoctor.leadStatus);
                      return (
                        <option key={tpl.id} value={tpl.id}>
                          {rec ? `★ Recommended — ${tpl.name}` : `${tpl.category}: ${tpl.name}`}
                        </option>
                      );
                    })}
                  </Select>
                  <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                    Website gap: {activeDoctor.websiteClassification}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="outreach-recipient-email"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Business Email
                  </label>
                  <Input
                    id="outreach-recipient-email"
                    type="email"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    placeholder="No public email on file — copy for WhatsApp/manual send"
                  />
                </div>
                <div>
                  <label
                    htmlFor="outreach-followup-date"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Schedule Next Follow-Up (Optional)
                  </label>
                  <Input
                    id="outreach-followup-date"
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="outreach-subject"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                >
                  Subject Line *
                </label>
                <Input
                  id="outreach-subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label
                    htmlFor="outreach-body"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                  >
                    Personalized Message Body *
                  </label>
                  {onAskAiForDraft && (
                    <button
                      type="button"
                      onClick={() => onAskAiForDraft(activeDoctor, subject, body)}
                      className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      Refine with Gemini Assistant
                    </button>
                  )}
                </div>
                <Textarea
                  id="outreach-body"
                  className="min-h-[210px] font-sans text-sm leading-relaxed"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  required
                />
              </div>

              {(activeDoctor.leadStatus === 'New' || activeDoctor.leadStatus === 'Researching') && (
                <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={markContacted}
                    onChange={(e) => setMarkContacted(e.target.checked)}
                  />
                  Automatically advance lead status from "{activeDoctor.leadStatus}" to "Contacted"
                </label>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <div className="flex flex-wrap items-center gap-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => void handleCopy()}>
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? 'Copied' : 'Copy Email'}
                  </Button>
                  {mailtoHref && (
                    <a
                      href={mailtoHref}
                      className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 h-8 text-xs font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open Mail App
                    </a>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Button type="button" variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    <Send className="h-3.5 w-3.5" />
                    {submitting ? 'Logging...' : 'Send & Log Outreach'}
                  </Button>
                </div>
              </div>
            </form>
          ) : (
            <div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400">
              No doctor leads are available yet. Add or discover a clinic first.
            </div>
          )
        ) : (
          <div className="space-y-4">
            {creatingTemplate && (
              <form
                onSubmit={handleCreateCustomTemplate}
                className="rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50/40 dark:bg-blue-950/30 p-4 space-y-3"
              >
                <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                  Create Reusable Email Template
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label htmlFor="new-tpl-name" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Template Name *
                    </label>
                    <Input
                      id="new-tpl-name"
                      value={newTplName}
                      onChange={(e) => setNewTplName(e.target.value)}
                      placeholder="e.g. Aesthetic Clinic Ramadan Offer"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="new-tpl-category" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Category
                    </label>
                    <Input
                      id="new-tpl-category"
                      value={newTplCategory}
                      onChange={(e) => setNewTplCategory(e.target.value)}
                    />
                  </div>
                  <div>
                    <label htmlFor="new-tpl-status" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Target Lead Status
                    </label>
                    <Select
                      id="new-tpl-status"
                      value={newTplStatus}
                      onChange={(e) => setNewTplStatus(e.target.value as LeadStatus)}
                    >
                      {LEAD_STATUSES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div>
                  <label htmlFor="new-tpl-subject" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Subject Template *
                  </label>
                  <Input
                    id="new-tpl-subject"
                    value={newTplSubject}
                    onChange={(e) => setNewTplSubject(e.target.value)}
                    placeholder="Patient booking upgrade for {{clinicName}} ({{area}})"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="new-tpl-body" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Message Body Template *
                  </label>
                  <Textarea
                    id="new-tpl-body"
                    value={newTplBody}
                    onChange={(e) => setNewTplBody(e.target.value)}
                    placeholder="Assalam-o-Alaikum {{doctorName}}, ..."
                    required
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                  <span>
                    Available tokens:{' '}
                    {EMAIL_TEMPLATE_PLACEHOLDERS.slice(0, 5)
                      .map((p) => p.token)
                      .join(', ')}
                  </span>
                  <Button type="submit" size="sm">
                    Save Template
                  </Button>
                </div>
              </form>
            )}

            {/* Library Filter Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="relative sm:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
                <Input
                  aria-label="Search email templates"
                  placeholder="Search templates by name, subject, or category..."
                  className="pl-9"
                  value={libQuery}
                  onChange={(e) => setLibQuery(e.target.value)}
                />
              </div>
              <Select
                aria-label="Filter templates by lead status"
                value={libStatusFilter}
                onChange={(e) => setLibStatusFilter(e.target.value as LeadStatus | 'all')}
              >
                <option value="all">All 10 Lead Statuses</option>
                {LEAD_STATUSES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </Select>
            </div>

            {/* Template List */}
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {filteredLibrary.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-700 rounded-md">
                  No email templates match your filter.
                </div>
              ) : (
                filteredLibrary.map((tpl) => (
                  <div
                    key={tpl.id}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 p-3.5 space-y-2"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                            {tpl.name}
                          </h3>
                          <StatusTag label={tpl.category} tone="neutral" />
                          {tpl.targetStatuses.map((st) => (
                            <StatusTag key={st} label={st} tone={getLeadStatusTone(st)} />
                          ))}
                        </div>
                        <p className="mt-1 text-xs font-medium text-slate-700 dark:text-slate-300">
                          Subject: {tpl.subject}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {tpl.isCustom && (
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            aria-label={`Delete template ${tpl.name}`}
                            onClick={() => handleDeleteCustomTemplate(tpl.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5 text-red-600 dark:text-red-400" />
                          </Button>
                        )}
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={!activeDoctor}
                          onClick={() => {
                            if (!activeDoctor) return;
                            setActiveTab('compose');
                            handleSelectTemplate(tpl.id);
                          }}
                        >
                          <Mail className="h-3.5 w-3.5" />
                          Use Template
                        </Button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400 whitespace-pre-line line-clamp-3">
                      {tpl.body}
                    </p>
                  </div>
                ))
              )}
            </div>

            <div className="rounded-md border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-3">
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 mb-1.5">
                Supported Personalization Placeholders
              </div>
              <div className="flex flex-wrap gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                {EMAIL_TEMPLATE_PLACEHOLDERS.map((p) => (
                  <span
                    key={p.token}
                    className="rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 py-0.5 font-mono"
                    title={p.description}
                  >
                    {p.token}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </Dialog>
  );
}
