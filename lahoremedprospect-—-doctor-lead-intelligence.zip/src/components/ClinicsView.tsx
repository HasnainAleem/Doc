import { useMemo, useState } from 'react';
import { Building2, ExternalLink, Search } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { LAHORE_AREAS } from '../types/domain';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input, Select } from './ui/input';
import { StatusTag } from './ui/status-tag';

export function ClinicsView() {
  const { clinics, doctors, setSelectedDoctorId, setActiveNav } = useWorkspace();
  const [search, setSearch] = useState('');
  const [areaFilter, setAreaFilter] = useState('all');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return clinics.filter((c) => {
      if (q && !c.name.toLowerCase().includes(q) && !(c.address || '').toLowerCase().includes(q)) {
        return false;
      }
      if (areaFilter !== 'all' && c.area !== areaFilter) return false;
      return true;
    });
  }, [areaFilter, clinics, search]);

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader>
          <CardTitle>Private Clinics &amp; Medical Centres in Lahore</CardTitle>
          <CardDescription>
            {filtered.length} medical facilities tracked across {LAHORE_AREAS.length} target zones
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="relative sm:col-span-2">
              <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
              <Input
                placeholder="Search clinic name or address..."
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={areaFilter} onChange={(e) => setAreaFilter(e.target.value)}>
              <option value="all">All Lahore Areas</option>
              {LAHORE_AREAS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>
          </div>

          {filtered.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-700 rounded-md">
              No clinics match your filter criteria.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((clinic) => {
                const clinicDocs = doctors.filter(
                  (d) => d.clinicId === clinic.id || d.clinicName === clinic.name
                );
                return (
                  <div
                    key={clinic.id}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 p-4 flex flex-col justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <Building2 className="h-4 w-4 text-blue-700 dark:text-blue-400 shrink-0" />
                          <h3 className="font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                            {clinic.name}
                          </h3>
                        </div>
                        <StatusTag
                          label={`${clinicDocs.length} ${clinicDocs.length === 1 ? 'Doctor' : 'Doctors'}`}
                          tone="blue"
                        />
                      </div>

                      <div className="mt-2 text-xs text-slate-500 dark:text-slate-400 space-y-1">
                        <div>
                          {clinic.area}, Lahore ·{' '}
                          <span className="capitalize">{clinic.practiceType.replace('_', ' ')}</span>
                        </div>
                        <div className="truncate">{clinic.address || 'Address not listed'}</div>
                        <div className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {clinic.phone || 'Phone not listed'}
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 dark:border-slate-800 pt-3 flex items-center justify-between gap-2 text-xs">
                      {clinic.website ? (
                        <a
                          href={clinic.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1 truncate"
                        >
                          {clinic.website.replace(/^https?:\/\//, '')}
                          <ExternalLink className="h-3 w-3 shrink-0" />
                        </a>
                      ) : (
                        <StatusTag label="No Website" tone="red" />
                      )}

                      {clinicDocs[0] && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedDoctorId(clinicDocs[0].id);
                            setActiveNav('doctors');
                          }}
                        >
                          View Lead
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
