import { Building2, Lock, ShieldCheck } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { ThemeToggle } from './ThemeToggle';
import { Button } from './ui/button';

export function AuthGate() {
  const { signInWithGoogle, enterSampleWorkspace } = useWorkspace();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative">
      <div className="absolute top-4 right-4 sm:top-6 sm:right-6">
        <ThemeToggle />
      </div>

      <div className="mx-auto w-full max-w-md">
        <div className="rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-blue-700 dark:bg-blue-600 text-white">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100">
                LahoreMedProspect
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Doctor Lead Generation &amp; Clinic Intelligence
              </p>
            </div>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-6">
            <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Admin Workspace Sign In
            </h2>
            <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Sign in with your authorized Google account to access PostgreSQL persistence, live
              website audits, Google Places discovery, and CRM pipeline management across Lahore.
            </p>

            <div className="mt-6 space-y-3">
              <Button
                type="button"
                variant="default"
                className="w-full h-10"
                onClick={() => void signInWithGoogle()}
              >
                <Lock className="h-4 w-4" />
                Sign in with Google
              </Button>

              <Button
                type="button"
                variant="outline"
                className="w-full h-10"
                onClick={enterSampleWorkspace}
              >
                Explore Development Sample Workspace
              </Button>
            </div>

            <div className="mt-6 border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-start gap-2">
                <ShieldCheck className="h-4 w-4 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
                <span>
                  Public business information only. Never stores patient records, private home
                  addresses, or personal mobile numbers.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
