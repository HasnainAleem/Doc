import { useState } from 'react';
import { Download, FileSpreadsheet, Upload } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  buildDoctorDedupeKey,
  identifyMissingFields,
  inferLahoreArea,
  inferSpeciality,
  normalizePakistanPhone,
  normalizeWebsiteUrl,
} from '../lib/normalization';
import { exportDoctorsToCsv, exportDoctorsToExcel, parseSpreadsheetFile } from '../lib/exportUtils';
import { parseExperienceYears, parseFeePkr } from '../lib/doctorMetadata';
import { DOCTOR_STATUSES, type DoctorStatus, type PracticeType } from '../types/domain';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { StatusTag } from './ui/status-tag';

interface ParsedImportRow {
  fullName: string;
  speciality: string;
  clinicName: string;
  practiceType: PracticeType;
  doctorStatus: DoctorStatus;
  pmdcVerified: boolean;
  availability: string | null;
  experienceYears: number | null;
  qualifications: string | null;
  consultationFeePkr: number | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  area: string;
  dedupeKey: string;
  isDuplicate: boolean;
  missingFields: string[];
}

export function ImportExportView() {
  const { doctors, importDoctorsBatch, notify } = useWorkspace();

  const [parsedRows, setParsedRows] = useState<ParsedImportRow[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const existingKeys = new Set(doctors.map((d) => d.dedupeKey));

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);

    try {
      const raw = await parseSpreadsheetFile(file);
      const seenInBatch = new Set<string>();
      const normalized: ParsedImportRow[] = [];

      for (const row of raw) {
        const fullName =
          row['Doctor Name'] || row['fullName'] || row['Name'] || row['doctor_name'] || '';
        const clinicName =
          row['Clinic Name'] || row['clinicName'] || row['Clinic'] || row['clinic_name'] || '';
        if (!fullName || !clinicName) continue;

        const speciality = inferSpeciality(row['Speciality'] || row['speciality'] || 'General physicians');
        const area = inferLahoreArea(row['Area'] || row['area'] || row['Address'] || 'Gulberg');
        const phone = normalizePakistanPhone(row['Public Phone'] || row['Phone'] || row['phone']);
        const website = normalizeWebsiteUrl(row['Official Website'] || row['Website'] || row['website']);
        const email = (row['Public Email'] || row['Email'] || row['email'] || '').trim() || null;
        const address = (row['Address'] || row['address'] || '').trim() || null;
        const rawDoctorStatus = (row['Doctor Status'] || row['doctorStatus'] || '').trim();
        const doctorStatus: DoctorStatus = (DOCTOR_STATUSES as readonly string[]).includes(
          rawDoctorStatus
        )
          ? (rawDoctorStatus as DoctorStatus)
          : 'Active Practice';
        const pmdcVerified =
          doctorStatus === 'PMDC Verified' ||
          /^(yes|true|1)$/i.test((row['PMDC Verified'] || '').trim());
        const availability = (row['Availability'] || row['availability'] || '').trim() || null;
        const experienceYears = parseExperienceYears(
          row['Experience (Years)'] || row['Experience'] || row['experienceYears']
        );
        const qualifications =
          (row['Qualifications'] || row['qualifications'] || '').trim() || null;
        const consultationFeePkr = parseFeePkr(
          row['Consultation Fee (PKR)'] || row['Fee'] || row['consultationFeePkr']
        );

        const dedupeKey = buildDoctorDedupeKey({
          fullName,
          speciality,
          clinicName,
          area,
        });

        const isDuplicate = existingKeys.has(dedupeKey) || seenInBatch.has(dedupeKey);
        seenInBatch.add(dedupeKey);

        normalized.push({
          fullName,
          speciality,
          clinicName,
          practiceType: 'independent',
          doctorStatus,
          pmdcVerified,
          availability,
          experienceYears,
          qualifications,
          consultationFeePkr,
          phone,
          email,
          website,
          address,
          area,
          dedupeKey,
          isDuplicate,
          missingFields: identifyMissingFields({ phone, email, website, address }),
        });
      }

      setParsedRows(normalized);
      if (normalized.length === 0) {
        notify(
          'info',
          'No valid rows detected. Ensure columns include "Doctor Name" and "Clinic Name".'
        );
      }
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to read spreadsheet file');
    }
  };

  const handleCommitImport = async () => {
    const uniqueRows = parsedRows.filter((r) => !r.isDuplicate);
    if (uniqueRows.length === 0) return;

    setImporting(true);
    try {
      await importDoctorsBatch(
        uniqueRows.map((r) => ({
          fullName: r.fullName,
          speciality: r.speciality,
          clinicName: r.clinicName,
          practiceType: r.practiceType,
          phone: r.phone,
          email: r.email,
          website: r.website,
          address: r.address,
          area: r.area,
          dataSource: fileName ? `Spreadsheet Import (${fileName})` : 'Spreadsheet Import',
          dataOrigin: 'verified',
        }))
      );
      setParsedRows([]);
      setFileName(null);
    } finally {
      setImporting(false);
    }
  };

  const downloadImportTemplate = () => {
    exportDoctorsToCsv(
      [
        {
          id: 1,
          fullName: 'Dr. Nadia Qamar',
          speciality: 'Dermatologists',
          clinicId: null,
          clinicName: 'Qamar Skin Centre',
          practiceType: 'independent',
          doctorStatus: 'PMDC Verified',
          pmdcVerified: true,
          availability: 'Mon–Sat 4:00 PM – 8:00 PM',
          experienceYears: 11,
          qualifications: 'MBBS, FCPS (Dermatology)',
          consultationFeePkr: 3000,
          rating: 4.8,
          reviewCount: 42,
          patientSatisfaction: '95%',
          waitTime: 'Under 15 Min',
          videoConsultation: false,
          phone: '0300-5551234',
          email: null,
          website: null,
          address: 'Block K, Gulberg II, Lahore',
          area: 'Gulberg',
          lat: null,
          lng: null,
          googleMapsUrl: null,
          googlePlaceId: null,
          profileUrl: null,
          socialLinks: {},
          dataSource: 'CSV Template',
          sourceUrl: null,
          dataOrigin: 'sample',
          lastVerifiedAt: null,
          websiteClassification: 'No website found',
          leadScore: 50,
          leadPriority: 'Low',
          leadStatus: 'New',
          opportunityValuePkr: null,
          nextFollowUpAt: null,
          notes: null,
          dedupeKey: '',
          createdAt: '',
          updatedAt: '',
        },
      ],
      'lahore-doctor-import-template.csv'
    );
  };

  const uniqueCount = parsedRows.filter((r) => !r.isDuplicate).length;
  const dupCount = parsedRows.length - uniqueCount;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Import Doctors from CSV or Excel (.xlsx)</CardTitle>
            <CardDescription>
              Automatically normalizes Pakistani phone numbers (+92), website URLs, missing data
              fields, and flags duplicates before saving.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <label className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950/60 px-6 py-8 text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50/30 dark:hover:border-blue-500 dark:hover:bg-blue-950/30 transition-colors">
              <Upload className="h-7 w-7 text-slate-400 dark:text-slate-500 mb-2" />
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                {fileName || 'Select a .csv, .xlsx, or .xls file'}
              </span>
              <span className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Expected headers: Doctor Name, Speciality, Clinic Name, Area, Public Phone,
                Public Email, Official Website, Address
              </span>
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                className="sr-only"
                onChange={handleFileChange}
              />
            </label>

            <div className="flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={downloadImportTemplate}
                className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" />
                Download Sample CSV Template
              </button>
              {parsedRows.length > 0 && (
                <span className="text-slate-600 dark:text-slate-400 font-mono tabular-nums">
                  {uniqueCount} new · {dupCount} duplicates
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Export Doctor &amp; Lead Database</CardTitle>
            <CardDescription>
              Export all {doctors.length} records with normalized phones, lead scores, audit
              classifications, and CRM statuses.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                type="button"
                variant="outline"
                className="h-12"
                onClick={() => exportDoctorsToCsv(doctors)}
              >
                <Download className="h-4 w-4" />
                Export All to CSV
              </Button>
              <Button
                type="button"
                variant="default"
                className="h-12"
                onClick={() => exportDoctorsToExcel(doctors)}
              >
                <Download className="h-4 w-4" />
                Export All to Excel (.xlsx)
              </Button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              All exports include data origin labels (verified vs. sample) and verification
              timestamps for compliance tracking.
            </p>
          </CardContent>
        </Card>
      </div>

      {parsedRows.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle>Import Normalization &amp; Deduplication Preview</CardTitle>
              <CardDescription>
                Review normalized phone formats, missing fields, and duplicate flags before committing
              </CardDescription>
            </div>
            <Button
              type="button"
              disabled={uniqueCount === 0 || importing}
              onClick={() => void handleCommitImport()}
            >
              {importing ? 'Importing...' : `Import ${uniqueCount} Unique Records`}
            </Button>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                  <th className="py-2.5 px-4">Doctor &amp; Clinic</th>
                  <th className="py-2.5 px-4">Normalized Area</th>
                  <th className="py-2.5 px-4">Normalized Phone</th>
                  <th className="py-2.5 px-4">Normalized Website</th>
                  <th className="py-2.5 px-4">Missing Fields</th>
                  <th className="py-2.5 px-4 text-right">Dedupe Check</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {parsedRows.map((row, idx) => (
                  <tr key={idx} className={row.isDuplicate ? 'bg-slate-50/70 dark:bg-slate-950/50 opacity-65' : ''}>
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">{row.fullName}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {row.speciality} · {row.clinicName}
                      </div>
                    </td>
                    <td className="py-2.5 px-4 text-xs text-slate-700 dark:text-slate-300">{row.area}</td>
                    <td className="py-2.5 px-4 font-mono tabular-nums text-xs text-slate-700 dark:text-slate-300">
                      {row.phone || 'null'}
                    </td>
                    <td className="py-2.5 px-4 text-xs text-slate-700 dark:text-slate-300">
                      {row.website || 'null'}
                    </td>
                    <td className="py-2.5 px-4 text-xs text-slate-500 dark:text-slate-400">
                      {row.missingFields.length > 0 ? row.missingFields.join(', ') : 'Complete'}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {row.isDuplicate ? (
                        <StatusTag label="Duplicate" tone="amber" />
                      ) : (
                        <StatusTag label="Ready" tone="green" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
