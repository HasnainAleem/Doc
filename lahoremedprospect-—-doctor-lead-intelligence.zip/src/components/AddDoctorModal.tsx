import { useState } from 'react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  DOCTOR_STATUSES,
  LAHORE_AREAS,
  LEAD_STATUSES,
  MEDICAL_SPECIALITIES,
  type DoctorStatus,
  type LeadStatus,
  type PracticeType,
} from '../types/domain';
import { Button } from './ui/button';
import { Dialog } from './ui/dialog';
import { Input, Select, Textarea } from './ui/input';

export function AddDoctorModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { createDoctor } = useWorkspace();

  const [fullName, setFullName] = useState('');
  const [speciality, setSpeciality] = useState<string>('Dermatologists');
  const [clinicName, setClinicName] = useState('');
  const [practiceType, setPracticeType] = useState<PracticeType>('independent');
  const [doctorStatus, setDoctorStatus] = useState<DoctorStatus>('Active Practice');
  const [availability, setAvailability] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [qualifications, setQualifications] = useState('');
  const [consultationFeePkr, setConsultationFeePkr] = useState('');
  const [area, setArea] = useState<string>('Gulberg');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [leadStatus, setLeadStatus] = useState<LeadStatus>('New');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!fullName.trim() || !clinicName.trim()) {
      setError('Doctor name and clinic name are required.');
      return;
    }

    setSubmitting(true);
    const parsedExp = experienceYears.trim() !== '' ? Number(experienceYears) : null;
    const parsedFee = consultationFeePkr.trim() !== '' ? Number(consultationFeePkr) : null;
    const res = await createDoctor({
      fullName: fullName.trim(),
      speciality,
      clinicName: clinicName.trim(),
      practiceType,
      doctorStatus,
      pmdcVerified: doctorStatus === 'PMDC Verified',
      availability: availability.trim() || null,
      experienceYears: parsedExp !== null && Number.isFinite(parsedExp) ? Math.round(parsedExp) : null,
      qualifications: qualifications.trim() || null,
      consultationFeePkr:
        parsedFee !== null && Number.isFinite(parsedFee) ? Math.round(parsedFee) : null,
      area,
      address: address.trim() || null,
      phone: phone.trim() || null,
      email: email.trim() || null,
      website: website.trim() || null,
      dataSource: 'Manual Admin Entry',
      dataOrigin: 'verified',
      leadStatus,
      notes: notes.trim() || null,
    });
    setSubmitting(false);

    if (!res.ok) {
      setError(res.error || 'Failed to add doctor');
      return;
    }

    setFullName('');
    setClinicName('');
    setDoctorStatus('Active Practice');
    setAvailability('');
    setExperienceYears('');
    setQualifications('');
    setConsultationFeePkr('');
    setAddress('');
    setPhone('');
    setEmail('');
    setWebsite('');
    setNotes('');
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Add Doctor Prospect"
      description="Enter publicly available professional and clinic details. Duplicates are checked automatically."
      maxWidthClass="max-w-2xl"
    >
      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {error && (
          <div className="sm:col-span-2 rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
            {error}
          </div>
        )}

        <div>
          <label htmlFor="add-full-name" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Doctor Full Name *
          </label>
          <Input
            id="add-full-name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Dr. Hamza Siddiqui"
            required
          />
        </div>

        <div>
          <label htmlFor="add-speciality" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Speciality *
          </label>
          <Select id="add-speciality" value={speciality} onChange={(e) => setSpeciality(e.target.value)}>
            {MEDICAL_SPECIALITIES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <label htmlFor="add-clinic-name" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Clinic / Hospital Name *
          </label>
          <Input
            id="add-clinic-name"
            value={clinicName}
            onChange={(e) => setClinicName(e.target.value)}
            placeholder="Gulberg Skin Clinic"
            required
          />
        </div>

        <div>
          <label htmlFor="add-area" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Lahore Area *
          </label>
          <Select id="add-area" value={area} onChange={(e) => setArea(e.target.value)}>
            {LAHORE_AREAS.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <label htmlFor="add-practice-type" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Practice Structure
          </label>
          <Select
            id="add-practice-type"
            value={practiceType}
            onChange={(e) => setPracticeType(e.target.value as PracticeType)}
          >
            <option value="independent">Independent Private Practice</option>
            <option value="clinic_group">Multi-Doctor Clinic Group</option>
            <option value="hospital_affiliated">Hospital Affiliated</option>
          </Select>
        </div>

        <div>
          <label htmlFor="add-lead-status" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Initial Lead Status
          </label>
          <Select
            id="add-lead-status"
            value={leadStatus}
            onChange={(e) => setLeadStatus(e.target.value as LeadStatus)}
          >
            {LEAD_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <label htmlFor="add-doctor-status" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Doctor Status
          </label>
          <Select
            id="add-doctor-status"
            value={doctorStatus}
            onChange={(e) => setDoctorStatus(e.target.value as DoctorStatus)}
          >
            {DOCTOR_STATUSES.map((ds) => (
              <option key={ds} value={ds}>
                {ds}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <label htmlFor="add-experience" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Experience (Years)
          </label>
          <Input
            id="add-experience"
            type="number"
            min={0}
            max={80}
            value={experienceYears}
            onChange={(e) => setExperienceYears(e.target.value)}
            placeholder="e.g. 12"
          />
        </div>

        <div>
          <label htmlFor="add-availability" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Availability / Clinic Hours
          </label>
          <Input
            id="add-availability"
            value={availability}
            onChange={(e) => setAvailability(e.target.value)}
            placeholder="Mon–Sat 5:00 PM – 9:00 PM"
          />
        </div>

        <div>
          <label htmlFor="add-fee" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Consultation Fee (PKR)
          </label>
          <Input
            id="add-fee"
            type="number"
            min={0}
            value={consultationFeePkr}
            onChange={(e) => setConsultationFeePkr(e.target.value)}
            placeholder="3000"
          />
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="add-qualifications" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Qualifications / Degrees
          </label>
          <Input
            id="add-qualifications"
            value={qualifications}
            onChange={(e) => setQualifications(e.target.value)}
            placeholder="MBBS, FCPS"
          />
        </div>

        <div>
          <label htmlFor="add-phone" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Public Business Phone
          </label>
          <Input
            id="add-phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="0300-1234567 or 042-35761234"
          />
        </div>

        <div>
          <label htmlFor="add-email" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Public Business Email
          </label>
          <Input
            id="add-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="info@clinic.pk"
          />
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="add-website" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Official Website (Leave blank if none)
          </label>
          <Input
            id="add-website"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            placeholder="https://clinic.pk"
          />
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="add-address" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Public Business Address
          </label>
          <Input
            id="add-address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Main Boulevard, Gulberg III, Lahore"
          />
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="add-notes" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Notes
          </label>
          <Textarea
            id="add-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Observations on current digital presence..."
          />
        </div>

        <div className="sm:col-span-2 flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? 'Saving...' : 'Save Doctor'}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
