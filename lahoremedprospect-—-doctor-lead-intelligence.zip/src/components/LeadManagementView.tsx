import { useMemo, useState } from 'react';
import { BookOpen, Calendar, Download, Mail } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { LEAD_STATUSES, type DoctorRecord, type LeadStatus } from '../types/domain';
import { exportDoctorsToCsv, exportDoctorsToExcel } from '../lib/exportUtils';
import { formatExperienceLabel } from '../lib/doctorMetadata';
import { EmailTemplatesModal } from './EmailTemplatesModal';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select } from './ui/input';
import {
  StatusTag,
  getDoctorStatusTone,
  getPriorityTone,
  getWebsiteTone,
} from './ui/status-tag';

export function LeadManagementView({
  onAskAiForDraft,
}: {
  onAskAiForDraft?: (doctor: DoctorRecord, subject: string, body: string) => void;
}) {
  const { doctors, updateDoctor, setSelectedDoctorId, setActiveNav } = useWorkspace();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [emailModalTab, setEmailModalTab] = useState<'compose' | 'library'>('compose');
  const [emailTargetDoctor, setEmailTargetDoctor] = useState<DoctorRecord | null>(null);

  const stageCounts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const s of LEAD_STATUSES) map[s] = 0;
    for (const d of doctors) map[d.leadStatus] = (map[d.leadStatus] || 0) + 1;
    return map;
  }, [doctors]);

  const filtered = useMemo(() => {
    return doctors
      .filter((d) => {
        if (statusFilter !== 'all' && d.leadStatus !== statusFilter) return false;
        if (priorityFilter !== 'all' && d.leadPriority !== priorityFilter) return false;
        return true;
      })
      .sort((a, b) => b.leadScore - a.leadScore);
  }, [doctors, priorityFilter, statusFilter]);

  const selectedRecords = useMemo(() => {
    if (selectedIds.length === 0) return filtered;
    const set = new Set(selectedIds);
    return doctors.filter((d) => set.has(d.id));
  }, [doctors, filtered, selectedIds]);

  const totalPipelineValue = useMemo(() => {
    return filtered.reduce((sum, d) => sum + (d.opportunityValuePkr || 0), 0);
  }, [filtered]);

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filtered.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filtered.map((d) => d.id));
    }
  };

  return (
    <div className="space-y-6">
      {/* Pipeline Status Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {LEAD_STATUSES.map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setStatusFilter((prev) => (prev === status ? 'all' : status))}
            className={`text-left rounded-lg border px-3 py-2.5 transition-colors cursor-pointer ${
              statusFilter === status
                ? 'border-blue-600 bg-blue-50 dark:border-blue-500 dark:bg-blue-950/60'
                : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800'
            }`}
          >
            <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{status}</div>
            <div className="mt-1 text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
              {stageCounts[status] || 0}
            </div>
          </button>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-4">
          <div>
            <CardTitle>Lead Management CRM Pipeline</CardTitle>
            <CardDescription>
              {filtered.length} prospects · Pipeline Est.: PKR{' '}
              <span className="font-mono tabular-nums font-medium text-slate-800 dark:text-slate-200">
                {totalPipelineValue.toLocaleString()}
              </span>{' '}
              · Select rows to export targeted campaigns
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select
              aria-label="Filter by lead priority"
              className="w-36"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option value="all">All Priorities</option>
              <option value="High">High (80–100)</option>
              <option value="Medium">Medium (60–79)</option>
              <option value="Low">Low (0–59)</option>
            </Select>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setEmailTargetDoctor(filtered[0] || doctors[0] || null);
                setEmailModalTab('library');
                setEmailModalOpen(true);
              }}
            >
              <BookOpen className="h-3.5 w-3.5" />
              Template Library
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => exportDoctorsToCsv(selectedRecords, 'selected-lahore-leads.csv')}
            >
              <Download className="h-3.5 w-3.5" />
              CSV ({selectedIds.length > 0 ? selectedIds.length : filtered.length})
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => exportDoctorsToExcel(selectedRecords, 'selected-lahore-leads.xlsx')}
            >
              <Download className="h-3.5 w-3.5" />
              Excel ({selectedIds.length > 0 ? selectedIds.length : filtered.length})
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                <th className="py-2.5 px-3 w-10">
                  <input
                    type="checkbox"
                    aria-label="Select all visible leads"
                    checked={filtered.length > 0 && selectedIds.length === filtered.length}
                    onChange={toggleSelectAll}
                  />
                </th>
                <th className="py-2.5 px-3">Prospect</th>
                <th className="py-2.5 px-3">Status &amp; Availability</th>
                <th className="py-2.5 px-3">Website Status</th>
                <th className="py-2.5 px-3">Score / Priority</th>
                <th className="py-2.5 px-3">Lead Status</th>
                <th className="py-2.5 px-3">Est. Deal (PKR)</th>
                <th className="py-2.5 px-3">Next Follow-Up</th>
                <th className="py-2.5 px-3 text-right">CRM</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="py-2.5 px-3">
                    <input
                      type="checkbox"
                      aria-label={`Select ${doc.fullName}`}
                      checked={selectedIds.includes(doc.id)}
                      onChange={() => toggleSelect(doc.id)}
                    />
                  </td>
                  <td className="py-2.5 px-3 max-w-[220px]">
                    <button
                      type="button"
                      className="font-medium text-slate-900 dark:text-slate-100 hover:text-blue-700 dark:hover:text-blue-400 hover:underline text-left cursor-pointer truncate block max-w-full"
                      onClick={() => {
                        setSelectedDoctorId(doc.id);
                        setActiveNav('doctors');
                      }}
                    >
                      {doc.fullName}
                    </button>
                    <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {doc.clinicName} · {doc.area} · {formatExperienceLabel(doc.experienceYears)}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 max-w-[180px] text-xs">
                    <StatusTag
                      label={doc.doctorStatus}
                      tone={getDoctorStatusTone(doc.doctorStatus)}
                    />
                    <div className="text-[11px] text-slate-600 dark:text-slate-300 truncate mt-1">
                      {doc.availability || (
                        <span className="text-slate-400 dark:text-slate-500">Schedule not listed</span>
                      )}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 max-w-[165px]">
                    <StatusTag
                      label={doc.websiteClassification}
                      tone={getWebsiteTone(doc.websiteClassification)}
                    />
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <div className="inline-flex items-center gap-2">
                      <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {doc.leadScore}
                      </span>
                      <StatusTag label={doc.leadPriority} tone={getPriorityTone(doc.leadPriority)} />
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <Select
                      aria-label={`Change lead status for ${doc.fullName}`}
                      className="h-8 text-xs w-40"
                      value={doc.leadStatus}
                      onChange={(e) =>
                        void updateDoctor(doc.id, { leadStatus: e.target.value as LeadStatus })
                      }
                    >
                      {LEAD_STATUSES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </Select>
                  </td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-xs text-slate-700 dark:text-slate-300">
                    {doc.opportunityValuePkr !== null
                      ? doc.opportunityValuePkr.toLocaleString()
                      : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-400">
                    {doc.nextFollowUpAt ? (
                      <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                        <Calendar className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                        {doc.nextFollowUpAt.slice(0, 10)}
                      </span>
                    ) : (
                      <span className="text-slate-400 dark:text-slate-500">Not scheduled</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="inline-flex items-center justify-end gap-1">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        aria-label={`Draft email for ${doc.fullName}`}
                        onClick={() => {
                          setEmailTargetDoctor(doc);
                          setEmailModalTab('compose');
                          setEmailModalOpen(true);
                        }}
                      >
                        <Mail className="h-3.5 w-3.5" />
                        Email
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setSelectedDoctorId(doc.id);
                          setActiveNav('doctors');
                        }}
                      >
                        Open CRM
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <EmailTemplatesModal
        open={emailModalOpen}
        onClose={() => setEmailModalOpen(false)}
        doctor={emailTargetDoctor}
        initialTab={emailModalTab}
        onAskAiForDraft={(targetDoc, subj, msgBody) => {
          setEmailModalOpen(false);
          onAskAiForDraft?.(targetDoc, subj, msgBody);
        }}
      />
    </div>
  );
}
