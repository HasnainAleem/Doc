import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Award,
  Calendar,
  Clock,
  ExternalLink,
  Globe,
  Mail,
  MapPin,
  Phone,
  RefreshCw,
  Save,
  Star,
  Trash2,
  Video,
} from 'lucide-react';
import { AdvancedMarker, Map as GoogleMap, Pin } from '@vis.gl/react-google-maps';
import { useWorkspace } from '../context/WorkspaceContext';
import { useTheme } from '../context/ThemeContext';
import {
  DOCTOR_STATUSES,
  LAHORE_AREAS,
  LEAD_STATUSES,
  MEDICAL_SPECIALITIES,
  type DoctorRecord,
  type DoctorStatus,
  type LeadActivity,
  type LeadStatus,
  type PracticeType,
} from '../types/domain';
import { formatExperienceLabel } from '../lib/doctorMetadata';
import { calculateLeadScore } from '../lib/scoring';
import { EmailTemplatesModal } from './EmailTemplatesModal';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog } from './ui/dialog';
import { Input, Select, Textarea } from './ui/input';
import {
  StatusTag,
  getDoctorStatusTone,
  getLeadStatusTone,
  getPriorityTone,
  getWebsiteTone,
} from './ui/status-tag';

export function DoctorProfileView({
  doctorId,
  onBack,
  onAskAiForDraft,
}: {
  doctorId: number;
  onBack: () => void;
  onAskAiForDraft?: (doctor: DoctorRecord, subject: string, body: string) => void;
}) {
  const {
    doctors,
    scoringRules,
    publicConfig,
    updateDoctor,
    deleteDoctor,
    addActivity,
    runWebsiteAudit,
  } = useWorkspace();
  const { theme } = useTheme();

  const doctor = doctors.find((d) => d.id === doctorId);

  const [editing, setEditing] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [auditing, setAuditing] = useState(false);

  const [fullName, setFullName] = useState('');
  const [speciality, setSpeciality] = useState('');
  const [clinicName, setClinicName] = useState('');
  const [practiceType, setPracticeType] = useState<PracticeType>('independent');
  const [doctorStatus, setDoctorStatus] = useState<DoctorStatus>('Active Practice');
  const [pmdcVerified, setPmdcVerified] = useState(false);
  const [availability, setAvailability] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [qualifications, setQualifications] = useState('');
  const [consultationFeePkr, setConsultationFeePkr] = useState('');
  const [waitTime, setWaitTime] = useState('');
  const [videoConsultation, setVideoConsultation] = useState(false);
  const [area, setArea] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [leadStatus, setLeadStatus] = useState<LeadStatus>('New');
  const [opportunityValuePkr, setOpportunityValuePkr] = useState('');
  const [notes, setNotes] = useState('');

  const [activityType, setActivityType] = useState<LeadActivity['type']>('note');
  const [activitySummary, setActivitySummary] = useState('');
  const [activityDetails, setActivityDetails] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');

  useEffect(() => {
    if (!doctor) return;
    setFullName(doctor.fullName);
    setSpeciality(doctor.speciality);
    setClinicName(doctor.clinicName);
    setPracticeType(doctor.practiceType);
    setDoctorStatus(doctor.doctorStatus || 'Active Practice');
    setPmdcVerified(Boolean(doctor.pmdcVerified));
    setAvailability(doctor.availability || '');
    setExperienceYears(doctor.experienceYears !== null ? String(doctor.experienceYears) : '');
    setQualifications(doctor.qualifications || '');
    setConsultationFeePkr(
      doctor.consultationFeePkr !== null ? String(doctor.consultationFeePkr) : ''
    );
    setWaitTime(doctor.waitTime || '');
    setVideoConsultation(Boolean(doctor.videoConsultation));
    setArea(doctor.area);
    setAddress(doctor.address || '');
    setPhone(doctor.phone || '');
    setEmail(doctor.email || '');
    setWebsite(doctor.website || '');
    setLeadStatus(doctor.leadStatus);
    setOpportunityValuePkr(
      doctor.opportunityValuePkr !== null ? String(doctor.opportunityValuePkr) : ''
    );
    setNotes(doctor.notes || '');
  }, [doctor]);

  if (!doctor) {
    return (
      <Card>
        <CardContent className="py-10 text-center space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-400">Doctor record not found.</p>
          <Button type="button" variant="outline" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
            Back to List
          </Button>
        </CardContent>
      </Card>
    );
  }

  const scoreBreakdown = calculateLeadScore(
    {
      website: doctor.website,
      websiteClassification: doctor.websiteClassification,
      practiceType: doctor.practiceType,
      phone: doctor.phone,
      email: doctor.email,
      latestAudit: doctor.latestAudit,
    },
    scoringRules
  );

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedExp = experienceYears.trim() !== '' ? Number(experienceYears) : null;
    const parsedFee = consultationFeePkr.trim() !== '' ? Number(consultationFeePkr) : null;
    const ok = await updateDoctor(doctor.id, {
      fullName,
      speciality,
      clinicName,
      practiceType,
      doctorStatus,
      pmdcVerified,
      availability: availability.trim() || null,
      experienceYears: parsedExp !== null && Number.isFinite(parsedExp) ? Math.round(parsedExp) : null,
      qualifications: qualifications.trim() || null,
      consultationFeePkr:
        parsedFee !== null && Number.isFinite(parsedFee) ? Math.round(parsedFee) : null,
      waitTime: waitTime.trim() || null,
      videoConsultation,
      area,
      address: address || null,
      phone: phone || null,
      email: email || null,
      website: website || null,
      leadStatus,
      opportunityValuePkr: opportunityValuePkr ? Number(opportunityValuePkr) : null,
      notes: notes || null,
    });
    if (ok) setEditing(false);
  };

  const handleRunAudit = async () => {
    setAuditing(true);
    await runWebsiteAudit(doctor.id, editing ? website : doctor.website);
    setAuditing(false);
  };

  const handleAddActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activitySummary.trim()) return;
    const ok = await addActivity(doctor.id, {
      type: activityType,
      summary: activitySummary.trim(),
      details: activityDetails.trim() || null,
      followUpDate: followUpDate ? new Date(followUpDate).toISOString() : null,
    });
    if (ok) {
      setActivitySummary('');
      setActivityDetails('');
      setFollowUpDate('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Profile Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">{doctor.fullName}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {doctor.speciality} · {doctor.clinicName} · {doctor.area}, Lahore ·{' '}
              {doctor.dataOrigin === 'sample' ? 'Sample Record' : 'Verified Public Record'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <StatusTag label={doctor.doctorStatus} tone={getDoctorStatusTone(doctor.doctorStatus)} />
          <StatusTag
            label={doctor.websiteClassification}
            tone={getWebsiteTone(doctor.websiteClassification)}
          />
          <StatusTag label={doctor.leadStatus} tone={getLeadStatusTone(doctor.leadStatus)} />
          <StatusTag
            label={`Score ${doctor.leadScore} (${doctor.leadPriority})`}
            tone={getPriorityTone(doctor.leadPriority)}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setEmailModalOpen(true)}
          >
            <Mail className="h-3.5 w-3.5" />
            Draft Email
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setEditing((v) => !v)}
          >
            {editing ? 'Cancel Edit' : 'Edit Profile'}
          </Button>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            onClick={() => setConfirmDeleteOpen(true)}
          >
            <Trash2 className="h-3.5 w-3.5" />
            Delete
          </Button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns */}
        <div className="lg:col-span-2 space-y-6">
          {editing ? (
            <Card>
              <CardHeader>
                <CardTitle>Edit Professional &amp; Clinic Record</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSaveProfile} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Full Professional Name
                    </label>
                    <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Speciality
                    </label>
                    <Select value={speciality} onChange={(e) => setSpeciality(e.target.value)}>
                      {MEDICAL_SPECIALITIES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Clinic / Hospital Name
                    </label>
                    <Input value={clinicName} onChange={(e) => setClinicName(e.target.value)} required />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Practice Structure
                    </label>
                    <Select
                      value={practiceType}
                      onChange={(e) => setPracticeType(e.target.value as PracticeType)}
                    >
                      <option value="independent">Independent Private Practice</option>
                      <option value="clinic_group">Multi-Doctor Clinic Group</option>
                      <option value="hospital_affiliated">Hospital Affiliated</option>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Doctor Status
                    </label>
                    <Select
                      aria-label="Doctor status"
                      value={doctorStatus}
                      onChange={(e) => {
                        const next = e.target.value as DoctorStatus;
                        setDoctorStatus(next);
                        if (next === 'PMDC Verified') setPmdcVerified(true);
                      }}
                    >
                      {DOCTOR_STATUSES.map((ds) => (
                        <option key={ds} value={ds}>
                          {ds}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Experience (Years)
                    </label>
                    <Input
                      type="number"
                      min={0}
                      max={80}
                      aria-label="Experience years"
                      value={experienceYears}
                      onChange={(e) => setExperienceYears(e.target.value)}
                      placeholder="e.g. 12"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Availability / Clinic Hours
                    </label>
                    <Input
                      aria-label="Availability and clinic hours"
                      value={availability}
                      onChange={(e) => setAvailability(e.target.value)}
                      placeholder="e.g. Mon–Sat 5:00 PM – 9:00 PM"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Qualifications / Degrees
                    </label>
                    <Input
                      aria-label="Qualifications"
                      value={qualifications}
                      onChange={(e) => setQualifications(e.target.value)}
                      placeholder="MBBS, FCPS"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Consultation Fee (PKR)
                    </label>
                    <Input
                      type="number"
                      min={0}
                      aria-label="Consultation fee PKR"
                      value={consultationFeePkr}
                      onChange={(e) => setConsultationFeePkr(e.target.value)}
                      placeholder="e.g. 3000"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Typical Wait Time
                    </label>
                    <Input
                      aria-label="Wait time"
                      value={waitTime}
                      onChange={(e) => setWaitTime(e.target.value)}
                      placeholder="e.g. Under 15 Min"
                    />
                  </div>
                  <div className="sm:col-span-2 flex flex-wrap items-center gap-6 py-1">
                    <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={pmdcVerified}
                        onChange={(e) => setPmdcVerified(e.target.checked)}
                      />
                      PMDC Verified Credentials
                    </label>
                    <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={videoConsultation}
                        onChange={(e) => setVideoConsultation(e.target.checked)}
                      />
                      Online Video Consultation Available
                    </label>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Lahore Area
                    </label>
                    <Select value={area} onChange={(e) => setArea(e.target.value)}>
                      {LAHORE_AREAS.map((a) => (
                        <option key={a} value={a}>
                          {a}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Lead Status
                    </label>
                    <Select
                      value={leadStatus}
                      onChange={(e) => setLeadStatus(e.target.value as LeadStatus)}
                    >
                      {LEAD_STATUSES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Public Business Phone
                    </label>
                    <Input
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+923001234567"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Public Business Email
                    </label>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="appointments@clinic.pk"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Official Website
                    </label>
                    <Input
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      placeholder="https://clinic.pk"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Est. Opportunity Value (PKR)
                    </label>
                    <Input
                      type="number"
                      min={0}
                      value={opportunityValuePkr}
                      onChange={(e) => setOpportunityValuePkr(e.target.value)}
                      placeholder="150000"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Public Business Address
                    </label>
                    <Input value={address} onChange={(e) => setAddress(e.target.value)} />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Sales Notes
                    </label>
                    <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
                  </div>
                  <div className="sm:col-span-2 flex justify-end gap-2">
                    <Button type="submit">
                      <Save className="h-4 w-4" />
                      Save Changes
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Practice, Availability & Experience Snapshot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <Award className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                    Experience &amp; Degrees
                  </div>
                  <div className="mt-1 text-base font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {formatExperienceLabel(doctor.experienceYears)}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 truncate" title={doctor.qualifications || undefined}>
                    {doctor.qualifications || 'Degrees not listed'}
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <Clock className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                    Clinic Availability
                  </div>
                  <div className="mt-1 text-xs font-semibold text-slate-900 dark:text-slate-100 leading-snug">
                    {doctor.availability || 'Schedule not listed'}
                  </div>
                  <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                    <Video className="h-3 w-3" />
                    {doctor.videoConsultation ? 'Video consultation available' : 'In-clinic visits only'}
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5">
                  <div className="text-xs text-slate-500 dark:text-slate-400">Consultation Fee</div>
                  <div className="mt-1 text-base font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {doctor.consultationFeePkr !== null
                      ? `PKR ${doctor.consultationFeePkr.toLocaleString()}`
                      : 'Not listed'}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    Wait: {doctor.waitTime || 'Not listed'}
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <Star className="h-3.5 w-3.5 text-amber-500" />
                    Patient Rating
                  </div>
                  <div className="mt-1 text-base font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {doctor.rating !== null
                      ? `${doctor.rating.toFixed(1)} / 5`
                      : 'No rating'}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    {doctor.reviewCount ? `${doctor.reviewCount} reviews` : '0 reviews'}
                    {doctor.patientSatisfaction ? ` · ${doctor.patientSatisfaction} satisfied` : ''}
                  </div>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Professional &amp; Public Business Details</CardTitle>
                  <CardDescription>
                    Source: {doctor.dataSource} · Last verified:{' '}
                    {doctor.lastVerifiedAt ? doctor.lastVerifiedAt.slice(0, 10) : 'Unverified'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div className="space-y-3">
                    <div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">Clinic / Facility</div>
                      <div className="font-medium text-slate-900 dark:text-slate-100">{doctor.clinicName}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                        {doctor.practiceType.replace('_', ' ')}
                        {doctor.pmdcVerified ? ' · PMDC Verified' : ''}
                      </div>
                    </div>
                  <div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Public Business Phone</div>
                    <div className="font-mono tabular-nums text-slate-900 dark:text-slate-100 flex items-center gap-1.5 mt-0.5">
                      <Phone className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
                      {doctor.phone || <span className="text-slate-400 dark:text-slate-500">Not listed (null)</span>}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Public Business Email</div>
                    <div className="text-slate-900 dark:text-slate-100 flex items-center gap-1.5 mt-0.5">
                      <Mail className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
                      {doctor.email || <span className="text-slate-400 dark:text-slate-500">Not listed (null)</span>}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Business Address &amp; Area</div>
                    <div className="text-slate-900 dark:text-slate-100 flex items-start gap-1.5 mt-0.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500 mt-0.5 shrink-0" />
                      <span>{doctor.address || `${doctor.area}, Lahore, Pakistan`}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Official Website</div>
                    <div className="mt-0.5">
                      {doctor.website ? (
                        <a
                          href={doctor.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                        >
                          {doctor.website}
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">No official website found</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">External Profiles &amp; Maps</div>
                    <div className="flex flex-wrap gap-3 mt-0.5 text-xs">
                      {doctor.googleMapsUrl && (
                        <a
                          href={doctor.googleMapsUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline"
                        >
                          Google Maps Listing
                        </a>
                      )}
                      {doctor.profileUrl && (
                        <a
                          href={doctor.profileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline"
                        >
                          Professional Profile
                        </a>
                      )}
                      {doctor.socialLinks?.instagram && (
                        <a
                          href={doctor.socialLinks.instagram}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline"
                        >
                          Instagram
                        </a>
                      )}
                      {doctor.socialLinks?.facebook && (
                        <a
                          href={doctor.socialLinks.facebook}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline"
                        >
                          Facebook
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {doctor.notes && (
                  <div className="sm:col-span-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                    <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">Sales Notes</div>
                    <p className="text-sm text-slate-700 dark:text-slate-300">{doctor.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
            </>
          )}

          {/* Website Audit Report Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle>Website Audit Report</CardTitle>
                <CardDescription>
                  Automated technical &amp; conversion readiness analysis
                </CardDescription>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={auditing}
                onClick={() => void handleRunAudit()}
              >
                <RefreshCw className={`h-3.5 w-3.5 ${auditing ? 'animate-spin' : ''}`} />
                {auditing ? 'Auditing...' : 'Run Live Audit'}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-slate-400 dark:text-slate-500" />
                  <span className="text-sm font-medium text-slate-900 dark:text-slate-100">Classification:</span>
                  <StatusTag
                    label={doctor.websiteClassification}
                    tone={getWebsiteTone(doctor.websiteClassification)}
                  />
                </div>
                {doctor.latestAudit?.checkedAt && (
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    Checked {doctor.latestAudit.checkedAt.slice(0, 10)}
                  </span>
                )}
              </div>

              {doctor.latestAudit ? (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">HTTP Status</div>
                      <div className="mt-1 font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.httpStatus ?? 'N/A'}
                      </div>
                    </div>
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">SSL / HTTPS</div>
                      <div className="mt-1 font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.sslValid ? 'Valid HTTPS' : 'Missing / Invalid'}
                      </div>
                    </div>
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">Load Time</div>
                      <div className="mt-1 font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.loadTimeMs !== null
                          ? `${doctor.latestAudit.loadTimeMs} ms`
                          : 'N/A'}
                      </div>
                    </div>
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">Mobile Responsive</div>
                      <div className="mt-1 font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.mobileResponsive ? 'Pass' : 'Fail'}
                      </div>
                    </div>
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">Online Booking</div>
                      <div className="mt-1 font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.hasAppointmentBooking ? 'Detected' : 'Missing'}
                      </div>
                    </div>
                    <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 p-2.5">
                      <div className="text-slate-500 dark:text-slate-400">SEO Fundamentals</div>
                      <div className="mt-1 font-semibold text-slate-900 dark:text-slate-100">
                        {doctor.latestAudit.hasSeoFundamentals ? 'Pass' : 'Incomplete'}
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                      Identified Improvement Opportunities
                    </div>
                    {doctor.latestAudit.improvementOpportunities.length === 0 ? (
                      <p className="text-xs text-emerald-700 dark:text-emerald-400">
                        No critical technical gaps detected. Focus pitch on paid acquisition or
                        content marketing.
                      </p>
                    ) : (
                      <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                        {doctor.latestAudit.improvementOpportunities.map((opp, idx) => (
                          <li key={idx}>{opp}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                </>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {doctor.website
                    ? 'Click "Run Live Audit" to fetch HTTP status, SSL, mobile responsiveness, booking CTA, and SEO signals.'
                    : 'No official website URL is listed. High-value candidate for a custom clinic website + online appointment booking.'}
                </p>
              )}
            </CardContent>
          </Card>

          {/* CRM Activity & Follow-up History */}
          <Card>
            <CardHeader>
              <CardTitle>Sales Notes &amp; Follow-up History</CardTitle>
              <CardDescription>Log outreach calls, WhatsApp messages, meetings, and follow-up dates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <form onSubmit={handleAddActivity} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <Select
                  aria-label="Activity type"
                  value={activityType}
                  onChange={(e) => setActivityType(e.target.value as LeadActivity['type'])}
                >
                  <option value="note">Note</option>
                  <option value="call">Phone Call</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="email">Email</option>
                  <option value="meeting">Meeting</option>
                </Select>
                <Input
                  className="sm:col-span-2"
                  placeholder="Summary (e.g. Sent website proposal to clinic manager)"
                  value={activitySummary}
                  onChange={(e) => setActivitySummary(e.target.value)}
                  required
                />
                <Input
                  type="date"
                  aria-label="Next follow-up date"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                />
                <Textarea
                  className="sm:col-span-3 min-h-[60px]"
                  placeholder="Optional details..."
                  value={activityDetails}
                  onChange={(e) => setActivityDetails(e.target.value)}
                />
                <div className="flex items-end">
                  <Button type="submit" className="w-full">
                    Log Activity
                  </Button>
                </div>
              </form>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
                {(doctor.activities || []).length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">No outreach history recorded yet.</p>
                ) : (
                  (doctor.activities || []).map((act) => (
                    <div key={act.id} className="border-b border-slate-100 dark:border-slate-800 pb-3 last:border-b-0">
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-semibold text-slate-900 dark:text-slate-100 capitalize">
                          {act.type.replace('_', ' ')} · {act.summary}
                        </span>
                        <span className="text-slate-400 dark:text-slate-500 font-mono tabular-nums">
                          {act.createdAt.slice(0, 10)}
                        </span>
                      </div>
                      {act.details && <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">{act.details}</p>}
                      {act.followUpDate && (
                        <div className="mt-1 inline-flex items-center gap-1 text-xs text-blue-700 dark:text-blue-400">
                          <Calendar className="h-3 w-3" />
                          Follow-up: {act.followUpDate.slice(0, 10)}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Lead Score Breakdown & Location Map */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Lead Score Breakdown</CardTitle>
              <CardDescription>
                Prioritization score (0–100); reflects digital service gaps, not purchase intent.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {scoreBreakdown.score}
                  <span className="text-sm font-normal text-slate-400 dark:text-slate-500"> / 100</span>
                </span>
                <StatusTag
                  label={`${scoreBreakdown.priority} Priority`}
                  tone={getPriorityTone(scoreBreakdown.priority)}
                />
              </div>
              <div className="space-y-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                {scoreBreakdown.breakdown.map((item) => (
                  <div key={item.criterion} className="flex items-start justify-between gap-2 text-xs">
                    <div>
                      <div className={item.applied ? 'font-medium text-slate-900 dark:text-slate-100' : 'text-slate-400 dark:text-slate-500'}>
                        {item.criterion}
                      </div>
                      <div className="text-slate-500 dark:text-slate-400">{item.reason}</div>
                    </div>
                    <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300 shrink-0">
                      +{item.points}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Clinic Location</CardTitle>
              <CardDescription>{doctor.area}, Lahore</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {doctor.lat && doctor.lng && publicConfig.googleMapsClientKey ? (
                <div className="h-56 w-full rounded overflow-hidden border border-slate-200 dark:border-slate-800">
                  <GoogleMap
                    defaultCenter={{ lat: doctor.lat, lng: doctor.lng }}
                    defaultZoom={14}
                    mapId="DEMO_MAP_ID"
                    colorScheme={theme === 'dark' ? 'DARK' : 'LIGHT'}
                    internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                    disableDefaultUI
                  >
                    <AdvancedMarker position={{ lat: doctor.lat, lng: doctor.lng }}>
                      <Pin background="#1d4ed8" borderColor="#1e3a8a" glyphColor="#ffffff" />
                    </AdvancedMarker>
                  </GoogleMap>
                </div>
              ) : (
                <div className="rounded border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-4 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                  <div className="font-medium text-slate-800 dark:text-slate-200">Coordinates</div>
                  <div className="font-mono tabular-nums">
                    {doctor.lat && doctor.lng
                      ? `${doctor.lat.toFixed(4)}, ${doctor.lng.toFixed(4)}`
                      : 'Coordinates unavailable'}
                  </div>
                </div>
              )}

              {doctor.googleMapsUrl && (
                <a
                  href={doctor.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline"
                >
                  Open in Google Maps
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog
        open={confirmDeleteOpen}
        onClose={() => setConfirmDeleteOpen(false)}
        title="Delete Doctor Record"
        description="This permanently removes the doctor record, website audit history, and CRM notes."
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-700 dark:text-slate-300">
            Confirm deletion of <strong>{doctor.fullName}</strong> ({doctor.clinicName})?
          </p>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setConfirmDeleteOpen(false)}>
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={async () => {
                const ok = await deleteDoctor(doctor.id);
                if (ok) {
                  setConfirmDeleteOpen(false);
                  onBack();
                }
              }}
            >
              Confirm Delete
            </Button>
          </div>
        </div>
      </Dialog>
      <EmailTemplatesModal
        open={emailModalOpen}
        onClose={() => setEmailModalOpen(false)}
        doctor={doctor}
        initialTab="compose"
        onAskAiForDraft={(targetDoc, subj, msgBody) => {
          setEmailModalOpen(false);
          onAskAiForDraft?.(targetDoc, subj, msgBody);
        }}
      />
    </div>
  );
}
