import { useEffect, useMemo, useState } from 'react';
import { ArrowUpDown, CheckSquare, Download, Eye, Search, X } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  DOCTOR_STATUSES,
  LAHORE_AREAS,
  LEAD_STATUSES,
  MEDICAL_SPECIALITIES,
  type DoctorRecord,
  type LeadPriority,
  type LeadStatus,
} from '../types/domain';
import { exportDoctorsToCsv, exportDoctorsToExcel } from '../lib/exportUtils';
import { toggleIdSelection, toggleSelectAllVisible } from '../lib/bulkActions';
import { formatExperienceLabel } from '../lib/doctorMetadata';
import { DoctorProfileView } from './DoctorProfileView';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input, Select } from './ui/input';
import {
  StatusTag,
  getDoctorStatusTone,
  getLeadStatusTone,
  getPriorityTone,
  getWebsiteTone,
} from './ui/status-tag';

type SortField = 'leadScore' | 'fullName' | 'area' | 'experience' | 'updatedAt';

export function DoctorDatabaseView({
  onOpenAddDoctor,
  onAskAiForDraft,
}: {
  onOpenAddDoctor: () => void;
  onAskAiForDraft?: (doctor: DoctorRecord, subject: string, body: string) => void;
}) {
  const { doctors, selectedDoctorId, setSelectedDoctorId, bulkUpdateDoctors } = useWorkspace();

  const [search, setSearch] = useState('');
  const [areaFilter, setAreaFilter] = useState('all');
  const [specFilter, setSpecFilter] = useState('all');
  const [webFilter, setWebFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [doctorStatusFilter, setDoctorStatusFilter] = useState('all');
  const [availabilityFilter, setAvailabilityFilter] = useState('all');
  const [originFilter, setOriginFilter] = useState('all');
  const [sortField, setSortField] = useState<SortField>('leadScore');
  const [sortAsc, setSortAsc] = useState(false);

  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [bulkStatus, setBulkStatus] = useState<LeadStatus>('Contacted');
  const [bulkPriority, setBulkPriority] = useState<LeadPriority>('High');
  const [bulkSubmitting, setBulkSubmitting] = useState(false);

  useEffect(() => {
    const validIds = new Set(doctors.map((d) => d.id));
    setSelectedIds((prev) => prev.filter((id) => validIds.has(id)));
  }, [doctors]);

  const filteredDoctors = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...doctors]
      .filter((d) => {
        if (
          q &&
          !d.fullName.toLowerCase().includes(q) &&
          !d.clinicName.toLowerCase().includes(q) &&
          !(d.qualifications || '').toLowerCase().includes(q) &&
          !(d.availability || '').toLowerCase().includes(q) &&
          !(d.phone || '').toLowerCase().includes(q) &&
          !(d.email || '').toLowerCase().includes(q)
        ) {
          return false;
        }
        if (areaFilter !== 'all' && d.area !== areaFilter) return false;
        if (specFilter !== 'all' && d.speciality !== specFilter) return false;
        if (statusFilter !== 'all' && d.leadStatus !== statusFilter) return false;
        if (doctorStatusFilter !== 'all' && d.doctorStatus !== doctorStatusFilter) return false;
        if (availabilityFilter === 'listed' && !d.availability) return false;
        if (availabilityFilter === 'video' && !d.videoConsultation) return false;
        if (availabilityFilter === 'not_listed' && d.availability) return false;
        if (originFilter !== 'all' && d.dataOrigin !== originFilter) return false;
        if (webFilter === 'none' && d.website) return false;
        if (webFilter === 'has_website' && !d.website) return false;
        if (
          webFilter === 'outdated' &&
          !['Outdated website', 'Website unavailable', 'Poor mobile responsiveness', 'Slow website'].includes(
            d.websiteClassification
          )
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'leadScore') cmp = a.leadScore - b.leadScore;
        else if (sortField === 'fullName') cmp = a.fullName.localeCompare(b.fullName);
        else if (sortField === 'area') cmp = a.area.localeCompare(b.area);
        else if (sortField === 'experience') cmp = (a.experienceYears ?? -1) - (b.experienceYears ?? -1);
        else cmp = a.updatedAt.localeCompare(b.updatedAt);
        return sortAsc ? cmp : -cmp;
      });
  }, [
    areaFilter,
    availabilityFilter,
    doctorStatusFilter,
    doctors,
    originFilter,
    search,
    sortAsc,
    sortField,
    specFilter,
    statusFilter,
    webFilter,
  ]);

  const visibleIds = useMemo(() => filteredDoctors.map((d) => d.id), [filteredDoctors]);
  const allVisibleSelected =
    visibleIds.length > 0 && visibleIds.every((id) => selectedIds.includes(id));

  const selectedRecords = useMemo(() => {
    const set = new Set(selectedIds);
    return doctors.filter((d) => set.has(d.id));
  }, [doctors, selectedIds]);

  if (selectedDoctorId !== null) {
    return (
      <DoctorProfileView
        doctorId={selectedDoctorId}
        onBack={() => setSelectedDoctorId(null)}
        onAskAiForDraft={onAskAiForDraft}
      />
    );
  }

  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortAsc((v) => !v);
    else {
      setSortField(field);
      setSortAsc(field === 'fullName' || field === 'area');
    }
  };

  const handleBulkStatus = async () => {
    if (selectedIds.length === 0) return;
    setBulkSubmitting(true);
    await bulkUpdateDoctors(selectedIds, { leadStatus: bulkStatus });
    setBulkSubmitting(false);
  };

  const handleBulkPriority = async () => {
    if (selectedIds.length === 0) return;
    setBulkSubmitting(true);
    await bulkUpdateDoctors(selectedIds, { leadPriority: bulkPriority });
    setBulkSubmitting(false);
  };

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-4">
          <div>
            <CardTitle>Doctor Database</CardTitle>
            <CardDescription>
              {filteredDoctors.length} of {doctors.length} records shown · Select rows for bulk
              actions or click any doctor to inspect profile
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => exportDoctorsToCsv(filteredDoctors)}
            >
              <Download className="h-3.5 w-3.5" />
              Export CSV
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => exportDoctorsToExcel(filteredDoctors)}
            >
              <Download className="h-3.5 w-3.5" />
              Export Excel
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative lg:col-span-2">
              <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
              <Input
                aria-label="Search doctors, clinics, or contacts"
                placeholder="Search doctor, clinic, degrees, schedule, phone..."
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <Select aria-label="Filter by speciality" value={specFilter} onChange={(e) => setSpecFilter(e.target.value)}>
              <option value="all">All Specialities</option>
              {MEDICAL_SPECIALITIES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>

            <Select aria-label="Filter by Lahore area" value={areaFilter} onChange={(e) => setAreaFilter(e.target.value)}>
              <option value="all">All Lahore Areas</option>
              {LAHORE_AREAS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>

            <Select
              aria-label="Filter by doctor status"
              value={doctorStatusFilter}
              onChange={(e) => setDoctorStatusFilter(e.target.value)}
            >
              <option value="all">All Doctor Statuses</option>
              {DOCTOR_STATUSES.map((ds) => (
                <option key={ds} value={ds}>
                  {ds}
                </option>
              ))}
            </Select>

            <Select
              aria-label="Filter by availability"
              value={availabilityFilter}
              onChange={(e) => setAvailabilityFilter(e.target.value)}
            >
              <option value="all">All Availability</option>
              <option value="listed">Schedule / Slots Listed</option>
              <option value="video">Video Consultation Available</option>
              <option value="not_listed">Availability Not Listed</option>
            </Select>

            <Select aria-label="Filter by website availability" value={webFilter} onChange={(e) => setWebFilter(e.target.value)}>
              <option value="all">All Website States</option>
              <option value="none">No Website</option>
              <option value="outdated">Outdated / Poor</option>
              <option value="has_website">Has Website</option>
            </Select>

            <Select aria-label="Filter by lead status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="all">All Lead Statuses</option>
              {LEAD_STATUSES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </Select>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <span>Origin:</span>
              {(['all', 'verified', 'sample'] as const).map((orig) => (
                <button
                  key={orig}
                  type="button"
                  onClick={() => setOriginFilter(orig)}
                  className={`px-2.5 py-1 rounded border text-xs font-medium capitalize cursor-pointer ${
                    originFilter === orig
                      ? 'border-blue-600 bg-blue-50 text-blue-800 dark:border-blue-500 dark:bg-blue-950/60 dark:text-blue-300'
                      : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                  }`}
                >
                  {orig === 'all' ? 'All Records' : orig}
                </button>
              ))}
            </div>
            {(search ||
              areaFilter !== 'all' ||
              specFilter !== 'all' ||
              webFilter !== 'all' ||
              statusFilter !== 'all' ||
              doctorStatusFilter !== 'all' ||
              availabilityFilter !== 'all' ||
              originFilter !== 'all') && (
              <button
                type="button"
                className="text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                onClick={() => {
                  setSearch('');
                  setAreaFilter('all');
                  setSpecFilter('all');
                  setWebFilter('all');
                  setStatusFilter('all');
                  setDoctorStatusFilter('all');
                  setAvailabilityFilter('all');
                  setOriginFilter('all');
                }}
              >
                Reset filters
              </button>
            )}
          </div>

          {/* Bulk Action Toolbar */}
          {selectedIds.length > 0 && (
            <div
              role="region"
              aria-label="Bulk actions toolbar"
              className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-blue-200 bg-blue-50/70 px-3.5 py-2.5 dark:border-blue-800 dark:bg-blue-950/50"
            >
              <div className="flex items-center gap-2.5">
                <CheckSquare className="h-4 w-4 text-blue-700 dark:text-blue-400 shrink-0" />
                <span className="text-xs font-semibold text-blue-950 dark:text-blue-100 font-mono tabular-nums">
                  {selectedIds.length} selected
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedIds([])}
                  className="inline-flex items-center gap-1 text-xs text-blue-800 dark:text-blue-300 hover:underline cursor-pointer"
                >
                  <X className="h-3 w-3" />
                  Clear
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <Select
                    aria-label="Bulk assign lead status"
                    className="h-8 text-xs w-40 bg-white dark:bg-slate-900"
                    value={bulkStatus}
                    onChange={(e) => setBulkStatus(e.target.value as LeadStatus)}
                  >
                    {LEAD_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </Select>
                  <Button
                    type="button"
                    size="sm"
                    variant="default"
                    disabled={bulkSubmitting}
                    onClick={() => void handleBulkStatus()}
                  >
                    Apply Status
                  </Button>
                </div>

                <div className="flex items-center gap-1.5">
                  <Select
                    aria-label="Bulk set lead priority"
                    className="h-8 text-xs w-32 bg-white dark:bg-slate-900"
                    value={bulkPriority}
                    onChange={(e) => setBulkPriority(e.target.value as LeadPriority)}
                  >
                    <option value="High">High Priority</option>
                    <option value="Medium">Medium Priority</option>
                    <option value="Low">Low Priority</option>
                  </Select>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="bg-white dark:bg-slate-900"
                    disabled={bulkSubmitting}
                    onClick={() => void handleBulkPriority()}
                  >
                    Set Priority
                  </Button>
                </div>

                <div className="flex items-center gap-1.5">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="bg-white dark:bg-slate-900"
                    onClick={() =>
                      exportDoctorsToCsv(selectedRecords, 'selected-lahore-doctors.csv')
                    }
                  >
                    <Download className="h-3.5 w-3.5" />
                    Export CSV ({selectedRecords.length})
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="bg-white dark:bg-slate-900"
                    onClick={() =>
                      exportDoctorsToExcel(selectedRecords, 'selected-lahore-doctors.xlsx')
                    }
                  >
                    <Download className="h-3.5 w-3.5" />
                    Export Excel ({selectedRecords.length})
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Data Table */}
          {filteredDoctors.length === 0 ? (
            <div className="py-12 text-center border border-dashed border-slate-200 dark:border-slate-700 rounded-lg space-y-3">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">No doctors match your current filters</p>
              <Button type="button" variant="outline" size="sm" onClick={onOpenAddDoctor}>
                Add New Doctor
              </Button>
            </div>
          ) : (
            <div className="w-full overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-md">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                    <th className="py-2.5 px-2 w-8">
                      <input
                        type="checkbox"
                        aria-label="Select all visible doctors"
                        checked={allVisibleSelected}
                        onChange={() =>
                          setSelectedIds((prev) => toggleSelectAllVisible(prev, visibleIds))
                        }
                      />
                    </th>
                    <th className="py-2.5 px-2">
                      <button
                        type="button"
                        onClick={() => toggleSort('fullName')}
                        className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                      >
                        Doctor &amp; Clinic
                        <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="py-2.5 px-2 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => toggleSort('area')}
                        className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                      >
                        Area
                        <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="py-2.5 px-2 whitespace-nowrap">Doctor Status &amp; Availability</th>
                    <th className="py-2.5 px-2 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => toggleSort('experience')}
                        className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                      >
                        Experience &amp; Fee
                        <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="py-2.5 px-2 whitespace-nowrap">Website Status</th>
                    <th className="py-2.5 px-2 whitespace-nowrap">Lead Status</th>
                    <th className="py-2.5 px-2 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => toggleSort('leadScore')}
                        className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                      >
                        Score
                        <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="py-2.5 px-2 text-right whitespace-nowrap">Profile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredDoctors.map((doc) => {
                    const isSelected = selectedIds.includes(doc.id);
                    return (
                      <tr
                        key={doc.id}
                        className={
                          isSelected
                            ? 'bg-blue-50/40 hover:bg-blue-50/70 dark:bg-blue-950/35 dark:hover:bg-blue-950/55'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                        }
                      >
                        <td className="py-2.5 px-2 w-8">
                          <input
                            type="checkbox"
                            aria-label={`Select ${doc.fullName}`}
                            checked={isSelected}
                            onChange={() =>
                              setSelectedIds((prev) => toggleIdSelection(prev, doc.id))
                            }
                          />
                        </td>
                        <td className="py-2.5 px-2 max-w-[190px]">
                          <div className="font-medium text-slate-900 dark:text-slate-100 truncate">{doc.fullName}</div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {doc.speciality} · {doc.clinicName}
                          </div>
                          {doc.qualifications && (
                            <div className="text-[11px] text-slate-400 dark:text-slate-500 truncate">
                              {doc.qualifications}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-2 text-slate-700 dark:text-slate-300 whitespace-nowrap text-xs">
                          <div>{doc.area}</div>
                          <div className="font-mono tabular-nums text-[11px] text-slate-400 dark:text-slate-500">
                            {doc.phone || 'No phone'}
                          </div>
                        </td>
                        <td className="py-2.5 px-2 max-w-[190px] text-xs">
                          <div className="flex items-center gap-1 flex-wrap">
                            <StatusTag
                              label={doc.doctorStatus}
                              tone={getDoctorStatusTone(doc.doctorStatus)}
                            />
                            {doc.videoConsultation && (
                              <StatusTag label="Video" tone="blue" />
                            )}
                          </div>
                          <div
                            className="text-[11px] text-slate-600 dark:text-slate-300 truncate mt-1"
                            title={doc.availability || undefined}
                          >
                            {doc.availability || (
                              <span className="text-slate-400 dark:text-slate-500">Schedule not listed</span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-2 text-xs whitespace-nowrap">
                          <div className="font-medium font-mono tabular-nums text-slate-900 dark:text-slate-100">
                            {formatExperienceLabel(doc.experienceYears)}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                            {doc.consultationFeePkr ? `Rs. ${doc.consultationFeePkr.toLocaleString()}` : 'Fee N/A'}
                            {doc.rating ? ` · ${doc.rating.toFixed(1)}★` : ''}
                          </div>
                        </td>
                        <td className="py-2.5 px-2 max-w-[165px]">
                          <StatusTag
                            label={doc.websiteClassification}
                            tone={getWebsiteTone(doc.websiteClassification)}
                          />
                          {doc.website && (
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                              {doc.website.replace(/^https?:\/\//, '')}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-2 whitespace-nowrap">
                          <StatusTag
                            label={doc.leadStatus}
                            tone={getLeadStatusTone(doc.leadStatus)}
                          />
                        </td>
                        <td className="py-2.5 px-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                              {doc.leadScore}
                            </span>
                            <StatusTag
                              label={doc.leadPriority}
                              tone={getPriorityTone(doc.leadPriority)}
                            />
                          </div>
                        </td>
                        <td className="py-2.5 px-2 text-right whitespace-nowrap">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="px-2"
                            onClick={() => setSelectedDoctorId(doc.id)}
                            aria-label={`View profile for ${doc.fullName}`}
                          >
                            <Eye className="h-3.5 w-3.5" />
                            View
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
