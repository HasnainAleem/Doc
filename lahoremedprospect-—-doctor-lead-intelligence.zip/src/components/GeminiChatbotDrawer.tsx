import { useEffect, useMemo, useRef, useState } from 'react';
import { Bot, Send, Trash2, User, X } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import {
  CHATBOT_ROLES,
  formatDoctorContextForChat,
  getChatbotRole,
  type ChatbotRoleId,
  type ChatTurn,
} from '../lib/geminiChatHelpers';
import { Button } from './ui/button';
import { Select, Textarea } from './ui/input';

interface GeminiChatbotDrawerProps {
  open: boolean;
  onClose: () => void;
  prefilledPrompt?: string | null;
  prefilledDoctorId?: number | null;
  onClearPrefilledPrompt?: () => void;
}

export function GeminiChatbotDrawer({
  open,
  onClose,
  prefilledPrompt,
  prefilledDoctorId,
  onClearPrefilledPrompt,
}: GeminiChatbotDrawerProps) {
  const { user, doctors, selectedDoctorId } = useWorkspace();

  const [roleId, setRoleId] = useState<ChatbotRoleId>('outreach_strategist');
  const [contextDoctorId, setContextDoctorId] = useState<number | 'none'>('none');
  const [messages, setMessages] = useState<ChatTurn[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const threadEndRef = useRef<HTMLDivElement | null>(null);
  const roleConfig = useMemo(() => getChatbotRole(roleId), [roleId]);

  const workspaceSummary = useMemo(() => {
    const noWeb = doctors.filter((d) => !d.website).length;
    const highPriority = doctors.filter((d) => d.leadPriority === 'High').length;
    return `Total Lahore prospects: ${doctors.length}, Without website: ${noWeb}, High-priority leads: ${highPriority}.`;
  }, [doctors]);

  useEffect(() => {
    if (selectedDoctorId !== null) {
      setContextDoctorId(selectedDoctorId);
    }
  }, [selectedDoctorId]);

  useEffect(() => {
    if (open && prefilledDoctorId != null) {
      setContextDoctorId(prefilledDoctorId);
    }
  }, [open, prefilledDoctorId]);

  useEffect(() => {
    if (open && prefilledPrompt) {
      setInput(prefilledPrompt);
      onClearPrefilledPrompt?.();
    }
  }, [onClearPrefilledPrompt, open, prefilledPrompt]);

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  if (!open) return null;

  const activeDoctor =
    contextDoctorId !== 'none' ? doctors.find((d) => d.id === contextDoctorId) || null : null;

  const sendMessage = async (rawPrompt?: string) => {
    const text = (rawPrompt ?? input).trim();
    if (!text || sending) return;

    setError(null);
    const userTurn: ChatTurn = {
      id: `u-${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date().toISOString(),
    };

    const nextMessages = [...messages, userTurn];
    setMessages(nextMessages);
    if (rawPrompt === undefined) {
      setInput('');
    }
    setSending(true);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (user) {
        const token = await user.getIdToken();
        headers.Authorization = `Bearer ${token}`;
      }

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          roleId,
          message: text,
          history: messages.map((m) => ({ role: m.role, text: m.text })),
          doctorContext: activeDoctor ? formatDoctorContextForChat(activeDoctor) : null,
          workspaceSummary,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.error || `Request failed (HTTP ${res.status})`);
      }

      const modelTurn: ChatTurn = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: data.reply,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, modelTurn]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach Gemini chat service.');
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 dark:bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-label="LahoreMedProspect Outreach Assistant"
    >
      <div className="flex h-full w-full max-w-md flex-col border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 px-4 py-3.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-700 dark:bg-blue-600 text-white shrink-0">
              <Bot className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                Outreach Assistant
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {roleConfig.label} · Multi-turn workspace chat
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {messages.length > 0 && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                aria-label="Clear chat history"
                onClick={() => {
                  setMessages([]);
                  setError(null);
                }}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close assistant"
              className="rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Role & Lead Context Controls */}
        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 px-4 py-3 space-y-2.5">
          <div>
            <label
              htmlFor="chatbot-role-select"
              className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Assistant Role (System Instruction)
            </label>
            <Select
              id="chatbot-role-select"
              className="h-8 text-xs"
              value={roleId}
              onChange={(e) => {
                setRoleId(e.target.value as ChatbotRoleId);
                setError(null);
              }}
            >
              {CHATBOT_ROLES.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label} — {r.description}
                </option>
              ))}
            </Select>
          </div>

          <div>
            <label
              htmlFor="chatbot-lead-context"
              className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Attach Doctor / Clinic Context (Optional)
            </label>
            <Select
              id="chatbot-lead-context"
              className="h-8 text-xs"
              value={contextDoctorId === 'none' ? 'none' : String(contextDoctorId)}
              onChange={(e) =>
                setContextDoctorId(e.target.value === 'none' ? 'none' : Number(e.target.value))
              }
            >
              <option value="none">General Lahore Prospecting Context</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fullName} ({d.clinicName}, {d.area} · {d.leadStatus})
                </option>
              ))}
            </Select>
          </div>
        </div>

        {/* Scrollable Message Thread */}
        <div
          data-testid="chatbot-thread"
          className="flex-1 overflow-y-auto px-4 py-4 space-y-4"
        >
          {messages.length === 0 ? (
            <div className="space-y-4 py-4">
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-3.5 text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                <div className="font-semibold text-slate-900 dark:text-slate-100">
                  {roleConfig.label} Ready
                </div>
                <p>{roleConfig.description}</p>
              </div>

              <div className="space-y-2">
                <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  Quick Starters
                </div>
                {roleConfig.starterPrompts.map((starter) => (
                  <button
                    key={starter}
                    type="button"
                    disabled={sending}
                    onClick={() => void sendMessage(starter)}
                    className="w-full text-left rounded-md border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/40 px-3 py-2 text-xs text-slate-700 dark:text-slate-300 hover:border-blue-500 hover:bg-blue-50/40 dark:hover:bg-blue-950/40 transition-colors cursor-pointer"
                  >
                    {starter}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
                >
                  <div
                    className={`flex h-7 w-7 items-center justify-center rounded-full shrink-0 ${
                      isUser
                        ? 'bg-blue-700 text-white dark:bg-blue-600'
                        : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {isUser ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                  </div>
                  <div
                    className={`max-w-[82%] rounded-lg px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${
                      isUser
                        ? 'bg-blue-700 text-white dark:bg-blue-600'
                        : 'border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              );
            })
          )}

          {sending && (
            <div className="flex items-start gap-2.5">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shrink-0">
                <Bot className="h-3.5 w-3.5" />
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-xs text-slate-500 dark:text-slate-400">
                Thinking...
              </div>
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300"
            >
              {error}
            </div>
          )}

          <div ref={threadEndRef} />
        </div>

        {/* Input Form */}
        <form
          onSubmit={handleSubmit}
          className="border-t border-slate-200 dark:border-slate-800 p-3 space-y-2 bg-white dark:bg-slate-900"
        >
          <Textarea
            aria-label="Message the Outreach Assistant"
            placeholder="Ask to draft an email, tailor a pitch, or review a lead..."
            className="min-h-[68px] text-xs"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                void sendMessage();
              }
            }}
          />
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-400 dark:text-slate-500">
              Enter to send · Shift+Enter for new line
            </span>
            <Button type="submit" size="sm" disabled={sending || !input.trim()}>
              <Send className="h-3.5 w-3.5" />
              {sending ? 'Sending...' : 'Send'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
