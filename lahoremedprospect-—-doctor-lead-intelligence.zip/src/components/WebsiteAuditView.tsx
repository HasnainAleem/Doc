import { useMemo, useState } from 'react';
import { ExternalLink, RefreshCw } from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { WEBSITE_CLASSIFICATIONS } from '../types/domain';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select } from './ui/input';
import { StatusTag, getWebsiteTone } from './ui/status-tag';

export function WebsiteAuditView() {
  const { doctors, runWebsiteAudit, setSelectedDoctorId, setActiveNav } = useWorkspace();
  const [classFilter, setClassFilter] = useState('all');
  const [auditingId, setAuditingId] = useState<number | null>(null);

  const summary = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const c of WEBSITE_CLASSIFICATIONS) counts[c] = 0;
    for (const d of doctors) {
      counts[d.websiteClassification] = (counts[d.websiteClassification] || 0) + 1;
    }
    return counts;
  }, [doctors]);

  const filtered = useMemo(() => {
    if (classFilter === 'all') return doctors;
    return doctors.filter((d) => d.websiteClassification === classFilter);
  }, [classFilter, doctors]);

  const handleAudit = async (doctorId: number) => {
    setAuditingId(doctorId);
    await runWebsiteAudit(doctorId);
    setAuditingId(null);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {WEBSITE_CLASSIFICATIONS.map((cls) => (
          <button
            key={cls}
            type="button"
            onClick={() => setClassFilter((prev) => (prev === cls ? 'all' : cls))}
            className={`text-left rounded-lg border p-3 transition-colors cursor-pointer ${
              classFilter === cls
                ? 'border-blue-600 bg-blue-50 dark:border-blue-500 dark:bg-blue-950/60'
                : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800'
            }`}
          >
            <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{cls}</div>
            <div className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
              {summary[cls] || 0}
            </div>
          </button>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-4">
          <div>
            <CardTitle>Website Analysis Engine</CardTitle>
            <CardDescription>
              Inspect HTTP status, SSL encryption, mobile responsiveness, page speed, booking CTAs,
              and local SEO fundamentals across Lahore clinic websites.
            </CardDescription>
          </div>
          <div className="w-64">
            <Select
              aria-label="Filter by website classification"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
            >
              <option value="all">All 9 Classifications</option>
              {WEBSITE_CLASSIFICATIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-600 dark:text-slate-400">
                <th className="py-2.5 px-3">Doctor &amp; Clinic</th>
                <th className="py-2.5 px-3">Official URL</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3">HTTP / SSL</th>
                <th className="py-2.5 px-3">Mobile / Speed</th>
                <th className="py-2.5 px-3">Booking / SEO</th>
                <th className="py-2.5 px-3 text-right">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((doc) => {
                const audit = doc.latestAudit;
                return (
                  <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-2.5 px-3">
                      <button
                        type="button"
                        className="font-medium text-slate-900 dark:text-slate-100 hover:text-blue-700 dark:hover:text-blue-400 hover:underline text-left cursor-pointer"
                        onClick={() => {
                          setSelectedDoctorId(doc.id);
                          setActiveNav('doctors');
                        }}
                      >
                        {doc.fullName}
                      </button>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {doc.clinicName} · {doc.area}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-xs">
                      {doc.website ? (
                        <a
                          href={doc.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                        >
                          {doc.website.replace(/^https?:\/\//, '')}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">None</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusTag
                        label={doc.websiteClassification}
                        tone={getWebsiteTone(doc.websiteClassification)}
                      />
                    </td>
                    <td className="py-2.5 px-3 text-xs font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {audit
                        ? `${audit.httpStatus ?? 'ERR'} · ${audit.sslValid ? 'HTTPS' : 'No SSL'}`
                        : 'Not audited'}
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-700 dark:text-slate-300">
                      {audit ? (
                        <span className="font-mono tabular-nums">
                          {audit.mobileResponsive ? 'Mobile OK' : 'Not Mobile'} ·{' '}
                          {audit.loadTimeMs !== null ? `${audit.loadTimeMs}ms` : 'N/A'}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">-</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-700 dark:text-slate-300">
                      {audit ? (
                        <span>
                          {audit.hasAppointmentBooking ? 'Booking OK' : 'No Booking'} ·{' '}
                          {audit.hasSeoFundamentals ? 'SEO OK' : 'No SEO'}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">-</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={auditingId === doc.id}
                        onClick={() => void handleAudit(doc.id)}
                      >
                        <RefreshCw
                          className={`h-3.5 w-3.5 ${auditingId === doc.id ? 'animate-spin' : ''}`}
                        />
                        {auditingId === doc.id ? 'Checking...' : 'Analyze'}
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
