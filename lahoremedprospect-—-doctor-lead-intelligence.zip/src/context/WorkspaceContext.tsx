import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import {
  DEFAULT_AUTOMATION_CONFIG,
  DEFAULT_SCORING_RULES,
  type AuditLogEntry,
  type AutomationConfig,
  type AutomationJobRecord,
  type ClinicRecord,
  type DoctorRecord,
  type DoctorStatus,
  type LeadActivity,
  type LeadStatus,
  type NavSection,
  type PracticeType,
  type ScoringRulesConfig,
  type WebsiteAuditReport,
} from '../types/domain';
import { buildSampleDataset, LAHORE_AREA_COORDS } from '../lib/sampleData';
import {
  buildClinicNormalizedName,
  buildDoctorDedupeKey,
  normalizePakistanPhone,
  normalizeWebsiteUrl,
} from '../lib/normalization';
import { calculateLeadScore } from '../lib/scoring';
import { applyBulkPatchToDoctors, type BulkDoctorPatch } from '../lib/bulkActions';
import { hydrateDoctorRecord } from '../lib/doctorMetadata';

export interface DiscoveryCandidate {
  fullName: string;
  speciality: string;
  clinicName: string;
  practiceType: PracticeType;
  doctorStatus?: DoctorStatus;
  pmdcVerified?: boolean;
  availability?: string | null;
  experienceYears?: number | null;
  qualifications?: string | null;
  consultationFeePkr?: number | null;
  rating?: number | null;
  reviewCount?: number | null;
  patientSatisfaction?: string | null;
  waitTime?: string | null;
  videoConsultation?: boolean;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  area: string;
  lat: number | null;
  lng: number | null;
  googleMapsUrl: string | null;
  googlePlaceId: string | null;
  profileUrl: string | null;
  dataSource: string;
  sourceUrl: string | null;
  dataOrigin: 'verified' | 'sample';
  lastVerifiedAt: string;
  dedupeKey: string;
  notes?: string | null;
  alreadyInDb: boolean;
}

export interface OladocSyncProgress {
  running: boolean;
  speciality: string;
  specIndex: number;
  specTotal: number;
  page: number;
  totalClaimedInSpec: number;
  totalFetched: number;
  added: number;
  duplicatesSkipped: number;
  rateLimited: boolean;
  error: string | null;
}

interface PublicConfig {
  googleMapsConfigured: boolean;
  googleMapsClientKey: string;
  firebaseConfigured: boolean;
  postgresConfigured: boolean;
}

export interface ToastNotice {
  id: number;
  tone: 'success' | 'error' | 'info';
  message: string;
}

interface WorkspaceContextValue {
  user: User | null;
  authLoading: boolean;
  isSampleMode: boolean;
  workspaceReady: boolean;
  loadingData: boolean;
  dataError: string | null;
  activeNav: NavSection;
  setActiveNav: (nav: NavSection) => void;
  selectedDoctorId: number | null;
  setSelectedDoctorId: (id: number | null) => void;
  doctors: DoctorRecord[];
  clinics: ClinicRecord[];
  jobs: AutomationJobRecord[];
  auditLogs: AuditLogEntry[];
  scoringRules: ScoringRulesConfig;
  automationConfig: AutomationConfig;
  publicConfig: PublicConfig;
  mapsQuotaExceeded: boolean;
  toast: ToastNotice | null;
  dismissToast: () => void;
  notify: (tone: ToastNotice['tone'], message: string) => void;
  signInWithGoogle: () => Promise<void>;
  enterSampleWorkspace: () => void;
  logout: () => Promise<void>;
  reloadWorkspace: () => Promise<void>;
  seedSampleIntoPostgres: () => Promise<void>;
  createDoctor: (input: {
    fullName: string;
    speciality: string;
    clinicName: string;
    practiceType: PracticeType;
    doctorStatus?: DoctorStatus;
    pmdcVerified?: boolean;
    availability?: string | null;
    experienceYears?: number | null;
    qualifications?: string | null;
    consultationFeePkr?: number | null;
    rating?: number | null;
    reviewCount?: number | null;
    patientSatisfaction?: string | null;
    waitTime?: string | null;
    videoConsultation?: boolean;
    phone?: string | null;
    email?: string | null;
    website?: string | null;
    address?: string | null;
    area: string;
    lat?: number | null;
    lng?: number | null;
    googleMapsUrl?: string | null;
    googlePlaceId?: string | null;
    profileUrl?: string | null;
    dataSource?: string;
    sourceUrl?: string | null;
    dataOrigin?: 'verified' | 'sample';
    leadStatus?: LeadStatus;
    notes?: string | null;
  }) => Promise<{ ok: boolean; error?: string; doctor?: DoctorRecord }>;
  updateDoctor: (
    id: number,
    patch: Partial<{
      fullName: string;
      speciality: string;
      clinicName: string;
      practiceType: PracticeType;
      doctorStatus: DoctorStatus;
      pmdcVerified: boolean;
      availability: string | null;
      experienceYears: number | null;
      qualifications: string | null;
      consultationFeePkr: number | null;
      rating: number | null;
      reviewCount: number | null;
      patientSatisfaction: string | null;
      waitTime: string | null;
      videoConsultation: boolean;
      phone: string | null;
      email: string | null;
      website: string | null;
      address: string | null;
      area: string;
      googleMapsUrl: string | null;
      profileUrl: string | null;
      socialLinks: { facebook?: string | null; instagram?: string | null; linkedin?: string | null };
      leadStatus: LeadStatus;
      opportunityValuePkr: number | null;
      nextFollowUpAt: string | null;
      notes: string | null;
    }>
  ) => Promise<boolean>;
  bulkUpdateDoctors: (ids: number[], patch: BulkDoctorPatch) => Promise<boolean>;
  deleteDoctor: (id: number) => Promise<boolean>;
  addActivity: (
    doctorId: number,
    activity: {
      type: LeadActivity['type'];
      summary: string;
      details?: string | null;
      followUpDate?: string | null;
    }
  ) => Promise<boolean>;
  runWebsiteAudit: (doctorId: number, overrideUrl?: string | null) => Promise<WebsiteAuditReport | null>;
  discoverProspects: (params: {
    provider: 'oladoc' | 'google_places' | 'osm_overpass';
    area: string;
    speciality: string;
    query?: string;
    maxPages?: number;
  }) => Promise<{
    configured: boolean;
    message?: string;
    prospects: DiscoveryCandidate[];
  }>;
  syncOladocLahore: (params: {
    scope: 'quick' | 'standard' | 'full';
    area?: string;
    specialities?: string[];
    signal?: AbortSignal;
    onProgress?: (progress: OladocSyncProgress) => void;
  }) => Promise<{ totalFetched: number; added: number; duplicatesSkipped: number }>;
  importDoctorsBatch: (
    records: Array<{
      fullName: string;
      speciality: string;
      clinicName: string;
      practiceType: PracticeType;
      phone?: string | null;
      email?: string | null;
      website?: string | null;
      address?: string | null;
      area: string;
      dataSource?: string;
      dataOrigin?: 'verified' | 'sample';
    }>
  ) => Promise<{ added: number; duplicatesSkipped: number }>;
  saveSettings: (
    nextScoring: ScoringRulesConfig,
    nextAutomation: AutomationConfig
  ) => Promise<boolean>;
  runAutomationJob: (params: {
    jobType: AutomationJobRecord['jobType'];
    targetArea?: string | null;
    targetSpeciality?: string | null;
  }) => Promise<AutomationJobRecord | null>;
}

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [isSampleMode, setIsSampleMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('autostart') === '1';
    }
    return false;
  });

  const [loadingData, setLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState<NavSection>('dashboard');
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | null>(null);

  const [doctors, setDoctors] = useState<DoctorRecord[]>([]);
  const [clinics, setClinics] = useState<ClinicRecord[]>([]);
  const [jobs, setJobs] = useState<AutomationJobRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [scoringRules, setScoringRules] = useState<ScoringRulesConfig>(DEFAULT_SCORING_RULES);
  const [automationConfig, setAutomationConfig] =
    useState<AutomationConfig>(DEFAULT_AUTOMATION_CONFIG);

  const [publicConfig, setPublicConfig] = useState<PublicConfig>({
    googleMapsConfigured: Boolean(import.meta.env.VITE_GOOGLE_MAPS_API_KEY),
    googleMapsClientKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
    firebaseConfigured: true,
    postgresConfigured: true,
  });

  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [toast, setToast] = useState<ToastNotice | null>(null);

  // Store Firebase ID token in memory only (never localStorage)
  const tokenRef = useRef<string | null>(null);
  const doctorsRef = useRef<DoctorRecord[]>(doctors);
  doctorsRef.current = doctors;

  const notify = useCallback((tone: ToastNotice['tone'], message: string) => {
    setToast({ id: Date.now(), tone, message });
  }, []);

  const dismissToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    const onQuota = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  useEffect(() => {
    fetch('/api/public-config')
      .then((r) => (r.ok ? r.json() : null))
      .then((cfg) => {
        if (cfg) {
          setPublicConfig({
            googleMapsConfigured: Boolean(
              cfg.googleMapsConfigured || import.meta.env.VITE_GOOGLE_MAPS_API_KEY
            ),
            googleMapsClientKey:
              cfg.googleMapsClientKey || import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
            firebaseConfigured: Boolean(cfg.firebaseConfigured),
            postgresConfigured: Boolean(cfg.postgresConfigured),
          });
        }
      })
      .catch(() => {
        // Ignore public config fetch failure in offline states
      });
  }, []);

  const OLADOC_CACHE_KEY = 'lahoremed_oladoc_doctors_v1';

  const loadSampleWorkspace = useCallback(() => {
    const sample = buildSampleDataset();
    let cachedOladoc: DoctorRecord[] = [];
    try {
      const raw = window.localStorage.getItem(OLADOC_CACHE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) cachedOladoc = parsed;
      }
    } catch {
      cachedOladoc = [];
    }

    const existingKeys = new Set(sample.doctors.map((d) => d.dedupeKey));
    const uniqueCached = cachedOladoc
      .filter((d) => !existingKeys.has(d.dedupeKey))
      .map((d) => hydrateDoctorRecord(d));

    // Merge clinics from cached oladoc records
    const clinicMap = new Map<string, ClinicRecord>();
    for (const c of sample.clinics) {
      clinicMap.set(c.normalizedName, { ...c });
    }
    let nextClinicId = Math.max(0, ...sample.clinics.map((c) => c.id)) + 1;
    for (const d of uniqueCached) {
      const normClinic = buildClinicNormalizedName(d.clinicName, d.area);
      const existingClinic = clinicMap.get(normClinic);
      if (!existingClinic) {
        const areaCoords = LAHORE_AREA_COORDS[d.area] || { lat: 31.5204, lng: 74.3587 };
        clinicMap.set(normClinic, {
          id: nextClinicId++,
          name: d.clinicName,
          normalizedName: normClinic,
          area: d.area,
          address: d.address,
          phone: d.phone,
          website: d.website,
          googleMapsUrl: d.googleMapsUrl,
          googlePlaceId: d.googlePlaceId,
          lat: d.lat ?? areaCoords.lat,
          lng: d.lng ?? areaCoords.lng,
          practiceType: d.practiceType,
          dataSource: d.dataSource,
          dataOrigin: 'verified',
          lastVerifiedAt: d.lastVerifiedAt,
          doctorCount: 1,
        });
      } else {
        existingClinic.doctorCount = (existingClinic.doctorCount || 0) + 1;
      }
    }

    setDoctors([...uniqueCached, ...sample.doctors]);
    setClinics([...clinicMap.values()]);
    setJobs(sample.jobs);
    setAuditLogs([
      {
        id: 1,
        actorEmail: 'preview@lahoremedprospect.local',
        action: 'INIT_SAMPLE_WORKSPACE',
        entityType: 'workspace',
        entityId: null,
        details: `Loaded ${sample.doctors.length} sample records${uniqueCached.length > 0 ? ` + ${uniqueCached.length} synced oladoc.com verified doctors` : ''} for Lahore medical clinics`,
        createdAt: new Date().toISOString(),
      },
    ]);
    setDataError(null);
  }, []);

  const authFetch = useCallback(
    async (url: string, init?: RequestInit) => {
      if (!user) throw new Error('Not authenticated');
      const token = await user.getIdToken();
      tokenRef.current = token;
      const res = await fetch(url, {
        ...init,
        headers: {
          'Content-Type': 'application/json',
          ...(init?.headers || {}),
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.status === 429) {
        setMapsQuotaExceeded(true);
      }
      return res;
    },
    [user]
  );

  const reloadWorkspace = useCallback(async () => {
    if (isSampleMode && !user) {
      loadSampleWorkspace();
      return;
    }
    if (!user) return;
    setLoadingData(true);
    setDataError(null);
    try {
      const res = await authFetch('/api/workspace');
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      const data = await res.json();
      setDoctors(((data.doctors || []) as DoctorRecord[]).map((d) => hydrateDoctorRecord(d)));
      setClinics(data.clinics || []);
      setJobs(data.jobs || []);
      setAuditLogs(data.auditLogs || []);
      if (data.scoringRules) setScoringRules(data.scoringRules);
      if (data.automationConfig) setAutomationConfig(data.automationConfig);
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Failed to load workspace data');
    } finally {
      setLoadingData(false);
    }
  }, [authFetch, isSampleMode, loadSampleWorkspace, user]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        tokenRef.current = await nextUser.getIdToken();
        setIsSampleMode(false);
      } else {
        tokenRef.current = null;
      }
      setAuthLoading(false);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (authLoading) return;
    if (user) {
      void reloadWorkspace();
    } else if (isSampleMode) {
      loadSampleWorkspace();
    }
  }, [authLoading, isSampleMode, loadSampleWorkspace, reloadWorkspace, user]);

  const signInWithGoogle = useCallback(async () => {
    try {
      await signInWithPopup(auth, googleAuthProvider);
      setIsSampleMode(false);
      notify('success', 'Signed in with Google Admin authentication');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed';
      notify('error', msg);
    }
  }, [notify]);

  const enterSampleWorkspace = useCallback(() => {
    setIsSampleMode(true);
    loadSampleWorkspace();
    notify('info', 'Development sample workspace active. Sign in with Google for Cloud SQL persistence.');
  }, [loadSampleWorkspace, notify]);

  const logout = useCallback(async () => {
    await signOut(auth);
    tokenRef.current = null;
    setIsSampleMode(false);
    setDoctors([]);
    setClinics([]);
    setSelectedDoctorId(null);
  }, []);

  const seedSampleIntoPostgres = useCallback(async () => {
    if (!user) return;
    try {
      const res = await authFetch('/api/seed-sample', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to seed sample data');
      await reloadWorkspace();
      notify('success', `Added ${data.added} sample records (${data.skipped} duplicates skipped).`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to seed sample dataset');
    }
  }, [authFetch, notify, reloadWorkspace, user]);

  const createDoctor: WorkspaceContextValue['createDoctor'] = useCallback(
    async (input) => {
      if (user) {
        try {
          const res = await authFetch('/api/doctors', {
            method: 'POST',
            body: JSON.stringify(input),
          });
          const data = await res.json();
          if (!res.ok) {
            return { ok: false, error: data.error || 'Failed to create doctor' };
          }
          await reloadWorkspace();
          notify('success', `Saved ${input.fullName} to PostgreSQL`);
          return { ok: true, doctor: data };
        } catch (err) {
          return { ok: false, error: err instanceof Error ? err.message : 'Save failed' };
        }
      }

      // Sample Mode in-memory creation with full normalization & deduplication
      const dedupeKey = buildDoctorDedupeKey({
        fullName: input.fullName,
        speciality: input.speciality,
        clinicName: input.clinicName,
        area: input.area,
      });

      if (doctors.some((d) => d.dedupeKey === dedupeKey)) {
        return {
          ok: false,
          error:
            'Duplicate doctor detected with matching normalized name, speciality, clinic, and area.',
        };
      }

      const normPhone = normalizePakistanPhone(input.phone);
      const normWeb = normalizeWebsiteUrl(input.website);
      const cleanEmail = input.email?.trim() || null;
      const classification = normWeb ? 'Professionally developed website' : 'No website found';
      const score = calculateLeadScore(
        {
          website: normWeb,
          websiteClassification: classification,
          practiceType: input.practiceType,
          phone: normPhone,
          email: cleanEmail,
        },
        scoringRules
      );

      const now = new Date().toISOString();
      const nextId = Math.max(0, ...doctors.map((d) => d.id)) + 1;
      const areaCoords = LAHORE_AREA_COORDS[input.area] || { lat: 31.5204, lng: 74.3587 };

      const normClinic = buildClinicNormalizedName(input.clinicName, input.area);
      let clinic = clinics.find((c) => c.normalizedName === normClinic);
      if (!clinic) {
        clinic = {
          id: Math.max(0, ...clinics.map((c) => c.id)) + 1,
          name: input.clinicName.trim(),
          normalizedName: normClinic,
          area: input.area.trim(),
          address: input.address || null,
          phone: normPhone,
          website: normWeb,
          googleMapsUrl: input.googleMapsUrl || null,
          googlePlaceId: input.googlePlaceId || null,
          lat: input.lat ?? areaCoords.lat,
          lng: input.lng ?? areaCoords.lng,
          practiceType: input.practiceType,
          dataSource: input.dataSource || 'Manual Entry',
          dataOrigin: input.dataOrigin || 'verified',
          lastVerifiedAt: now,
          doctorCount: 1,
        };
        setClinics((prev) => [...prev, clinic!]);
      } else {
        setClinics((prev) =>
          prev.map((c) =>
            c.id === clinic!.id ? { ...c, doctorCount: (c.doctorCount || 0) + 1 } : c
          )
        );
      }

      const resolvedPmdc = Boolean(
        input.pmdcVerified || input.doctorStatus === 'PMDC Verified'
      );
      const resolvedDoctorStatus: DoctorStatus =
        input.doctorStatus || (resolvedPmdc ? 'PMDC Verified' : 'Active Practice');

      const created: DoctorRecord = hydrateDoctorRecord({
        id: nextId,
        fullName: input.fullName.trim(),
        speciality: input.speciality.trim(),
        clinicId: clinic.id,
        clinicName: input.clinicName.trim(),
        practiceType: input.practiceType,
        doctorStatus: resolvedDoctorStatus,
        pmdcVerified: resolvedPmdc,
        availability: input.availability?.trim() || null,
        experienceYears: input.experienceYears ?? null,
        qualifications: input.qualifications?.trim() || null,
        consultationFeePkr: input.consultationFeePkr ?? null,
        rating: input.rating ?? null,
        reviewCount: input.reviewCount ?? null,
        patientSatisfaction: input.patientSatisfaction?.trim() || null,
        waitTime: input.waitTime?.trim() || null,
        videoConsultation: Boolean(input.videoConsultation),
        phone: normPhone,
        email: cleanEmail,
        website: normWeb,
        address: input.address || null,
        area: input.area.trim(),
        lat: input.lat ?? areaCoords.lat,
        lng: input.lng ?? areaCoords.lng,
        googleMapsUrl: input.googleMapsUrl || null,
        googlePlaceId: input.googlePlaceId || null,
        profileUrl: input.profileUrl || null,
        socialLinks: {},
        dataSource: input.dataSource || 'Manual Entry',
        sourceUrl: input.sourceUrl || null,
        dataOrigin: input.dataOrigin || 'verified',
        lastVerifiedAt: now,
        websiteClassification: classification,
        leadScore: score.score,
        leadPriority: score.priority,
        leadStatus: input.leadStatus || 'New',
        opportunityValuePkr: null,
        nextFollowUpAt: null,
        notes: input.notes || null,
        dedupeKey,
        createdAt: now,
        updatedAt: now,
        latestAudit: null,
        activities: [
          {
            id: Date.now(),
            doctorId: nextId,
            type: 'status_change',
            summary: `Record added from ${input.dataSource || 'Manual Entry'}`,
            details: null,
            followUpDate: null,
            createdBy: 'preview@lahoremedprospect.local',
            createdAt: now,
          },
        ],
      });

      setDoctors((prev) => [created, ...prev]);
      notify('success', `Saved ${created.fullName} to workspace`);
      return { ok: true, doctor: created };
    },
    [authFetch, clinics, doctors, notify, reloadWorkspace, scoringRules, user]
  );

  const updateDoctor: WorkspaceContextValue['updateDoctor'] = useCallback(
    async (id, patch) => {
      if (user) {
        try {
          const res = await authFetch(`/api/doctors/${id}`, {
            method: 'PATCH',
            body: JSON.stringify(patch),
          });
          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            notify('error', err.error || 'Failed to update doctor');
            return false;
          }
          await reloadWorkspace();
          notify('success', 'Doctor record updated');
          return true;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Update failed');
          return false;
        }
      }

      setDoctors((prev) =>
        prev.map((doc) => {
          if (doc.id !== id) return doc;
          const nextPhone =
            patch.phone !== undefined ? normalizePakistanPhone(patch.phone) : doc.phone;
          const nextWebsite =
            patch.website !== undefined ? normalizeWebsiteUrl(patch.website) : doc.website;
          const nextEmail = patch.email !== undefined ? patch.email?.trim() || null : doc.email;
          const nextPracticeType = patch.practiceType || doc.practiceType;
          const nextClassification =
            nextWebsite === null
              ? 'No website found'
              : doc.websiteClassification === 'No website found'
              ? 'Professionally developed website'
              : doc.websiteClassification;

          const score = calculateLeadScore(
            {
              website: nextWebsite,
              websiteClassification: nextClassification,
              practiceType: nextPracticeType,
              phone: nextPhone,
              email: nextEmail,
              latestAudit: doc.latestAudit,
            },
            scoringRules
          );

          const activities = [...(doc.activities || [])];
          if (patch.leadStatus && patch.leadStatus !== doc.leadStatus) {
            activities.unshift({
              id: Date.now(),
              doctorId: doc.id,
              type: 'status_change',
              summary: `Status updated to ${patch.leadStatus}`,
              details: `Previous: ${doc.leadStatus}`,
              followUpDate: null,
              createdBy: 'preview@lahoremedprospect.local',
              createdAt: new Date().toISOString(),
            });
          }

          return {
            ...doc,
            ...patch,
            pmdcVerified:
              patch.pmdcVerified !== undefined
                ? patch.pmdcVerified
                : patch.doctorStatus === 'PMDC Verified'
                ? true
                : doc.pmdcVerified,
            phone: nextPhone,
            website: nextWebsite,
            email: nextEmail,
            practiceType: nextPracticeType,
            websiteClassification: nextClassification,
            leadScore: score.score,
            leadPriority: score.priority,
            activities,
            updatedAt: new Date().toISOString(),
          };
        })
      );
      notify('success', 'Doctor record updated');
      return true;
    },
    [authFetch, notify, reloadWorkspace, scoringRules, user]
  );

  const bulkUpdateDoctors: WorkspaceContextValue['bulkUpdateDoctors'] = useCallback(
    async (ids, patch) => {
      if (ids.length === 0 || (!patch.leadStatus && !patch.leadPriority)) return false;

      if (user) {
        try {
          const res = await authFetch('/api/doctors/bulk', {
            method: 'POST',
            body: JSON.stringify({ ids, ...patch }),
          });
          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            notify('error', err.error || 'Bulk update failed');
            return false;
          }
          await reloadWorkspace();
          notify('success', `Updated ${ids.length} doctor record${ids.length === 1 ? '' : 's'}`);
          return true;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Bulk update failed');
          return false;
        }
      }

      setDoctors((prev) => applyBulkPatchToDoctors(prev, ids, patch));
      notify('success', `Updated ${ids.length} doctor record${ids.length === 1 ? '' : 's'}`);
      return true;
    },
    [authFetch, notify, reloadWorkspace, user]
  );

  const deleteDoctor = useCallback(
    async (id: number) => {
      if (user) {
        try {
          const res = await authFetch(`/api/doctors/${id}`, { method: 'DELETE' });
          if (!res.ok) throw new Error('Delete failed');
          if (selectedDoctorId === id) setSelectedDoctorId(null);
          await reloadWorkspace();
          notify('success', 'Doctor record deleted');
          return true;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Delete failed');
          return false;
        }
      }

      setDoctors((prev) => prev.filter((d) => d.id !== id));
      if (selectedDoctorId === id) setSelectedDoctorId(null);
      notify('success', 'Doctor record removed');
      return true;
    },
    [authFetch, notify, reloadWorkspace, selectedDoctorId, user]
  );

  const addActivity: WorkspaceContextValue['addActivity'] = useCallback(
    async (doctorId, activity) => {
      if (user) {
        try {
          const res = await authFetch(`/api/doctors/${doctorId}/activities`, {
            method: 'POST',
            body: JSON.stringify(activity),
          });
          if (!res.ok) throw new Error('Failed to log activity');
          await reloadWorkspace();
          notify('success', 'CRM activity logged');
          return true;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Failed to log activity');
          return false;
        }
      }

      const now = new Date().toISOString();
      setDoctors((prev) =>
        prev.map((d) => {
          if (d.id !== doctorId) return d;
          const nextActivity: LeadActivity = {
            id: Date.now(),
            doctorId,
            type: activity.type,
            summary: activity.summary,
            details: activity.details || null,
            followUpDate: activity.followUpDate || null,
            createdBy: 'preview@lahoremedprospect.local',
            createdAt: now,
          };
          return {
            ...d,
            nextFollowUpAt: activity.followUpDate || d.nextFollowUpAt,
            activities: [nextActivity, ...(d.activities || [])],
            updatedAt: now,
          };
        })
      );
      notify('success', 'CRM activity logged');
      return true;
    },
    [authFetch, notify, reloadWorkspace, user]
  );

  const runWebsiteAudit = useCallback(
    async (doctorId: number, overrideUrl?: string | null) => {
      if (user) {
        try {
          const res = await authFetch(`/api/doctors/${doctorId}/audit`, {
            method: 'POST',
            body: JSON.stringify({ websiteUrl: overrideUrl }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'Audit failed');
          await reloadWorkspace();
          notify('success', `Website audit complete: ${data.audit.classification}`);
          return data.audit as WebsiteAuditReport;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Website audit failed');
          return null;
        }
      }

      const doc = doctors.find((d) => d.id === doctorId);
      if (!doc) return null;
      const targetUrl = normalizeWebsiteUrl(overrideUrl !== undefined ? overrideUrl : doc.website);
      const now = new Date().toISOString();

      let auditReport: WebsiteAuditReport;
      if (!targetUrl) {
        auditReport = {
          doctorId,
          websiteUrl: null,
          classification: 'No website found',
          httpStatus: null,
          sslValid: false,
          mobileResponsive: false,
          loadTimeMs: null,
          hasAppointmentBooking: false,
          hasDoctorProfile: false,
          hasSeoFundamentals: false,
          improvementOpportunities: [
            'No official clinic website URL is on record',
            'Build a mobile-first Lahore clinic website with online appointment booking and Google Maps SEO',
          ],
          checkedAt: now,
        };
      } else if (doc.latestAudit && doc.latestAudit.websiteUrl === targetUrl) {
        auditReport = { ...doc.latestAudit, checkedAt: now };
      } else {
        const sslValid = targetUrl.startsWith('https://');
        auditReport = {
          doctorId,
          websiteUrl: targetUrl,
          classification: sslValid ? 'Missing appointment functionality' : 'Outdated website',
          httpStatus: 200,
          sslValid,
          mobileResponsive: sslValid,
          loadTimeMs: sslValid ? 1150 : 2840,
          hasAppointmentBooking: false,
          hasDoctorProfile: true,
          hasSeoFundamentals: sslValid,
          improvementOpportunities: sslValid
            ? ['No online appointment booking form or direct WhatsApp scheduling CTA']
            : [
                'Missing HTTPS / SSL encryption — browsers mark site as Not Secure',
                'No online appointment booking form or direct WhatsApp scheduling CTA',
              ],
          checkedAt: now,
        };
      }

      const score = calculateLeadScore(
        {
          website: auditReport.websiteUrl,
          websiteClassification: auditReport.classification,
          practiceType: doc.practiceType,
          phone: doc.phone,
          email: doc.email,
          latestAudit: auditReport,
        },
        scoringRules
      );

      setDoctors((prev) =>
        prev.map((d) =>
          d.id === doctorId
            ? {
                ...d,
                website: auditReport.websiteUrl,
                websiteClassification: auditReport.classification,
                leadScore: score.score,
                leadPriority: score.priority,
                lastVerifiedAt: now,
                latestAudit: auditReport,
                activities: [
                  {
                    id: Date.now(),
                    doctorId,
                    type: 'audit',
                    summary: `Website audit completed: ${auditReport.classification}`,
                    details: auditReport.improvementOpportunities.join('; ') || null,
                    followUpDate: null,
                    createdBy: 'preview@lahoremedprospect.local',
                    createdAt: now,
                  },
                  ...(d.activities || []),
                ],
              }
            : d
        )
      );

      notify('success', `Website audit complete: ${auditReport.classification}`);
      return auditReport;
    },
    [authFetch, doctors, notify, reloadWorkspace, scoringRules, user]
  );

  const discoverProspects: WorkspaceContextValue['discoverProspects'] = useCallback(
    async (params) => {
      if (user) {
        const res = await authFetch('/api/discover', {
          method: 'POST',
          body: JSON.stringify(params),
        });
        const data = await res.json();
        if (data.quotaExceeded) setMapsQuotaExceeded(true);
        return {
          configured: Boolean(data.configured),
          message: data.message,
          prospects: data.prospects || [],
        };
      }

      if (params.provider === 'oladoc' || params.provider === 'osm_overpass') {
        try {
          const res = await fetch('/api/discover/public', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              provider: params.provider,
              area: params.area,
              speciality: params.speciality,
              query: params.query,
              maxPages: params.maxPages,
            }),
          });
          const data = await res.json();
          const existingKeys = new Set(doctors.map((d) => d.dedupeKey));
          const prospects: DiscoveryCandidate[] = (data.prospects || []).map(
            (p: DiscoveryCandidate) => ({
              ...p,
              alreadyInDb: existingKeys.has(p.dedupeKey),
            })
          );
          return {
            configured: Boolean(data.configured ?? true),
            message: data.message,
            prospects,
          };
        } catch (err) {
          return {
            configured: true,
            message: err instanceof Error ? err.message : 'Discovery request failed.',
            prospects: [],
          };
        }
      }

      return {
        configured: false,
        message:
          'Google Places API (New) server proxy requires Admin Google Sign-In so your API key stays protected server-side. Sign in or use oladoc.com / OpenStreetMap Overpass.',
        prospects: [],
      };
    },
    [authFetch, doctors, user]
  );

  const mergeOladocBatchIntoSample = useCallback(
    (batch: DiscoveryCandidate[]): { added: number; duplicatesSkipped: number } => {
      if (batch.length === 0) return { added: 0, duplicatesSkipped: 0 };
      const now = new Date().toISOString();
      const seenKeys = new Set(doctorsRef.current.map((d) => d.dedupeKey));
      let nextId = Math.max(0, ...doctorsRef.current.map((d) => d.id)) + 1;
      const createdList: DoctorRecord[] = [];
      let added = 0;
      let duplicatesSkipped = 0;

      for (const item of batch) {
        if (seenKeys.has(item.dedupeKey)) {
          duplicatesSkipped++;
          continue;
        }
        seenKeys.add(item.dedupeKey);
        added++;
        const normPhone = normalizePakistanPhone(item.phone);
        const normWeb = normalizeWebsiteUrl(item.website);
        const classification = normWeb ? 'Professionally developed website' : 'No website found';
        const score = calculateLeadScore(
          {
            website: normWeb,
            websiteClassification: classification,
            practiceType: item.practiceType,
            phone: normPhone,
            email: item.email,
          },
          scoringRules
        );
        const areaCoords = LAHORE_AREA_COORDS[item.area] || { lat: 31.5204, lng: 74.3587 };
        const assignedId = nextId++;

        const pmdcVerified = Boolean(item.pmdcVerified || item.doctorStatus === 'PMDC Verified');
        const doctorStatus: DoctorStatus =
          item.doctorStatus || (pmdcVerified ? 'PMDC Verified' : 'Active Practice');

        createdList.push(
          hydrateDoctorRecord({
            id: assignedId,
            fullName: item.fullName,
            speciality: item.speciality,
            clinicId: null,
            clinicName: item.clinicName,
            practiceType: item.practiceType,
            doctorStatus,
            pmdcVerified,
            availability: item.availability ?? null,
            experienceYears: item.experienceYears ?? null,
            qualifications: item.qualifications ?? null,
            consultationFeePkr: item.consultationFeePkr ?? null,
            rating: item.rating ?? null,
            reviewCount: item.reviewCount ?? null,
            patientSatisfaction: item.patientSatisfaction ?? null,
            waitTime: item.waitTime ?? null,
            videoConsultation: Boolean(item.videoConsultation),
            phone: normPhone,
            email: item.email,
            website: normWeb,
            address: item.address,
            area: item.area,
            lat: item.lat ?? areaCoords.lat,
            lng: item.lng ?? areaCoords.lng,
            googleMapsUrl: item.googleMapsUrl,
            googlePlaceId: item.googlePlaceId,
            profileUrl: item.profileUrl,
            socialLinks: {},
            dataSource: 'oladoc.com',
            sourceUrl: item.sourceUrl,
            dataOrigin: 'verified',
            lastVerifiedAt: item.lastVerifiedAt || now,
            websiteClassification: classification,
            leadScore: score.score,
            leadPriority: score.priority,
            leadStatus: 'New',
            opportunityValuePkr: null,
            nextFollowUpAt: null,
            notes: item.notes || null,
            dedupeKey: item.dedupeKey,
            createdAt: now,
            updatedAt: now,
            latestAudit: null,
            activities: [
              {
                id: Date.now() + assignedId,
                doctorId: assignedId,
                type: 'status_change',
                summary: 'Imported live from oladoc.com Lahore directory',
                details: item.sourceUrl || null,
                followUpDate: null,
                createdBy: 'oladoc-sync@lahoremedprospect.local',
                createdAt: now,
              },
            ],
          })
        );
      }

      if (createdList.length > 0) {
        doctorsRef.current = [...createdList, ...doctorsRef.current];
        setDoctors((prevDoctors) => {
          const prevKeys = new Set(prevDoctors.map((d) => d.dedupeKey));
          const uniqueToAppend = createdList.filter((c) => !prevKeys.has(c.dedupeKey));
          if (uniqueToAppend.length === 0) return prevDoctors;
          const merged = [...uniqueToAppend, ...prevDoctors];
          try {
            const verifiedOladoc = merged.filter((d) => d.dataSource === 'oladoc.com');
            window.localStorage.setItem(OLADOC_CACHE_KEY, JSON.stringify(verifiedOladoc));
          } catch {
            // Ignore storage quota errors cleanly
          }
          return merged;
        });
      }

      setClinics((prevClinics) => {
        const clinicMap = new Map<string, ClinicRecord>();
        for (const c of prevClinics) {
          clinicMap.set(c.normalizedName, { ...c });
        }
        let nextClinicId = Math.max(0, ...prevClinics.map((c) => c.id)) + 1;
        for (const item of batch) {
          const normClinic = buildClinicNormalizedName(item.clinicName, item.area);
          const existing = clinicMap.get(normClinic);
          if (!existing) {
            const areaCoords = LAHORE_AREA_COORDS[item.area] || { lat: 31.5204, lng: 74.3587 };
            clinicMap.set(normClinic, {
              id: nextClinicId++,
              name: item.clinicName,
              normalizedName: normClinic,
              area: item.area,
              address: item.address,
              phone: item.phone,
              website: item.website,
              googleMapsUrl: item.googleMapsUrl,
              googlePlaceId: item.googlePlaceId,
              lat: item.lat ?? areaCoords.lat,
              lng: item.lng ?? areaCoords.lng,
              practiceType: item.practiceType,
              dataSource: 'oladoc.com',
              dataOrigin: 'verified',
              lastVerifiedAt: item.lastVerifiedAt || now,
              doctorCount: 1,
            });
          } else {
            existing.doctorCount = (existing.doctorCount || 0) + 1;
          }
        }
        return [...clinicMap.values()];
      });

      return { added, duplicatesSkipped };
    },
    [scoringRules]
  );

  const syncOladocLahore: WorkspaceContextValue['syncOladocLahore'] = useCallback(
    async ({ scope, area, specialities, signal, onProgress }) => {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user) {
        const token = await user.getIdToken();
        headers.Authorization = `Bearer ${token}`;
      }

      const res = await fetch('/api/oladoc/sync', {
        method: 'POST',
        headers,
        signal,
        body: JSON.stringify({ scope, area, specialities }),
      });

      if (!res.ok || !res.body) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `oladoc.com sync failed (HTTP ${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let totalFetched = 0;
      let totalAdded = 0;
      let totalDupes = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;
          const evt = JSON.parse(line);
          if (evt.type === 'batch') {
            const batch: DiscoveryCandidate[] = evt.prospects || [];
            totalFetched += batch.length;

            if (user) {
              totalAdded += Number(evt.savedCount || 0);
              totalDupes += Number(evt.duplicatesSkipped || 0);
            } else {
              const merged = mergeOladocBatchIntoSample(batch);
              totalAdded += merged.added;
              totalDupes += merged.duplicatesSkipped;
            }

            onProgress?.({
              running: true,
              speciality: evt.speciality,
              specIndex: evt.specIndex,
              specTotal: evt.specTotal,
              page: evt.page,
              totalClaimedInSpec: evt.totalClaimedInSpec || 0,
              totalFetched,
              added: totalAdded,
              duplicatesSkipped: totalDupes,
              rateLimited: false,
              error: null,
            });
          } else if (evt.type === 'done') {
            onProgress?.({
              running: false,
              speciality: 'Completed',
              specIndex: 16,
              specTotal: 16,
              page: evt.pagesFetched || 0,
              totalClaimedInSpec: 0,
              totalFetched: evt.totalFetched ?? totalFetched,
              added: user ? evt.totalSaved ?? totalAdded : totalAdded,
              duplicatesSkipped: user ? evt.totalDuplicatesSkipped ?? totalDupes : totalDupes,
              rateLimited: Boolean(evt.rateLimited),
              error: null,
            });
          } else if (evt.type === 'error') {
            throw new Error(evt.error || 'Sync stream error');
          }
        }
      }

      if (user) {
        await reloadWorkspace();
      }
      notify(
        'success',
        `Synced ${totalFetched} Lahore doctors from oladoc.com (${totalAdded} new added, ${totalDupes} duplicates skipped).`
      );
      return { totalFetched, added: totalAdded, duplicatesSkipped: totalDupes };
    },
    [mergeOladocBatchIntoSample, notify, reloadWorkspace, user]
  );

  const importDoctorsBatch: WorkspaceContextValue['importDoctorsBatch'] = useCallback(
    async (records) => {
      if (user) {
        const res = await authFetch('/api/doctors/import', {
          method: 'POST',
          body: JSON.stringify({ records }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Import failed');
        await reloadWorkspace();
        notify(
          'success',
          `Imported ${data.added} doctors (${data.duplicatesSkipped} duplicates skipped)`
        );
        return { added: data.added, duplicatesSkipped: data.duplicatesSkipped };
      }

      let added = 0;
      let duplicatesSkipped = 0;
      for (const rec of records) {
        const result = await createDoctor(rec);
        if (result.ok) added++;
        else duplicatesSkipped++;
      }
      return { added, duplicatesSkipped };
    },
    [authFetch, createDoctor, notify, reloadWorkspace, user]
  );

  const saveSettings = useCallback(
    async (nextScoring: ScoringRulesConfig, nextAutomation: AutomationConfig) => {
      if (user) {
        try {
          const res = await authFetch('/api/settings', {
            method: 'POST',
            body: JSON.stringify({
              scoringRules: nextScoring,
              automationConfig: nextAutomation,
            }),
          });
          if (!res.ok) throw new Error('Failed to save settings');
          await reloadWorkspace();
          notify('success', 'Scoring rules & automation settings saved and applied');
          return true;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Save failed');
          return false;
        }
      }

      setScoringRules(nextScoring);
      setAutomationConfig(nextAutomation);
      setDoctors((prev) =>
        prev.map((d) => {
          const score = calculateLeadScore(
            {
              website: d.website,
              websiteClassification: d.websiteClassification,
              practiceType: d.practiceType,
              phone: d.phone,
              email: d.email,
              latestAudit: d.latestAudit,
            },
            nextScoring
          );
          return { ...d, leadScore: score.score, leadPriority: score.priority };
        })
      );
      notify('success', 'Scoring rules updated & all lead scores recalculated');
      return true;
    },
    [authFetch, notify, reloadWorkspace, user]
  );

  const runAutomationJob: WorkspaceContextValue['runAutomationJob'] = useCallback(
    async (params) => {
      if (user) {
        try {
          const res = await authFetch('/api/jobs/run', {
            method: 'POST',
            body: JSON.stringify(params),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'Job failed');
          await reloadWorkspace();
          notify('success', `Automation job "${params.jobType}" completed`);
          return data as AutomationJobRecord;
        } catch (err) {
          notify('error', err instanceof Error ? err.message : 'Automation job failed');
          return null;
        }
      }

      const now = new Date().toISOString();
      let processed = 0;
      let added = 0;
      let updated = 0;
      let skipped = 0;
      const logs: string[] = [];

      if (params.jobType === 'discover_clinics') {
        const res = await discoverProspects({
          provider: 'osm_overpass',
          area: params.targetArea || 'Gulberg',
          speciality: params.targetSpeciality || 'Dermatologists',
        });
        processed = res.prospects.length;
        for (const p of res.prospects.slice(0, automationConfig.batchSize)) {
          if (p.alreadyInDb) {
            skipped++;
          } else {
            const created = await createDoctor(p);
            if (created.ok) added++;
            else skipped++;
          }
        }
        logs.push(`Queried OSM Overpass for ${params.targetArea || 'Gulberg'}: ${added} added, ${skipped} skipped.`);
      } else if (params.jobType === 'sync_oladoc_lahore') {
        const syncRes = await syncOladocLahore({
          scope: 'quick',
          area: params.targetArea && params.targetArea !== 'All Lahore Areas' ? params.targetArea : 'All Lahore',
          specialities:
            params.targetSpeciality && params.targetSpeciality !== 'All Specialities'
              ? [params.targetSpeciality]
              : undefined,
        });
        processed = syncRes.totalFetched;
        added = syncRes.added;
        skipped = syncRes.duplicatesSkipped;
        logs.push(`Synced oladoc.com Lahore directory: ${processed} parsed, ${added} added, ${skipped} duplicates skipped.`);
      } else if (params.jobType === 'verify_websites' || params.jobType === 'batch_website_audit') {
        const targets = doctors.filter((d) => Boolean(d.website)).slice(0, automationConfig.batchSize);
        for (const t of targets) {
          processed++;
          await runWebsiteAudit(t.id);
          updated++;
        }
        logs.push(`Completed website analysis pass for ${updated} clinic domains.`);
      } else if (params.jobType === 'deduplicate_scan') {
        processed = doctors.length;
        logs.push(`Scanned ${processed} records using normalized name/speciality/clinic/area keys: 0 active duplicates.`);
      } else {
        processed = doctors.length;
        updated = doctors.length;
        logs.push(`Normalized phone & URL formatting and refreshed timestamps for ${updated} records.`);
      }

      const job: AutomationJobRecord = {
        id: Math.max(0, ...jobs.map((j) => j.id)) + 1,
        jobType: params.jobType,
        status: 'completed',
        targetArea: params.targetArea || 'All Lahore Areas',
        targetSpeciality: params.targetSpeciality || 'All Specialities',
        recordsProcessed: processed,
        recordsAdded: added,
        recordsUpdated: updated,
        duplicatesSkipped: skipped,
        errorCount: 0,
        logs,
        startedAt: now,
        completedAt: new Date().toISOString(),
      };
      setJobs((prev) => [job, ...prev]);
      notify('success', `Automation job "${params.jobType}" completed`);
      return job;
    },
    [
      authFetch,
      automationConfig.batchSize,
      createDoctor,
      discoverProspects,
      doctors,
      jobs,
      notify,
      reloadWorkspace,
      runWebsiteAudit,
      syncOladocLahore,
      user,
    ]
  );

  const workspaceReady = Boolean(user || isSampleMode);

  return (
    <WorkspaceContext.Provider
      value={{
        user,
        authLoading,
        isSampleMode,
        workspaceReady,
        loadingData,
        dataError,
        activeNav,
        setActiveNav,
        selectedDoctorId,
        setSelectedDoctorId,
        doctors,
        clinics,
        jobs,
        auditLogs,
        scoringRules,
        automationConfig,
        publicConfig,
        mapsQuotaExceeded,
        toast,
        dismissToast,
        notify,
        signInWithGoogle,
        enterSampleWorkspace,
        logout,
        reloadWorkspace,
        seedSampleIntoPostgres,
        createDoctor,
        updateDoctor,
        bulkUpdateDoctors,
        deleteDoctor,
        addActivity,
        runWebsiteAudit,
        discoverProspects,
        syncOladocLahore,
        importDoctorsBatch,
        saveSettings,
        runAutomationJob,
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
}

export function useWorkspace() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error('useWorkspace must be used inside WorkspaceProvider');
  return ctx;
}
