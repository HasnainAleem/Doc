import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateLeadScore } from './scoring';
import { DEFAULT_SCORING_RULES } from '../types/domain';

test('calculateLeadScore awards high priority when website is missing and medium for outdated with gaps', () => {
  const noWebsiteClinic = calculateLeadScore({
    website: null,
    websiteClassification: 'No website found',
    practiceType: 'independent',
    phone: '+923001234567',
    email: null,
  });
  // 45 (no website) + 15 (no booking) + 10 (poor mobile) + 10 (independent) + 5 (contact) = 85
  assert.equal(noWebsiteClinic.score, 85);
  assert.equal(noWebsiteClinic.priority, 'High');

  const outdatedClinic = calculateLeadScore({
    website: 'https://oldclinic.pk',
    websiteClassification: 'Outdated website',
    practiceType: 'independent',
    phone: '+923001234567',
    email: null,
    latestAudit: {
      hasAppointmentBooking: false,
      mobileResponsive: false,
    },
  });
  // 25 (outdated) + 15 (no booking) + 10 (poor mobile) + 10 (independent) + 5 (contact) = 65
  assert.equal(outdatedClinic.score, 65);
  assert.equal(outdatedClinic.priority, 'Medium');
});

test('calculateLeadScore respects custom scoring weights and thresholds', () => {
  const customRules = {
    ...DEFAULT_SCORING_RULES,
    noWebsiteWeight: 50,
    independentPracticeWeight: 20,
    highPriorityThreshold: 85,
  };
  const noWeb = calculateLeadScore(
    {
      website: null,
      websiteClassification: 'No website found',
      practiceType: 'independent',
      phone: '+923001112233',
      email: 'info@clinic.pk',
    },
    customRules
  );
  // 50 + 15 + 10 + 20 + 5 = 100
  assert.equal(noWeb.score, 100);
  assert.equal(noWeb.priority, 'High');
});

test('calculateLeadScore gives low score for professional hospital-affiliated clinics', () => {
  const pro = calculateLeadScore({
    website: 'https://modernclinic.pk',
    websiteClassification: 'Professionally developed website',
    practiceType: 'hospital_affiliated',
    phone: '+924235761234',
    email: 'care@modernclinic.pk',
    latestAudit: {
      hasAppointmentBooking: true,
      mobileResponsive: true,
    },
  });
  assert.equal(pro.score, 5);
  assert.equal(pro.priority, 'Low');
});
