import type { DoctorRecord, LeadStatus } from '../types/domain';

export interface EmailTemplate {
  id: string;
  name: string;
  category: string;
  targetStatuses: LeadStatus[];
  subject: string;
  body: string;
  isCustom?: boolean;
}

export const CUSTOM_TEMPLATES_STORAGE_KEY = 'lahoremed_custom_email_templates';

export const EMAIL_TEMPLATE_PLACEHOLDERS = [
  { token: '{{doctorName}}', description: "Doctor's full professional name" },
  { token: '{{clinicName}}', description: 'Clinic or hospital name' },
  { token: '{{speciality}}', description: 'Medical speciality' },
  { token: '{{area}}', description: 'Lahore neighbourhood / zone' },
  { token: '{{website}}', description: 'Official website URL or fallback note' },
  { token: '{{websiteStatus}}', description: 'Website audit classification' },
  { token: '{{auditSummary}}', description: 'Top detected technical or booking gaps' },
  { token: '{{leadStatus}}', description: 'Current CRM pipeline status' },
  { token: '{{opportunityValue}}', description: 'Estimated PKR deal value' },
  { token: '{{senderName}}', description: 'Outreach sender name or team' },
] as const;

export const PREDEFINED_EMAIL_TEMPLATES: EmailTemplate[] = [
  {
    id: 'new-no-website',
    name: 'No-Website Clinic Introduction',
    category: 'First Outreach',
    targetStatuses: ['New', 'Researching'],
    subject: 'Dedicated clinic website & patient booking for {{clinicName}} ({{area}})',
    body: `Assalam-o-Alaikum {{doctorName}},

I came across {{clinicName}} while reviewing leading {{speciality}} practices in {{area}}, Lahore. Noticeably, {{clinicName}} currently has {{website}}, which means patients searching on Google Maps or mobile often rely on third-party aggregators to reach your front desk.

We specialize in building fast, mobile-first websites and direct WhatsApp/online appointment booking systems specifically for private medical practices in Lahore.

Would you or your clinic coordinator be open to a brief 10-minute preview tailored for {{clinicName}} this week?

Warm regards,
{{senderName}}`,
  },
  {
    id: 'new-website-audit',
    name: 'Technical Website Audit Findings',
    category: 'Website Audit',
    targetStatuses: ['New', 'Researching'],
    subject: 'Quick website & mobile audit notes for {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

While evaluating online visibility for {{speciality}} clinics in {{area}}, Lahore, we ran a brief technical check on {{clinicName}} ({{website}}).

Our automated check flagged: {{websiteStatus}} — specifically {{auditSummary}}.

Fixing these fundamentals typically lifts direct patient appointment inquiries without increasing ad spend. I have prepared a short 3-point summary for {{clinicName}} if you would like me to share it.

Best regards,
{{senderName}}`,
  },
  {
    id: 'contacted-intro',
    name: 'Initial Outreach — Lahore Patient Search',
    category: 'First Outreach',
    targetStatuses: ['Contacted', 'New'],
    subject: 'Helping {{area}} patients book directly with {{doctorName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Following up on our initial note regarding {{clinicName}} in {{area}}. Patients looking for {{speciality}} care across Lahore increasingly check clinic timings, consultation fees, and online booking before calling.

We help clinics like {{clinicName}} turn local search traffic into confirmed appointments with a clean doctor profile, bilingual/mobile-friendly layout, and Google Maps SEO alignment.

Let me know if Thursday or Friday afternoon works for a short walkthrough.

Sincerely,
{{senderName}}`,
  },
  {
    id: 'followup-portfolio',
    name: 'Gentle Follow-Up + Sample Case Notes',
    category: 'Follow-Up',
    targetStatuses: ['Follow-up required', 'Contacted'],
    subject: 'Following up: Digital presence & booking flow for {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

I wanted to circle back briefly on our previous message about strengthening {{clinicName}}'s online patient acquisition in {{area}}.

Given your current status ({{websiteStatus}}), addressing {{auditSummary}} is the quickest win for {{speciality}} clinics looking to capture high-intent Lahore patients directly.

Happy to send over 2 concise clinic examples from Gulberg and DHA so you can see the turnaround time and structure.

Best regards,
{{senderName}}`,
  },
  {
    id: 'interested-discovery',
    name: 'Interested Lead — Discovery & Mockup Offer',
    category: 'Discovery & Demo',
    targetStatuses: ['Interested'],
    subject: 'Custom homepage concept & booking flow for {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Thank you for expressing interest in upgrading {{clinicName}}'s digital footprint.

Based on your {{speciality}} practice in {{area}} ({{websiteStatus}}), I would love to put together a tailored homepage & appointment booking mockup for {{doctorName}} before we discuss scope.

Could you reply with your preferred 15-minute slot this week and any specific clinic services you want highlighted?

Warm regards,
{{senderName}}`,
  },
  {
    id: 'meeting-confirmation',
    name: 'Meeting Scheduled — Confirmation & Agenda',
    category: 'Meeting & Agenda',
    targetStatuses: ['Meeting scheduled'],
    subject: 'Confirmed: Digital Growth Review for {{doctorName}} — {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Looking forward to our upcoming session regarding {{clinicName}} ({{area}}, Lahore).

Here is our brief 15-minute agenda:
1. Review current audit findings ({{websiteStatus}}: {{auditSummary}})
2. Walk through a mobile appointment booking & WhatsApp triage flow for {{speciality}} patients
3. Align on timeline, deliverables, and transparent pricing ({{opportunityValue}})

Please let us know if any clinic manager or partner should also be looped into the invite.

Best regards,
{{senderName}}`,
  },
  {
    id: 'proposal-walkthrough',
    name: 'Proposal Sent — Scope & ROI Follow-Up',
    category: 'Proposal',
    targetStatuses: ['Proposal sent'],
    subject: 'Proposal summary ({{opportunityValue}}) — {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Checking in to ensure you received the digital growth proposal ({{opportunityValue}}) tailored for {{clinicName}} in {{area}}.

Our focus remains resolving {{auditSummary}} so your clinic captures direct appointments without ongoing commission fees. I am happy to walk through any line items or adjust launch priorities to match your clinic schedule.

Warm regards,
{{senderName}}`,
  },
  {
    id: 'negotiating-milestones',
    name: 'Negotiating — Phased Rollout & Milestones',
    category: 'Closing',
    targetStatuses: ['Negotiating'],
    subject: 'Flexible phased rollout option for {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Thank you for your candid feedback on the proposal for {{clinicName}} ({{opportunityValue}}).

To make onboarding effortless for your team in {{area}}, we can split the engagement into two clear milestones:
- Phase 1: Mobile clinic website, SSL security, {{doctorName}} profile & WhatsApp/online booking launch
- Phase 2: Local Lahore SEO optimization for {{speciality}} queries & Google Business Profile enhancement

Let me know if this phased structure aligns with your clinic's timeline so we can finalize the kickoff date.

Sincerely,
{{senderName}}`,
  },
  {
    id: 'converted-onboarding',
    name: 'Converted — Welcome & Onboarding Kickoff',
    category: 'Onboarding',
    targetStatuses: ['Converted'],
    subject: 'Welcome aboard! Onboarding checklist for {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

We are excited to partner with {{clinicName}} in {{area}}!

To kick off your project smoothly, could your team share the following items over the next 2–3 days:
1. Clinic logo (or brand colors) and high-resolution headshot of {{doctorName}}
2. Updated OPD consultation timings, room/branch details, and fee structure (if public)
3. Official WhatsApp desk number and preferred domain name

We will share your staging preview link as soon as Phase 1 content is assembled.

Warm regards,
{{senderName}}`,
  },
  {
    id: 'not-interested-checkin',
    name: 'Not Interested — Respectful Closing Note',
    category: 'Re-Engagement',
    targetStatuses: ['Not interested'],
    subject: 'Thank you for your time — {{clinicName}}',
    body: `Assalam-o-Alaikum {{doctorName}},

Thank you for letting us know that digital upgrades are not a priority for {{clinicName}} right now. We completely respect your schedule and will pause our outreach.

Whenever you decide to revisit online patient booking or local SEO in {{area}}, feel free to reply to this thread and we will be glad to assist. Wishing {{clinicName}} continued success.

Best regards,
{{senderName}}`,
  },
];

export function isTemplateRecommendedForStatus(
  template: EmailTemplate,
  status: LeadStatus
): boolean {
  return template.targetStatuses.includes(status);
}

export function getTemplatesOrderedForStatus(
  status: LeadStatus,
  allTemplates: EmailTemplate[] = PREDEFINED_EMAIL_TEMPLATES
): EmailTemplate[] {
  const recommended = allTemplates.filter((t) => isTemplateRecommendedForStatus(t, status));
  const others = allTemplates.filter((t) => !isTemplateRecommendedForStatus(t, status));
  return [...recommended, ...others];
}

export function renderEmailTemplate(
  template: Pick<EmailTemplate, 'subject' | 'body'>,
  doctor: DoctorRecord,
  senderName = 'LahoreMedProspect Outreach Team'
): { subject: string; body: string } {
  const auditOpportunities = doctor.latestAudit?.improvementOpportunities ?? [];
  const auditSummary =
    auditOpportunities.length > 0
      ? auditOpportunities.slice(0, 2).join('; ')
      : doctor.website
      ? 'missing online appointment scheduling & local SEO optimization'
      : 'no dedicated clinic website or online appointment booking system';

  const replacements: Record<string, string> = {
    '{{doctorName}}': doctor.fullName,
    '{{clinicName}}': doctor.clinicName,
    '{{speciality}}': doctor.speciality,
    '{{area}}': doctor.area,
    '{{website}}': doctor.website || 'no official website listed',
    '{{websiteStatus}}': doctor.websiteClassification,
    '{{auditSummary}}': auditSummary,
    '{{leadStatus}}': doctor.leadStatus,
    '{{opportunityValue}}':
      doctor.opportunityValuePkr !== null
        ? `PKR ${doctor.opportunityValuePkr.toLocaleString()}`
        : 'custom clinic package',
    '{{senderName}}': senderName.trim() || 'LahoreMedProspect Outreach Team',
  };

  const substitute = (input: string): string => {
    let output = input;
    for (const [token, value] of Object.entries(replacements)) {
      output = output.split(token).join(value);
    }
    return output;
  };

  return {
    subject: substitute(template.subject),
    body: substitute(template.body),
  };
}

export function buildMailtoHref(
  toEmail: string | null | undefined,
  subject: string,
  body: string
): string | null {
  const cleanEmail = toEmail?.trim();
  if (!cleanEmail) return null;
  const params = new URLSearchParams({
    subject,
    body,
  });
  // URLSearchParams encodes spaces as '+', whereas mailto clients expect '%20'
  return `mailto:${encodeURIComponent(cleanEmail)}?${params.toString().replace(/\+/g, '%20')}`;
}

export function filterEmailTemplates(
  templates: EmailTemplate[],
  options: { query?: string; statusFilter?: LeadStatus | 'all' }
): EmailTemplate[] {
  const q = (options.query || '').trim().toLowerCase();
  const status = options.statusFilter || 'all';
  return templates.filter((t) => {
    if (status !== 'all' && !t.targetStatuses.includes(status)) {
      return false;
    }
    if (
      q &&
      !t.name.toLowerCase().includes(q) &&
      !t.category.toLowerCase().includes(q) &&
      !t.subject.toLowerCase().includes(q) &&
      !t.body.toLowerCase().includes(q)
    ) {
      return false;
    }
    return true;
  });
}

export function loadCustomEmailTemplates(): EmailTemplate[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(CUSTOM_TEMPLATES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is EmailTemplate =>
        Boolean(
          item &&
            typeof item.id === 'string' &&
            typeof item.name === 'string' &&
            typeof item.subject === 'string' &&
            typeof item.body === 'string' &&
            Array.isArray(item.targetStatuses)
        )
    );
  } catch {
    return [];
  }
}

export function saveCustomEmailTemplates(templates: EmailTemplate[]): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(CUSTOM_TEMPLATES_STORAGE_KEY, JSON.stringify(templates));
  } catch {
    // Ignore storage quota errors
  }
}
