import * as XLSX from 'xlsx';
import type { DoctorRecord } from '../types/domain';

function buildExportRows(doctors: DoctorRecord[]) {
  return doctors.map((d) => ({
    ID: d.id,
    'Doctor Name': d.fullName,
    Speciality: d.speciality,
    'Clinic Name': d.clinicName,
    'Practice Type': d.practiceType,
    'Doctor Status': d.doctorStatus,
    'PMDC Verified': d.pmdcVerified ? 'Yes' : 'No',
    Availability: d.availability || '',
    'Experience (Years)': d.experienceYears ?? '',
    Qualifications: d.qualifications || '',
    'Consultation Fee (PKR)': d.consultationFeePkr ?? '',
    Rating: d.rating ?? '',
    Reviews: d.reviewCount ?? '',
    'Patient Satisfaction': d.patientSatisfaction || '',
    'Wait Time': d.waitTime || '',
    'Video Consultation': d.videoConsultation ? 'Yes' : 'No',
    Area: d.area,
    Address: d.address || '',
    'Public Phone': d.phone || '',
    'Public Email': d.email || '',
    'Official Website': d.website || '',
    'Website Classification': d.websiteClassification,
    'Lead Score': d.leadScore,
    'Lead Priority': d.leadPriority,
    'Lead Status': d.leadStatus,
    'Opportunity Value (PKR)': d.opportunityValuePkr ?? '',
    'Next Follow-Up': d.nextFollowUpAt ? d.nextFollowUpAt.slice(0, 10) : '',
    'Google Maps URL': d.googleMapsUrl || '',
    'Profile URL': d.profileUrl || '',
    'Data Source': d.dataSource,
    'Data Origin': d.dataOrigin,
    'Last Verified': d.lastVerifiedAt ? d.lastVerifiedAt.slice(0, 10) : '',
    Notes: d.notes || '',
  }));
}

export function exportDoctorsToCsv(doctors: DoctorRecord[], filename = 'lahore-doctor-leads.csv') {
  const rows = buildExportRows(doctors);
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportDoctorsToExcel(doctors: DoctorRecord[], filename = 'lahore-doctor-leads.xlsx') {
  const rows = buildExportRows(doctors);
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Lahore Doctors');
  XLSX.writeFile(workbook, filename);
}

export async function parseSpreadsheetFile(file: File): Promise<Array<Record<string, string>>> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const firstSheet = workbook.SheetNames[0];
  if (!firstSheet) return [];
  const worksheet = workbook.Sheets[firstSheet];
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, { defval: '' });
  return rawRows.map((row) => {
    const clean: Record<string, string> = {};
    for (const [k, v] of Object.entries(row)) {
      clean[k.trim()] = String(v ?? '').trim();
    }
    return clean;
  });
}
