import type { WebsiteClassification } from '../types/domain';

export interface HtmlAnalysisInput {
  url: string;
  httpStatus: number | null;
  loadTimeMs: number | null;
  sslValid: boolean;
  html: string | null;
  fetchError?: string | null;
}

export interface HtmlAnalysisOutput {
  classification: WebsiteClassification;
  httpStatus: number | null;
  sslValid: boolean;
  mobileResponsive: boolean;
  loadTimeMs: number | null;
  hasAppointmentBooking: boolean;
  hasDoctorProfile: boolean;
  hasSeoFundamentals: boolean;
  improvementOpportunities: string[];
}

export function isSafePublicHttpUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return false;
    }
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '0.0.0.0' ||
      host === '::1' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      host.startsWith('169.254.') ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
      host.endsWith('.local') ||
      host.endsWith('.internal')
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function analyzeWebsiteHtml(input: HtmlAnalysisInput): HtmlAnalysisOutput {
  const opportunities: string[] = [];

  if (input.fetchError || input.httpStatus === null || input.httpStatus >= 400) {
    opportunities.push(
      input.httpStatus
        ? `Website returned HTTP ${input.httpStatus} error status`
        : `Website unreachable during check (${input.fetchError || 'connection failed'})`
    );
    opportunities.push('Verify domain hosting, DNS configuration, and SSL certificate');
    return {
      classification: 'Website unavailable',
      httpStatus: input.httpStatus,
      sslValid: input.sslValid,
      mobileResponsive: false,
      loadTimeMs: input.loadTimeMs,
      hasAppointmentBooking: false,
      hasDoctorProfile: false,
      hasSeoFundamentals: false,
      improvementOpportunities: opportunities,
    };
  }

  const html = (input.html || '').toLowerCase();

  // Check mobile responsiveness signals
  const hasViewportMeta =
    /<meta[^>]+name=["']viewport["'][^>]*>/i.test(html) ||
    html.includes('width=device-width');
  const hasResponsiveFramework =
    html.includes('@media') ||
    html.includes('tailwind') ||
    html.includes('bootstrap') ||
    html.includes('flex') ||
    html.includes('grid');
  const mobileResponsive = hasViewportMeta && (hasResponsiveFramework || html.length > 0);

  // Check appointment / booking functionality
  const bookingKeywords = [
    'book appointment',
    'book an appointment',
    'schedule appointment',
    'appointment',
    'book now',
    'book consultation',
    'calendly',
    'wa.me/',
    'whatsapp',
    'online booking',
    'reserve',
  ];
  const hasAppointmentBooking = bookingKeywords.some((kw) => html.includes(kw));

  // Check doctor profile signals
  const profileKeywords = [
    'dr.',
    'mbbs',
    'fcps',
    'md',
    'consultant',
    'specialist',
    'qualifications',
    'experience',
    'pmdc',
    'about doctor',
    'our doctors',
  ];
  const hasDoctorProfile = profileKeywords.some((kw) => html.includes(kw));

  // Check SEO fundamentals
  const hasTitle = /<title>[^<]{5,}<\/title>/i.test(html);
  const hasMetaDesc = /<meta[^>]+name=["']description["'][^>]*content=["'][^"']{10,}["']/i.test(
    html
  );
  const hasH1 = /<h1[\s>]/i.test(html);
  const hasSeoFundamentals = hasTitle && hasMetaDesc && hasH1;

  // Check outdated web markers
  const hasLegacyMarkup =
    html.includes('<marquee') ||
    html.includes('<frameset') ||
    html.includes('jquery-1.') ||
    html.includes('flashplayer') ||
    html.includes('frontpage') ||
    !input.sslValid;

  const isSlow = (input.loadTimeMs ?? 0) > 2500;

  if (!input.sslValid) {
    opportunities.push('Missing HTTPS / SSL encryption — browsers mark site as Not Secure');
  }
  if (!mobileResponsive) {
    opportunities.push('Missing responsive viewport meta tag for mobile patients');
  }
  if (isSlow) {
    opportunities.push(`Slow page load (${input.loadTimeMs}ms) — optimize assets and caching`);
  }
  if (!hasAppointmentBooking) {
    opportunities.push('No online appointment booking form or direct WhatsApp scheduling CTA');
  }
  if (!hasDoctorProfile) {
    opportunities.push('Missing structured doctor credentials (PMDC/MBBS/FCPS) and bio section');
  }
  if (!hasSeoFundamentals) {
    opportunities.push(
      'Incomplete local SEO tags (missing title, meta description, or H1 structure)'
    );
  }
  if (hasLegacyMarkup) {
    opportunities.push('Legacy HTML/script patterns detected — modernize UI architecture');
  }

  let classification: WebsiteClassification = 'Professionally developed website';

  if (hasLegacyMarkup || (!input.sslValid && !mobileResponsive)) {
    classification = 'Outdated website';
  } else if (!mobileResponsive) {
    classification = 'Poor mobile responsiveness';
  } else if (isSlow) {
    classification = 'Slow website';
  } else if (!hasAppointmentBooking) {
    classification = 'Missing appointment functionality';
  } else if (!hasDoctorProfile) {
    classification = 'Missing doctor profile';
  } else if (!hasSeoFundamentals) {
    classification = 'Missing SEO fundamentals';
  }

  return {
    classification,
    httpStatus: input.httpStatus,
    sslValid: input.sslValid,
    mobileResponsive,
    loadTimeMs: input.loadTimeMs,
    hasAppointmentBooking,
    hasDoctorProfile,
    hasSeoFundamentals,
    improvementOpportunities: opportunities,
  };
}
