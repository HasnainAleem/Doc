import test from 'node:test';
import assert from 'node:assert/strict';
import {
  PREDEFINED_EMAIL_TEMPLATES,
  buildMailtoHref,
  filterEmailTemplates,
  getTemplatesOrderedForStatus,
  renderEmailTemplate,
} from './emailTemplates';
import type { DoctorRecord } from '../types/domain';

const sampleDoctor: DoctorRecord = {
  id: 42,
  fullName: 'Dr. Ayesha Tariq',
  speciality: 'Dermatologists',
  clinicId: 7,
  clinicName: 'Dermacare Lahore',
  practiceType: 'independent',
  doctorStatus: 'PMDC Verified',
  pmdcVerified: true,
  availability: 'Mon–Sat 5:00 PM – 9:00 PM',
  experienceYears: 12,
  qualifications: 'MBBS, FCPS (Dermatology)',
  consultationFeePkr: 3000,
  rating: 4.9,
  reviewCount: 64,
  patientSatisfaction: '96%',
  waitTime: 'Under 15 Min',
  videoConsultation: true,
  phone: '+923004128910',
  email: 'appointments@dermacare.pk',
  website: null,
  address: 'Main Boulevard, Gulberg III, Lahore',
  area: 'Gulberg',
  lat: 31.51,
  lng: 74.35,
  googleMapsUrl: null,
  googlePlaceId: null,
  profileUrl: null,
  socialLinks: {},
  dataSource: 'Sample Dataset',
  sourceUrl: null,
  dataOrigin: 'sample',
  lastVerifiedAt: '2026-11-01T00:00:00.000Z',
  websiteClassification: 'No website found',
  leadScore: 85,
  leadPriority: 'High',
  leadStatus: 'Interested',
  opportunityValuePkr: 175000,
  nextFollowUpAt: null,
  notes: null,
  dedupeKey: 'ayesha-tariq-dermatologists-dermacare-gulberg',
  createdAt: '2026-11-01T00:00:00.000Z',
  updatedAt: '2026-11-01T00:00:00.000Z',
  latestAudit: null,
  activities: [],
};

test('PREDEFINED_EMAIL_TEMPLATES covers all 10 CRM lead statuses', () => {
  const covered = new Set(PREDEFINED_EMAIL_TEMPLATES.flatMap((t) => t.targetStatuses));
  for (const status of [
    'New',
    'Researching',
    'Contacted',
    'Follow-up required',
    'Interested',
    'Meeting scheduled',
    'Proposal sent',
    'Negotiating',
    'Converted',
    'Not interested',
  ] as const) {
    assert.equal(covered.has(status), true, `Missing template coverage for ${status}`);
  }
});

test('getTemplatesOrderedForStatus places matching status templates first', () => {
  const ordered = getTemplatesOrderedForStatus('Proposal sent');
  assert.equal(ordered[0].targetStatuses.includes('Proposal sent'), true);
  assert.equal(ordered.length, PREDEFINED_EMAIL_TEMPLATES.length);
});

test('renderEmailTemplate substitutes all doctor, clinic, and opportunity tokens cleanly', () => {
  const template = PREDEFINED_EMAIL_TEMPLATES.find((t) => t.id === 'interested-discovery')!;
  const rendered = renderEmailTemplate(template, sampleDoctor, 'Lahore Growth Desk');

  assert.match(rendered.subject, /Dermacare Lahore/);
  assert.match(rendered.body, /Dr\. Ayesha Tariq/);
  assert.match(rendered.body, /Gulberg/);
  assert.match(rendered.body, /Dermatologists/);
  assert.match(rendered.body, /Lahore Growth Desk/);
  assert.equal(rendered.subject.includes('{{'), false);
  assert.equal(rendered.body.includes('{{'), false);
});

test('buildMailtoHref encodes recipient, subject, and body properly or returns null when email missing', () => {
  assert.equal(buildMailtoHref(null, 'Hello', 'Body'), null);
  const href = buildMailtoHref('appointments@dermacare.pk', 'Clinic Review', 'Hello Doctor');
  assert.ok(href);
  assert.match(href, /^mailto:appointments%40dermacare\.pk\?/);
  assert.match(href, /subject=Clinic%20Review/);
  assert.match(href, /body=Hello%20Doctor/);
});

test('filterEmailTemplates filters by lead status and search keyword', () => {
  const filteredByStatus = filterEmailTemplates(PREDEFINED_EMAIL_TEMPLATES, {
    statusFilter: 'Converted',
  });
  assert.equal(filteredByStatus.length, 1);
  assert.equal(filteredByStatus[0].id, 'converted-onboarding');

  const filteredByQuery = filterEmailTemplates(PREDEFINED_EMAIL_TEMPLATES, {
    query: 'phased rollout',
  });
  assert.equal(filteredByQuery.length, 1);
  assert.equal(filteredByQuery[0].id, 'negotiating-milestones');
});
