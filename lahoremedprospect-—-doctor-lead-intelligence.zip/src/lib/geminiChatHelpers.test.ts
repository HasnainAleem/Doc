import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CHATBOT_ROLES,
  formatDoctorContextForChat,
  getChatbotRole,
  toGeminiHistory,
} from './geminiChatHelpers';

test('CHATBOT_ROLES provides distinct roles with non-empty system instructions', () => {
  assert.equal(CHATBOT_ROLES.length, 3);
  for (const role of CHATBOT_ROLES) {
    assert.ok(role.systemInstruction.length > 40);
    assert.ok(role.starterPrompts.length >= 2);
  }
  assert.equal(getChatbotRole('website_analyst').id, 'website_analyst');
});

test('toGeminiHistory strips leading model turns, empty text, and merges consecutive same-role turns', () => {
  const history = toGeminiHistory([
    { role: 'model', text: 'Welcome greeting' },
    { role: 'user', text: 'First question' },
    { role: 'user', text: '   ' },
    { role: 'user', text: 'Clarification' },
    { role: 'model', text: 'Detailed reply' },
  ]);

  assert.equal(history.length, 2);
  assert.equal(history[0].role, 'user');
  assert.deepEqual(history[0].parts, [{ text: 'First question' }, { text: 'Clarification' }]);
  assert.equal(history[1].role, 'model');
  assert.deepEqual(history[1].parts, [{ text: 'Detailed reply' }]);
});

test('formatDoctorContextForChat includes clinic, area, lead status, and website classification', () => {
  const summary = formatDoctorContextForChat({
    fullName: 'Dr. Kamran Siddiqui',
    speciality: 'Cardiologists',
    clinicName: 'HeartBeat Diagnostics',
    area: 'Gulberg',
    leadStatus: 'Proposal sent',
    leadScore: 65,
    leadPriority: 'Medium',
    website: 'http://heartbeat.pk',
    websiteClassification: 'Outdated website',
    opportunityValuePkr: 150000,
  });

  assert.match(summary, /Dr\. Kamran Siddiqui/);
  assert.match(summary, /HeartBeat Diagnostics/);
  assert.match(summary, /Proposal sent/);
  assert.match(summary, /PKR 150,000/);
  assert.match(summary, /Outdated website/);
});
