import type { DoctorRecord, DoctorStatus } from '../types/domain';

export function parseExperienceYears(raw: string | number | null | undefined): number | null {
  if (typeof raw === 'number') {
    return Number.isFinite(raw) && raw >= 0 && raw <= 80 ? Math.round(raw) : null;
  }
  if (!raw || typeof raw !== 'string') return null;
  const match = raw.match(/(\d{1,2})\s*(?:\+?\s*)?(?:yrs?|years?)/i) || raw.match(/^(\d{1,2})$/);
  if (!match) return null;
  const val = Number(match[1]);
  return Number.isFinite(val) && val >= 0 && val <= 80 ? val : null;
}

export function parseFeePkr(raw: string | number | null | undefined): number | null {
  if (typeof raw === 'number') {
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw) : null;
  }
  if (!raw || typeof raw !== 'string') return null;
  const digits = raw.replace(/[^\d]/g, '');
  if (!digits) return null;
  const val = Number(digits);
  return Number.isFinite(val) && val > 0 ? val : null;
}

export function formatExperienceLabel(years: number | null | undefined): string {
  if (years === null || years === undefined || !Number.isFinite(years)) return 'Not listed';
  return years === 1 ? '1 yr exp' : `${years} yrs exp`;
}

export function extractMetadataFromNotes(notes: string | null | undefined): {
  qualifications: string | null;
  experienceYears: number | null;
  rating: number | null;
  reviewCount: number | null;
  consultationFeePkr: number | null;
} {
  if (!notes) {
    return {
      qualifications: null,
      experienceYears: null,
      rating: null,
      reviewCount: null,
      consultationFeePkr: null,
    };
  }

  const qualMatch = notes.match(/Qualifications:\s*([^·]+)/i);
  const expMatch = notes.match(/Experience:\s*([^·]+)/i);
  const ratingMatch = notes.match(/Rating:\s*([\d.]+)\s*\/\s*5(?:\s*\((\d+)\s*reviews?\))?/i);
  const feeMatch = notes.match(/Consultation Fee:\s*([^·]+)/i);

  return {
    qualifications: qualMatch ? qualMatch[1].trim() || null : null,
    experienceYears: expMatch ? parseExperienceYears(expMatch[1]) : null,
    rating: ratingMatch ? Number(ratingMatch[1]) || null : null,
    reviewCount: ratingMatch && ratingMatch[2] ? Number(ratingMatch[2]) || null : null,
    consultationFeePkr: feeMatch ? parseFeePkr(feeMatch[1]) : null,
  };
}

/**
 * Normalizes a partial or legacy DoctorRecord (for instance, from localStorage cache
 * or PostgreSQL rows) so status, availability, experience, and website fields are always typed.
 */
export function hydrateDoctorRecord(doc: DoctorRecord): DoctorRecord {
  const fromNotes = extractMetadataFromNotes(doc.notes);
  const pmdcVerified = Boolean(doc.pmdcVerified);
  const videoConsultation = Boolean(doc.videoConsultation);
  const doctorStatus: DoctorStatus =
    doc.doctorStatus ||
    (pmdcVerified
      ? 'PMDC Verified'
      : doc.clinicName.toLowerCase().includes('online video consultation')
      ? 'Online Video Only'
      : 'Active Practice');

  return {
    ...doc,
    doctorStatus,
    pmdcVerified,
    availability: doc.availability ?? null,
    experienceYears: doc.experienceYears ?? fromNotes.experienceYears,
    qualifications: doc.qualifications ?? fromNotes.qualifications,
    consultationFeePkr: doc.consultationFeePkr ?? fromNotes.consultationFeePkr,
    rating: doc.rating ?? fromNotes.rating,
    reviewCount: doc.reviewCount ?? fromNotes.reviewCount,
    patientSatisfaction: doc.patientSatisfaction ?? null,
    waitTime: doc.waitTime ?? null,
    videoConsultation,
  };
}

export function isAvailableTodayOrSoon(availability: string | null | undefined): boolean {
  if (!availability) return false;
  return /\b(available|today|tomorrow|mon|tue|wed|thu|fri|sat|sun|daily|walk-in)\b/i.test(
    availability
  );
}
