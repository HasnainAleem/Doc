import type { DoctorRecord, LeadActivity, LeadPriority, LeadStatus } from '../types/domain';

export interface BulkDoctorPatch {
  leadStatus?: LeadStatus;
  leadPriority?: LeadPriority;
}

export function toggleIdSelection(selectedIds: number[], id: number): number[] {
  return selectedIds.includes(id)
    ? selectedIds.filter((item) => item !== id)
    : [...selectedIds, id];
}

export function toggleSelectAllVisible(
  selectedIds: number[],
  visibleIds: number[]
): number[] {
  if (visibleIds.length === 0) return selectedIds;
  const visibleSet = new Set(visibleIds);
  const allVisibleSelected = visibleIds.every((id) => selectedIds.includes(id));

  if (allVisibleSelected) {
    return selectedIds.filter((id) => !visibleSet.has(id));
  }

  const merged = new Set(selectedIds);
  for (const id of visibleIds) {
    merged.add(id);
  }
  return Array.from(merged);
}

export function applyBulkPatchToDoctors(
  doctors: DoctorRecord[],
  targetIds: number[],
  patch: BulkDoctorPatch,
  actorEmail = 'preview@lahoremedprospect.local',
  timestamp = new Date().toISOString()
): DoctorRecord[] {
  if (targetIds.length === 0 || (!patch.leadStatus && !patch.leadPriority)) {
    return doctors;
  }

  const targetSet = new Set(targetIds);

  return doctors.map((doc) => {
    if (!targetSet.has(doc.id)) return doc;

    const activities: LeadActivity[] = [...(doc.activities || [])];
    const nextStatus = patch.leadStatus ?? doc.leadStatus;
    const nextPriority = patch.leadPriority ?? doc.leadPriority;

    if (patch.leadStatus && patch.leadStatus !== doc.leadStatus) {
      activities.unshift({
        id: Date.now() + doc.id,
        doctorId: doc.id,
        type: 'status_change',
        summary: `Bulk status updated to ${patch.leadStatus}`,
        details: `Previous: ${doc.leadStatus}`,
        followUpDate: null,
        createdBy: actorEmail,
        createdAt: timestamp,
      });
    }

    if (patch.leadPriority && patch.leadPriority !== doc.leadPriority) {
      activities.unshift({
        id: Date.now() + doc.id + 1000,
        doctorId: doc.id,
        type: 'status_change',
        summary: `Bulk priority set to ${patch.leadPriority}`,
        details: `Previous: ${doc.leadPriority}`,
        followUpDate: null,
        createdBy: actorEmail,
        createdAt: timestamp,
      });
    }

    return {
      ...doc,
      leadStatus: nextStatus,
      leadPriority: nextPriority,
      activities,
      updatedAt: timestamp,
    };
  });
}
