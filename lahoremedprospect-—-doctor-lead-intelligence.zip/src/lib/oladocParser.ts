import type { DoctorStatus, LahoreArea, MedicalSpeciality, PracticeType } from '../types/domain';
import { LAHORE_AREAS, MEDICAL_SPECIALITIES } from '../types/domain';
import { buildDoctorDedupeKey, inferLahoreArea, inferSpeciality } from './normalization';
import { parseExperienceYears, parseFeePkr } from './doctorMetadata';
import { LAHORE_AREA_COORDS } from './sampleData';

export const OLADOC_BASE_URL = 'https://oladoc.com';
export const OLADOC_LAHORE_BASE = `${OLADOC_BASE_URL}/pakistan/lahore`;

/**
 * Centralized oladoc helpline numbers that belong to the aggregator's call center,
 * NOT the doctor's or clinic's direct public business phone.
 */
export const OLADOC_HELPLINE_PHONES = new Set([
  '04238900939',
  '+924238900939',
  '924238900939',
  '042-38900939',
]);

export const OLADOC_SPECIALITY_SLUGS: Record<MedicalSpeciality, string> = {
  Dermatologists: 'dermatologist',
  Cardiologists: 'cardiologist',
  Dentists: 'dentist',
  Gynecologists: 'gynecologist',
  Neurologists: 'neurologist',
  'Orthopedic surgeons': 'orthopedic-surgeon',
  'General physicians': 'general-physician',
  Pediatricians: 'child-specialist',
  Psychiatrists: 'psychiatrist',
  'Plastic surgeons': 'plastic-surgeon',
  Physiotherapists: 'physiotherapist',
  Ophthalmologists: 'eye-specialist',
  'ENT specialists': 'ent-specialist',
  Urologists: 'urologist',
  Gastroenterologists: 'gastroenterologist',
  'Aesthetic physicians': 'aesthetic-medicine-specialist',
};

export const OLADOC_AREA_SLUGS: Record<LahoreArea, string> = {
  Gulberg: 'gulberg',
  DHA: 'dha',
  'Johar Town': 'johar-town',
  'Model Town': 'model-town',
  'Garden Town': 'garden-town',
  'Faisal Town': 'faisal-town',
  'Bahria Town': 'bahria-town',
  Township: 'township',
  'Wapda Town': 'wapda-town',
  'Muslim Town': 'muslim-town',
  'Cavalry Ground': 'cavalry-ground',
  'Allama Iqbal Town': 'allama-iqbal-town',
  Shadman: 'shadman',
  Ichhra: 'ichra',
  Cantt: 'lahore-cantt',
};

export interface ParsedOladocDoctor {
  fullName: string;
  speciality: string;
  clinicName: string;
  practiceType: PracticeType;
  doctorStatus: DoctorStatus;
  pmdcVerified: boolean;
  availability: string | null;
  experienceYears: number | null;
  qualifications: string | null;
  consultationFeePkr: number | null;
  rating: number | null;
  reviewCount: number | null;
  patientSatisfaction: string | null;
  waitTime: string | null;
  videoConsultation: boolean;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  area: string;
  lat: number | null;
  lng: number | null;
  googleMapsUrl: string | null;
  googlePlaceId: string | null;
  profileUrl: string;
  dataSource: string;
  sourceUrl: string;
  dataOrigin: 'verified';
  lastVerifiedAt: string;
  dedupeKey: string;
  notes: string | null;
}

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;|&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function stripTags(input: string): string {
  return decodeHtmlEntities(
    input
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/-->/g, ' ')
      .replace(/<[^>]+>/g, ' ')
  );
}

export function buildOladocListingUrl(params: {
  speciality: string;
  area?: string | null;
  offset?: number;
}): string {
  const specSlug =
    OLADOC_SPECIALITY_SLUGS[params.speciality as MedicalSpeciality] ||
    params.speciality.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

  const cleanArea = params.area && params.area !== 'All Lahore' ? params.area : null;
  const areaSlug = cleanArea
    ? OLADOC_AREA_SLUGS[cleanArea as LahoreArea] ||
      cleanArea.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
    : null;

  const base = areaSlug
    ? `${OLADOC_LAHORE_BASE}/${areaSlug}/${specSlug}`
    : `${OLADOC_LAHORE_BASE}/${specSlug}`;

  if (params.offset && params.offset > 0) {
    return `${base}/${params.offset}`;
  }
  return base;
}

export function extractOladocTotalCount(html: string): number {
  const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (h1Match) {
    const clean = stripTags(h1Match[1]);
    const numMatch = clean.match(/^(\d[\d,]*)\s+/);
    if (numMatch) {
      const n = Number(numMatch[1].replace(/,/g, ''));
      if (Number.isFinite(n) && n > 0) return n;
    }
  }
  return 0;
}

interface PhysicianJsonLd {
  name?: string;
  url?: string;
  description?: string;
  address?: {
    streetAddress?: string;
    addressLocality?: string;
    addressRegion?: string;
  };
  areaServed?: Array<{
    name?: string;
    geoMidpoint?: {
      latitude?: number | string;
      longitude?: number | string;
    };
  }>;
  openingHours?: string;
  priceRange?: string;
}

function extractPhysicianJsonLdMap(html: string): Map<string, PhysicianJsonLd> {
  const map = new Map<string, PhysicianJsonLd>();
  const matches = html.matchAll(
    /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi
  );

  for (const m of matches) {
    try {
      const parsed = JSON.parse(m[1].trim());
      const items = Array.isArray(parsed) ? parsed : [parsed];
      for (const item of items) {
        if (item && item['@type'] === 'Physician' && typeof item.url === 'string') {
          map.set(item.url.trim(), item as PhysicianJsonLd);
        }
      }
    } catch {
      // Ignore malformed JSON-LD blocks
    }
  }

  return map;
}

function normalizeOladocArea(rawArea: string | null | undefined, fallbackArea?: string): string {
  const candidate = (rawArea || '').trim();
  if (/^ichra$/i.test(candidate)) return 'Ichhra';
  if (/^lahore cantt$/i.test(candidate)) return 'Cantt';
  if (/^dha defence$/i.test(candidate)) return 'DHA';
  if (candidate) {
    const resolved = inferLahoreArea(candidate);
    if ((LAHORE_AREAS as readonly string[]).includes(resolved)) {
      return resolved;
    }
    if (!/^lahore$/i.test(resolved) && !/video consultation/i.test(resolved)) {
      return resolved;
    }
  }
  if (fallbackArea && fallbackArea !== 'All Lahore') {
    return fallbackArea;
  }
  return 'Gulberg';
}

function splitClinicAndArea(locationLabel: string): { clinicName: string; areaHint: string | null } {
  const clean = decodeHtmlEntities(locationLabel);
  const parenMatch = clean.match(/^(.*?)\s*\(([^()]+)\)\s*$/);
  if (parenMatch) {
    return {
      clinicName: parenMatch[1].trim(),
      areaHint: parenMatch[2].trim(),
    };
  }
  return { clinicName: clean, areaHint: null };
}

function inferPracticeTypeFromClinic(clinicName: string): PracticeType {
  const lower = clinicName.toLowerCase();
  if (
    lower.includes('hospital') ||
    lower.includes('institute') ||
    lower.includes('teaching') ||
    lower.includes('complex')
  ) {
    return 'hospital_affiliated';
  }
  if (
    lower.includes('medical center') ||
    lower.includes('medical centre') ||
    lower.includes('polyclinic') ||
    lower.includes('group')
  ) {
    return 'clinic_group';
  }
  return 'independent';
}

export function parseOladocListingPage(
  html: string,
  pageUrl: string,
  options: {
    fallbackSpeciality: string;
    fallbackArea?: string;
    verifiedAt?: string;
  }
): ParsedOladocDoctor[] {
  const ldByUrl = extractPhysicianJsonLdMap(html);
  const now = options.verifiedAt || new Date().toISOString();

  const cardStartRegex = /<div[^>]*\bclass="[^"]*\bdoc-listing-card\b[^"]*"[^>]*>/gi;
  const starts: number[] = [];
  let match: RegExpExecArray | null;
  while ((match = cardStartRegex.exec(html)) !== null) {
    starts.push(match.index);
  }

  const results: ParsedOladocDoctor[] = [];
  const seenProfiles = new Set<string>();

  for (let i = 0; i < starts.length; i++) {
    const start = starts[i];
    const end = i + 1 < starts.length ? starts[i + 1] : html.length;
    const cardHtml = html.slice(start, end);

    // Extract doctor name + profile URL
    const nameAnchor =
      cardHtml.match(
        /<a[^>]*\bclass="[^"]*\bdoctor-card__name\b[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i
      ) ||
      cardHtml.match(
        /<a[^>]*href="([^"]+)"[^>]*\bclass="[^"]*\bdoctor-card__name\b[^"]*"[^>]*>([\s\S]*?)<\/a>/i
      );

    if (!nameAnchor) continue;
    const profileUrl = nameAnchor[1].trim();
    const fullName = stripTags(nameAnchor[2]);
    if (!fullName || !profileUrl || seenProfiles.has(profileUrl)) continue;
    seenProfiles.add(profileUrl);

    const ld = ldByUrl.get(profileUrl);

    // PMDC Verified marker
    const pmdcVerified = /doctor-card__verified|PMDC Verified/i.test(cardHtml);

    // Speciality
    const specMatch = cardHtml.match(
      /<p[^>]*\bclass="[^"]*\bdoctor-card__specialization\b[^"]*"[^>]*>([\s\S]*?)<\/p>/i
    );
    const rawSpecText = specMatch ? stripTags(specMatch[1]) : '';
    const speciality =
      (MEDICAL_SPECIALITIES as readonly string[]).includes(options.fallbackSpeciality)
        ? options.fallbackSpeciality
        : inferSpeciality(rawSpecText || options.fallbackSpeciality);

    // Degrees, experience, satisfaction, wait time, rating
    const degMatch = cardHtml.match(
      /<p[^>]*\bclass="[^"]*\bdoctor-card__degrees\b[^"]*"[^>]*>([\s\S]*?)<\/p>/i
    );
    const qualifications = degMatch ? stripTags(degMatch[1]) || null : null;

    const expMatch = cardHtml.match(
      /<span[^>]*class="[^"]*doctor-card__stat-label[^"]*"[^>]*>\s*Experience\s*<\/span>\s*<span[^>]*class="[^"]*doctor-card__stat-value[^"]*"[^>]*>([\s\S]*?)<\/span>/i
    );
    const experience = expMatch ? stripTags(expMatch[1]) : '';
    const experienceYears = parseExperienceYears(experience);

    const satMatch = cardHtml.match(
      /<span[^>]*class="[^"]*doctor-card__stat-label[^"]*"[^>]*>\s*Satisfied\s*<\/span>\s*<span[^>]*class="[^"]*doctor-card__stat-value[^"]*"[^>]*>([\s\S]*?)<\/span>/i
    );
    const patientSatisfaction = satMatch ? stripTags(satMatch[1]) || null : null;

    const waitMatch = cardHtml.match(
      /<span[^>]*class="[^"]*doctor-card__stat-label[^"]*"[^>]*>\s*Wait\s*<\/span>\s*<span[^>]*class="[^"]*doctor-card__stat-value[^"]*"[^>]*>([\s\S]*?)<\/span>/i
    );
    const waitTime = waitMatch ? stripTags(waitMatch[1]) || null : null;

    const ratingMatch = cardHtml.match(
      /<span[^>]*class="[^"]*doctor-card__rating-value[^"]*"[^>]*>([\s\S]*?)<\/span>/i
    );
    const reviewsMatch = cardHtml.match(
      /<span[^>]*class="[^"]*doctor-card__reviews[^"]*"[^>]*>([\s\S]*?)<\/span>/i
    );
    const ratingStr = ratingMatch ? stripTags(ratingMatch[1]) : '';
    const reviewsStr = reviewsMatch ? stripTags(reviewsMatch[1]) : '';
    const parsedRating = ratingStr ? Number(ratingStr) : NaN;
    const rating = Number.isFinite(parsedRating) && parsedRating > 0 ? parsedRating : null;
    const revDigits = reviewsStr.replace(/[^\d]/g, '');
    const reviewCount = revDigits ? Number(revDigits) : null;

    // Parse location cards inside doctor-card__locations
    const locSectionMatch = cardHtml.match(
      /<div[^>]*\bclass="[^"]*\bdoctor-card__locations\b[^"]*"[^>]*>([\s\S]*?)(?:<\/div>\s*<\/div>\s*<\/div>|$)/i
    );
    const locSection = locSectionMatch ? locSectionMatch[1] : cardHtml;

    const locationCards: Array<{
      isVideo: boolean;
      label: string;
      fee: string;
      availability: string | null;
    }> = [];
    const locCardMatches = locSection.matchAll(
      /<a[^>]*class="([^"]*\bdoctor-listing-location-card\b[^"]*)"[^>]*>([\s\S]*?)<\/a>/gi
    );
    for (const lm of locCardMatches) {
      const cls = lm[1];
      const inner = lm[2];
      const locNameMatch = inner.match(
        /<span[^>]*class="[^"]*doctor-listing-location-card__name[^"]*"[^>]*>([\s\S]*?)<\/span>/i
      );
      if (!locNameMatch) continue;
      const label = stripTags(locNameMatch[1]);
      if (!label) continue;
      const isVideo =
        cls.includes('available-video-hospitalcard') ||
        /^online\s+video\s+consultation/i.test(label);
      const feeMatch = inner.match(
        /<span[^>]*class="[^"]*doctor-listing-location-card__fee[^"]*"[^>]*>([\s\S]*?)<\/span>/i
      );
      const fee = feeMatch ? stripTags(feeMatch[1]) : '';
      const availMatch = inner.match(
        /<span[^>]*class="[^"]*doctor-listing-location-card__availability-text[^"]*"[^>]*>([\s\S]*?)<\/span>/i
      );
      const availRaw = availMatch ? stripTags(availMatch[1]) : '';
      const availability =
        availRaw && availRaw.length > 2 && !/^w$/i.test(availRaw) ? availRaw : null;
      locationCards.push({ isVideo, label, fee, availability });
    }

    const physicalLocations = locationCards.filter((l) => !l.isVideo);
    const videoLocation = locationCards.find((l) => l.isVideo) || null;
    const videoConsultation = Boolean(videoLocation);
    const chosenLocation = physicalLocations[0] || locationCards[0] || null;

    let clinicName = 'Private Clinic (oladoc.com)';
    let areaHint: string | null = null;
    let feeText = '';

    if (chosenLocation) {
      feeText = chosenLocation.fee;
      if (chosenLocation.isVideo) {
        clinicName = 'Online Video Consultation (oladoc)';
      } else {
        const split = splitClinicAndArea(chosenLocation.label);
        clinicName = split.clinicName || chosenLocation.label;
        areaHint = split.areaHint;
      }
    }

    const consultationFeePkr = parseFeePkr(feeText || ld?.priceRange || null);

    // Combine availability text with JSON-LD openingHours if present
    const rawAvail =
      chosenLocation?.availability ||
      locationCards.find((l) => l.availability)?.availability ||
      null;
    const ldHours = ld?.openingHours?.trim() || null;
    const availability =
      rawAvail && ldHours && !rawAvail.toLowerCase().includes(ldHours.toLowerCase())
        ? `${rawAvail} · ${ldHours}`
        : rawAvail || (ldHours ? `Clinic hours: ${ldHours}` : null);

    const doctorStatus: DoctorStatus = pmdcVerified
      ? 'PMDC Verified'
      : physicalLocations.length === 0 && videoConsultation
      ? 'Online Video Only'
      : 'Active Practice';

    const ldStreet = ld?.address?.streetAddress?.trim() || null;
    const isVideoAddress = Boolean(
      ldStreet && /speak to doctor through a video call/i.test(ldStreet)
    );
    const cleanAddress =
      ldStreet && !isVideoAddress
        ? ldStreet
        : chosenLocation && !chosenLocation.isVideo
        ? `${clinicName}, ${areaHint || options.fallbackArea || 'Lahore'}, Lahore, Pakistan`
        : null;

    const ldAreaServed = ld?.areaServed?.find(
      (a) => a.name && !/video consultation/i.test(a.name)
    );
    const area = normalizeOladocArea(
      areaHint ||
        ldAreaServed?.name?.replace(/,\s*lahore$/i, '') ||
        cleanAddress,
      options.fallbackArea
    );

    let lat: number | null = null;
    let lng: number | null = null;
    const geoLat = Number(ldAreaServed?.geoMidpoint?.latitude);
    const geoLng = Number(ldAreaServed?.geoMidpoint?.longitude);
    if (Number.isFinite(geoLat) && Number.isFinite(geoLng) && geoLat !== 0 && geoLng !== 0) {
      lat = geoLat;
      lng = geoLng;
    } else {
      const areaCoords =
        LAHORE_AREA_COORDS[area] ||
        LAHORE_AREA_COORDS[inferLahoreArea(area)] ||
        LAHORE_AREA_COORDS['Gulberg'];
      if (areaCoords) {
        lat = areaCoords.lat;
        lng = areaCoords.lng;
      }
    }

    const noteParts: string[] = [];
    if (rawSpecText) noteParts.push(`Specialties: ${rawSpecText}`);
    if (qualifications) noteParts.push(`Qualifications: ${qualifications}`);
    if (experience) noteParts.push(`Experience: ${experience}`);
    if (ratingStr) noteParts.push(`Rating: ${ratingStr}/5 ${reviewsStr}`.trim());
    if (feeText) noteParts.push(`Consultation Fee: ${feeText}`);
    if (availability) noteParts.push(`Availability: ${availability}`);
    if (physicalLocations.length > 1) {
      noteParts.push(
        `Other Clinics: ${physicalLocations
          .slice(1, 3)
          .map((l) => l.label)
          .join('; ')}`
      );
    }

    const dedupeKey = buildDoctorDedupeKey({
      fullName,
      speciality,
      clinicName,
      area,
    });

    results.push({
      fullName,
      speciality,
      clinicName,
      practiceType: inferPracticeTypeFromClinic(clinicName),
      doctorStatus,
      pmdcVerified,
      availability,
      experienceYears,
      qualifications,
      consultationFeePkr,
      rating,
      reviewCount,
      patientSatisfaction,
      waitTime,
      videoConsultation,
      phone: null, // oladoc masks individual clinic phones behind centralized 04238900939 helpline; never store aggregator phone as clinic direct phone
      email: null,
      website: null,
      address: cleanAddress,
      area,
      lat,
      lng,
      googleMapsUrl:
        lat !== null && lng !== null
          ? `https://maps.google.com/?q=${encodeURIComponent(`${clinicName} ${area} Lahore`)}`
          : null,
      googlePlaceId: null,
      profileUrl,
      dataSource: 'oladoc.com',
      sourceUrl: profileUrl || pageUrl,
      dataOrigin: 'verified',
      lastVerifiedAt: now,
      dedupeKey,
      notes: noteParts.length > 0 ? noteParts.join(' · ') : null,
    });
  }

  return results;
}
