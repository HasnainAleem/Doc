import test from 'node:test';
import assert from 'node:assert/strict';
import { LAHORE_AREAS, MEDICAL_SPECIALITIES } from '../types/domain';
import {
  OLADOC_AREA_SLUGS,
  OLADOC_SPECIALITY_SLUGS,
  buildOladocListingUrl,
  extractOladocTotalCount,
  parseOladocListingPage,
} from './oladocParser';

test('oladoc slug maps cover all 16 target specialities and 15 Lahore areas', () => {
  for (const spec of MEDICAL_SPECIALITIES) {
    assert.ok(OLADOC_SPECIALITY_SLUGS[spec], `Missing oladoc speciality slug for ${spec}`);
  }
  for (const area of LAHORE_AREAS) {
    assert.ok(OLADOC_AREA_SLUGS[area], `Missing oladoc area slug for ${area}`);
  }

  assert.equal(
    buildOladocListingUrl({ speciality: 'Dermatologists', area: 'Gulberg' }),
    'https://oladoc.com/pakistan/lahore/gulberg/dermatologist'
  );
  assert.equal(
    buildOladocListingUrl({ speciality: 'Pediatricians', area: 'All Lahore', offset: 20 }),
    'https://oladoc.com/pakistan/lahore/child-specialist/20'
  );
});

test('extractOladocTotalCount extracts total Lahore doctors from H1 heading', () => {
  const html = `<html><body><h1>304 Best Dermatologists In Lahore | Top Skin Specialists</h1></body></html>`;
  assert.equal(extractOladocTotalCount(html), 304);
  assert.equal(extractOladocTotalCount('<html><body><h1>No results</h1></body></html>'), 0);
});

test('parseOladocListingPage extracts clinic, area, JSON-LD address, and never fakes direct phone', () => {
  const sampleHtml = `
    <script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "Physician",
        "name": "Dr. Mahru Usman",
        "url": "https://oladoc.com/pakistan/lahore/dr/dermatologist/mahru-usman/2756415",
        "telephone": "04238900939",
        "openingHours": "05:00 PM",
        "priceRange": "PKR 2500",
        "address": {"@type": "PostalAddress", "streetAddress": "42-B Main Boulevard Gulberg III, Lahore"},
        "areaServed": [{"name": "Gulberg, Lahore", "geoMidpoint": {"latitude": 31.5123, "longitude": 74.3456}}]
      }
    </script>
    <div class="card doc-listing-card doctor-card doc-card-1" id="doc-card-01">
      <div class="doctor-card__info">
        <h2 class="doctor-name-heading doctor-card__heading">
          <a class="doctor-name nearme doctor-card__name" href="https://oladoc.com/pakistan/lahore/dr/dermatologist/mahru-usman/2756415">Dr. Mahru Usman</a>
          <span class="doctor-card__verified" title="PMDC Verified"></span>
        </h2>
        <p class="doctor-card__specialization">Dermatologist, Aesthetic Physician</p>
        <p class="doctor-card__degrees">MBBS, MCPS</p>
      </div>
      <ul class="doctor-card__stats">
        <li class="doctor-card__stat">
          <span class="doctor-card__stat-rating"><span class="doctor-card__rating-value">4.9</span><span class="doctor-card__reviews">(85 reviews)</span></span>
        </li>
        <li class="doctor-card__stat">
          <span class="doctor-card__stat-label">Experience</span>
          <span class="doctor-card__stat-value">11 Yrs</span>
        </li>
        <li class="doctor-card__stat">
          <span class="doctor-card__stat-label">Satisfied</span>
          <span class="doctor-card__stat-value">96%</span>
        </li>
        <li class="doctor-card__stat">
          <span class="doctor-card__stat-label">Wait</span>
          <span class="doctor-card__stat-value">Under 15 Min</span>
        </li>
      </ul>
      <div class="doctor-card__locations">
        <a href="https://oladoc.com/appointment/4681/2756415" class="doctor-listing-location-card available-video-hospitalcard">
          <span class="doctor-listing-location-card__name">Online Video Consultation</span>
          <span class="doctor-listing-location-card__fee"><span>Rs. 2,000</span></span>
          <span class="doctor-listing-location-card__availability-text">Available today</span>
        </a>
        <a href="https://oladoc.com/appointment/17738/2756415" class="doctor-listing-location-card">
          <span class="doctor-listing-location-card__name">MU Laser &amp; Dermatology Clinic (Gulberg)</span>
          <span class="doctor-listing-location-card__fee"><span>Rs. 2,500</span></span>
          <span class="doctor-listing-location-card__availability-text">Available tomorrow</span>
        </a>
      </div>
    </div>
    <div class="card doc-listing-card doctor-card doc-card-2" id="doc-card-02">
      <div class="doctor-card__info">
        <h2>
          <a href="https://oladoc.com/pakistan/lahore/dr/dermatologist/adnan-mehmood/15522" class="doctor-card__name">Dr. Adnan Mehmood <!-- verified --></a>
        </h2>
        <p class="doctor-card__specialization">Dermatologist</p>
      </div>
      <div class="doctor-card__locations">
        <a href="https://oladoc.com/appointment/999/15522" class="doctor-listing-location-card">
          <span class="doctor-listing-location-card__name">Evercare Hospital (Nespak Society)</span>
          <span class="doctor-listing-location-card__fee"><span>Rs. 3,500</span></span>
          <span class="doctor-listing-location-card__availability-text">W</span>
        </a>
      </div>
    </div>
  `;

  const parsed = parseOladocListingPage(sampleHtml, 'https://oladoc.com/pakistan/lahore/dermatologist', {
    fallbackSpeciality: 'Dermatologists',
    fallbackArea: 'Gulberg',
  });

  assert.equal(parsed.length, 2);

  assert.equal(parsed[0].fullName, 'Dr. Mahru Usman');
  assert.equal(parsed[0].clinicName, 'MU Laser & Dermatology Clinic');
  assert.equal(parsed[0].area, 'Gulberg');
  assert.equal(parsed[0].practiceType, 'independent');
  assert.equal(parsed[0].doctorStatus, 'PMDC Verified');
  assert.equal(parsed[0].pmdcVerified, true);
  assert.equal(parsed[0].qualifications, 'MBBS, MCPS');
  assert.equal(parsed[0].experienceYears, 11);
  assert.equal(parsed[0].consultationFeePkr, 2500);
  assert.equal(parsed[0].rating, 4.9);
  assert.equal(parsed[0].reviewCount, 85);
  assert.equal(parsed[0].patientSatisfaction, '96%');
  assert.equal(parsed[0].waitTime, 'Under 15 Min');
  assert.equal(parsed[0].videoConsultation, true);
  assert.equal(parsed[0].availability, 'Available tomorrow · 05:00 PM');
  assert.equal(parsed[0].phone, null);
  assert.equal(parsed[0].website, null);
  assert.equal(parsed[0].address, '42-B Main Boulevard Gulberg III, Lahore');
  assert.equal(parsed[0].lat, 31.5123);
  assert.equal(parsed[0].dataSource, 'oladoc.com');
  assert.equal(parsed[0].dataOrigin, 'verified');
  assert.ok(parsed[0].notes?.includes('Rs. 2,500'));
  assert.ok(parsed[0].notes?.includes('11 Yrs'));

  assert.equal(parsed[1].fullName, 'Dr. Adnan Mehmood');
  assert.equal(parsed[1].clinicName, 'Evercare Hospital');
  assert.equal(parsed[1].area, 'Nespak Society');
  assert.equal(parsed[1].practiceType, 'hospital_affiliated');
  assert.equal(parsed[1].doctorStatus, 'Active Practice');
  assert.equal(parsed[1].pmdcVerified, false);
  assert.equal(parsed[1].availability, null);
  assert.equal(parsed[1].consultationFeePkr, 3500);
});
