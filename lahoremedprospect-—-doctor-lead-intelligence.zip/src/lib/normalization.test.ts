import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildDoctorDedupeKey,
  identifyMissingFields,
  inferLahoreArea,
  inferSpeciality,
  normalizePakistanPhone,
  normalizeWebsiteUrl,
} from './normalization';

test('normalizePakistanPhone normalizes mobile and Lahore landline numbers', () => {
  assert.equal(normalizePakistanPhone('0300-1234567'), '+923001234567');
  assert.equal(normalizePakistanPhone('+92 321 9876543'), '+923219876543');
  assert.equal(normalizePakistanPhone('042-35761234'), '+924235761234');
  assert.equal(normalizePakistanPhone('00923331112233'), '+923331112233');
  assert.equal(normalizePakistanPhone(''), null);
  assert.equal(normalizePakistanPhone('N/A'), null);
  assert.equal(normalizePakistanPhone('123'), null);
});

test('normalizeWebsiteUrl cleans domains and preserves null', () => {
  assert.equal(normalizeWebsiteUrl('www.SkinCareLahore.pk/'), 'https://skincarelahore.pk');
  assert.equal(normalizeWebsiteUrl('http://www.clinic.com/doctors/'), 'http://clinic.com/doctors');
  assert.equal(normalizeWebsiteUrl(''), null);
  assert.equal(normalizeWebsiteUrl('N/A'), null);
  assert.equal(normalizeWebsiteUrl('not-a-domain'), null);
});

test('buildDoctorDedupeKey catches formatted variations of the same doctor', () => {
  const keyA = buildDoctorDedupeKey({
    fullName: 'Dr. Ayesha Tariq',
    speciality: 'Dermatologists',
    clinicName: 'Ayesha Skin Clinic',
    area: 'Gulberg',
  });
  const keyB = buildDoctorDedupeKey({
    fullName: 'Ayesha Tariq',
    speciality: 'Dermatologists',
    clinicName: 'Ayesha Skin Medical Center',
    area: 'Gulberg',
  });
  assert.equal(keyA.split('|')[0], keyB.split('|')[0]);
  assert.equal(
    buildDoctorDedupeKey({
      fullName: 'Dr. Bilal',
      speciality: 'Dentists',
      clinicName: 'Smile Care Clinic',
      area: 'DHA',
    }),
    'bilal|dentists|smile care|dha'
  );
});

test('inferLahoreArea and inferSpeciality resolve common variants', () => {
  assert.equal(inferLahoreArea('Street 4, Defence Phase 5, Lahore'), 'DHA');
  assert.equal(inferLahoreArea('Block H2, Johar Town'), 'Johar Town');
  assert.equal(inferSpeciality('Skin & Laser Specialist'), 'Dermatologists');
  assert.equal(inferSpeciality('Heart Care Clinic'), 'Cardiologists');
});

test('identifyMissingFields lists only absent public fields', () => {
  const missing = identifyMissingFields({
    phone: '+923001234567',
    email: null,
    website: null,
    address: 'Main Blvd Gulberg',
    googleMapsUrl: 'https://maps.google.com/?q=1',
  });
  assert.deepEqual(missing, ['Public email', 'Official website']);
});
