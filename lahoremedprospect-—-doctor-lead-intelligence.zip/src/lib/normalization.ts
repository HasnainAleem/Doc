import { LAHORE_AREAS, MEDICAL_SPECIALITIES, type LahoreArea, type MedicalSpeciality } from '../types/domain';

/**
 * Normalizes Pakistani business phone numbers (mobile 03xx, Lahore landline 042)
 * into standardized E.164-like format (+92...). Never fabricates missing numbers.
 */
export function normalizePakistanPhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (!trimmed || trimmed.toLowerCase() === 'null' || trimmed.toLowerCase() === 'n/a') {
    return null;
  }

  // Keep only digits and leading +
  const digitsOnly = trimmed.replace(/[^\d+]/g, '');
  const digits = digitsOnly.replace(/\+/g, '');

  if (digits.length < 7 || digits.length > 15) {
    return null;
  }

  // Already starts with 92 (e.g. 923001234567 or 924235761234)
  if (digits.startsWith('92') && digits.length >= 11 && digits.length <= 12) {
    return `+${digits}`;
  }

  // Starts with 0092
  if (digits.startsWith('0092') && digits.length >= 13 && digits.length <= 14) {
    return `+${digits.slice(2)}`;
  }

  // Local mobile: 03xx-xxxxxxx (11 digits)
  if (digits.startsWith('03') && digits.length === 11) {
    return `+92${digits.slice(1)}`;
  }

  // Local Lahore landline: 042-xxxxxxxx (10 or 11 digits)
  if (digits.startsWith('042') && (digits.length === 10 || digits.length === 11)) {
    return `+92${digits.slice(1)}`;
  }

  // Lahore landline without leading 0 (e.g. 4235761234)
  if (digits.startsWith('42') && (digits.length === 9 || digits.length === 10)) {
    return `+92${digits}`;
  }

  // Local mobile without leading 0 (3001234567)
  if (digits.startsWith('3') && digits.length === 10) {
    return `+92${digits}`;
  }

  // UAN / toll numbers (e.g. 111-xxx-xxx)
  if (digits.startsWith('111') && digits.length === 9) {
    return `+9242${digits}`;
  }

  if (digitsOnly.startsWith('+')) {
    return `+${digits}`;
  }

  return `+92${digits.replace(/^0+/, '')}`;
}

/**
 * Normalizes a clinic/doctor website URL. Preserves null for missing values.
 */
export function normalizeWebsiteUrl(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (
    !trimmed ||
    trimmed.toLowerCase() === 'null' ||
    trimmed.toLowerCase() === 'none' ||
    trimmed.toLowerCase() === 'n/a' ||
    trimmed === '-'
  ) {
    return null;
  }

  let candidate = trimmed;
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = `https://${candidate}`;
  }

  try {
    const parsed = new URL(candidate);
    if (!parsed.hostname || !parsed.hostname.includes('.')) {
      return null;
    }
    const hostname = parsed.hostname.toLowerCase().replace(/^www\./, '');
    const pathname = parsed.pathname === '/' ? '' : parsed.pathname.replace(/\/+$/, '');
    return `${parsed.protocol}//${hostname}${pathname}`;
  } catch {
    return null;
  }
}

export function normalizeTextToken(value: string | null | undefined): string {
  if (!value) return '';
  return value
    .toLowerCase()
    .replace(/\b(dr|prof|professor|assoc|assistant|clinic|hospital|medical|center|centre|pvt|ltd)\b/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

export function inferLahoreArea(text: string | null | undefined): LahoreArea | string {
  if (!text) return 'Gulberg';
  const lower = text.toLowerCase();
  for (const area of LAHORE_AREAS) {
    if (lower.includes(area.toLowerCase())) {
      return area;
    }
  }
  if (lower.includes('defence') || lower.includes('dha phase')) return 'DHA';
  if (lower.includes('cantonment') || lower.includes('saddar')) return 'Cantt';
  if (lower.includes('iqbal town')) return 'Allama Iqbal Town';
  return text.trim() || 'Gulberg';
}

export function inferSpeciality(text: string | null | undefined): MedicalSpeciality | string {
  if (!text) return 'General physicians';
  const lower = text.toLowerCase();
  for (const spec of MEDICAL_SPECIALITIES) {
    const singular = spec.toLowerCase().replace(/s$/, '');
    if (lower.includes(spec.toLowerCase()) || lower.includes(singular)) {
      return spec;
    }
  }
  if (lower.includes('skin') || lower.includes('derma')) return 'Dermatologists';
  if (lower.includes('heart') || lower.includes('cardio')) return 'Cardiologists';
  if (lower.includes('dental') || lower.includes('tooth') || lower.includes('orthodont')) return 'Dentists';
  if (lower.includes('gynae') || lower.includes('obstet')) return 'Gynecologists';
  if (lower.includes('neuro')) return 'Neurologists';
  if (lower.includes('ortho') || lower.includes('bone')) return 'Orthopedic surgeons';
  if (lower.includes('child') || lower.includes('paed') || lower.includes('pediat')) return 'Pediatricians';
  if (lower.includes('psych')) return 'Psychiatrists';
  if (lower.includes('plastic') || lower.includes('cosmetic surgery')) return 'Plastic surgeons';
  if (lower.includes('physio') || lower.includes('rehab')) return 'Physiotherapists';
  if (lower.includes('eye') || lower.includes('ophthalm')) return 'Ophthalmologists';
  if (lower.includes('ent') || lower.includes('ear nose')) return 'ENT specialists';
  if (lower.includes('uro')) return 'Urologists';
  if (lower.includes('gastro') || lower.includes('liver')) return 'Gastroenterologists';
  if (lower.includes('aesthetic') || lower.includes('laser')) return 'Aesthetic physicians';
  return text.trim();
}

/**
 * Generates deterministic deduplication key from normalized
 * name + speciality + clinic + location.
 */
export function buildDoctorDedupeKey(input: {
  fullName: string;
  speciality: string;
  clinicName: string;
  area: string;
}): string {
  const parts = [
    normalizeTextToken(input.fullName),
    normalizeTextToken(input.speciality),
    normalizeTextToken(input.clinicName),
    normalizeTextToken(input.area),
  ];
  return parts.join('|');
}

export function buildClinicNormalizedName(name: string, area: string): string {
  return `${normalizeTextToken(name)}|${normalizeTextToken(area)}`;
}

export function identifyMissingFields(record: {
  phone?: string | null;
  email?: string | null;
  website?: string | null;
  address?: string | null;
  googleMapsUrl?: string | null;
}): string[] {
  const missing: string[] = [];
  if (!record.phone) missing.push('Public phone');
  if (!record.email) missing.push('Public email');
  if (!record.website) missing.push('Official website');
  if (!record.address) missing.push('Business address');
  if (!record.googleMapsUrl) missing.push('Google Maps link');
  return missing;
}
