export type ThemeMode = 'light' | 'dark';

export const THEME_STORAGE_KEY = 'lahoremed_theme';

export function resolveInitialTheme(
  stored: string | null | undefined,
  prefersDark: boolean
): ThemeMode {
  if (stored === 'dark' || stored === 'light') {
    return stored;
  }
  return prefersDark ? 'dark' : 'light';
}

export function getNextTheme(current: ThemeMode): ThemeMode {
  return current === 'dark' ? 'light' : 'dark';
}

export function applyThemeToElement(theme: ThemeMode, root: HTMLElement | null): void {
  if (!root) return;
  if (theme === 'dark') {
    root.classList.add('dark');
    root.style.colorScheme = 'dark';
  } else {
    root.classList.remove('dark');
    root.style.colorScheme = 'light';
  }
}
