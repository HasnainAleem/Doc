import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeWebsiteHtml, isSafePublicHttpUrl } from './audit';

test('isSafePublicHttpUrl blocks private and loopback addresses (SSRF defense)', () => {
  assert.equal(isSafePublicHttpUrl('http://localhost:3000'), false);
  assert.equal(isSafePublicHttpUrl('http://127.0.0.1/admin'), false);
  assert.equal(isSafePublicHttpUrl('http://169.254.169.254/latest'), false);
  assert.equal(isSafePublicHttpUrl('https://clinic.pk'), true);
});

test('analyzeWebsiteHtml classifies modern clinic sites with booking and SEO as professional', () => {
  const html = `
    <html>
      <head>
        <title>Lahore Heart & Skin Clinic - Dr. Sara Khan</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="Specialized cardiology and dermatology consultations in Gulberg Lahore." />
      </head>
      <body class="flex grid">
        <h1>Dr. Sara Khan MBBS FCPS</h1>
        <a href="https://wa.me/923001234567">Book Appointment</a>
      </body>
    </html>
  `;
  const result = analyzeWebsiteHtml({
    url: 'https://sarakhanclinic.pk',
    httpStatus: 200,
    loadTimeMs: 420,
    sslValid: true,
    html,
  });
  assert.equal(result.classification, 'Professionally developed website');
  assert.equal(result.hasAppointmentBooking, true);
  assert.equal(result.hasDoctorProfile, true);
  assert.equal(result.hasSeoFundamentals, true);
  assert.equal(result.mobileResponsive, true);
});

test('analyzeWebsiteHtml classifies missing viewport as Poor mobile responsiveness', () => {
  const html = `
    <html>
      <head><title>Clinic Lahore</title></head>
      <body><h1>Welcome</h1><p>Dr. Ali MBBS</p><a href="#book">Book Appointment</a></body>
    </html>
  `;
  const result = analyzeWebsiteHtml({
    url: 'https://clinic.pk',
    httpStatus: 200,
    loadTimeMs: 500,
    sslValid: true,
    html,
  });
  assert.equal(result.classification, 'Poor mobile responsiveness');
  assert.equal(result.mobileResponsive, false);
});

test('analyzeWebsiteHtml classifies unreachable sites as Website unavailable', () => {
  const result = analyzeWebsiteHtml({
    url: 'https://downclinic.pk',
    httpStatus: null,
    loadTimeMs: null,
    sslValid: false,
    html: null,
    fetchError: 'ENOTFOUND',
  });
  assert.equal(result.classification, 'Website unavailable');
  assert.ok(result.improvementOpportunities.length > 0);
});
