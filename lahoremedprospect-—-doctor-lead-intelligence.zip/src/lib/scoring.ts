import {
  DEFAULT_SCORING_RULES,
  type LeadPriority,
  type PracticeType,
  type ScoringRulesConfig,
  type WebsiteAuditReport,
  type WebsiteClassification,
} from '../types/domain';

export interface ScoreBreakdownItem {
  criterion: string;
  points: number;
  applied: boolean;
  reason: string;
}

export interface LeadScoreResult {
  score: number;
  priority: LeadPriority;
  breakdown: ScoreBreakdownItem[];
}

export function calculateLeadScore(
  input: {
    website: string | null;
    websiteClassification: WebsiteClassification;
    practiceType: PracticeType;
    phone: string | null;
    email: string | null;
    latestAudit?: Partial<WebsiteAuditReport> | null;
  },
  rules: ScoringRulesConfig = DEFAULT_SCORING_RULES
): LeadScoreResult {
  const breakdown: ScoreBreakdownItem[] = [];

  const hasNoWebsite =
    !input.website || input.websiteClassification === 'No website found';

  const isOutdatedOrBroken =
    !hasNoWebsite &&
    (input.websiteClassification === 'Outdated website' ||
      input.websiteClassification === 'Website unavailable' ||
      input.websiteClassification === 'Missing SEO fundamentals');

  const missingAppointment =
    hasNoWebsite ||
    input.websiteClassification === 'Missing appointment functionality' ||
    input.latestAudit?.hasAppointmentBooking === false;

  const poorMobile =
    hasNoWebsite ||
    input.websiteClassification === 'Poor mobile responsiveness' ||
    input.latestAudit?.mobileResponsive === false;

  const isIndependent = input.practiceType === 'independent';
  const hasPublicContact = Boolean(input.phone || input.email);

  breakdown.push({
    criterion: 'No official website',
    points: hasNoWebsite ? rules.noWebsiteWeight : 0,
    applied: hasNoWebsite,
    reason: hasNoWebsite
      ? 'No official clinic website detected'
      : 'Clinic has a listed website URL',
  });

  breakdown.push({
    criterion: 'Outdated or underperforming website',
    points: isOutdatedOrBroken ? rules.outdatedWebsiteWeight : 0,
    applied: isOutdatedOrBroken,
    reason: isOutdatedOrBroken
      ? `Classified as ${input.websiteClassification}`
      : 'Website is not flagged as outdated or unavailable',
  });

  breakdown.push({
    criterion: 'Missing appointment functionality',
    points: missingAppointment ? rules.missingAppointmentWeight : 0,
    applied: missingAppointment,
    reason: hasNoWebsite
      ? 'No website present for online appointment scheduling'
      : missingAppointment
      ? 'No online booking or appointment request flow found'
      : 'Appointment booking signals present or unchecked',
  });

  breakdown.push({
    criterion: 'Poor mobile experience',
    points: poorMobile ? rules.poorMobileWeight : 0,
    applied: poorMobile,
    reason: hasNoWebsite
      ? 'No mobile-accessible clinic website available'
      : poorMobile
      ? 'Missing mobile viewport or responsive layout markers'
      : 'Mobile viewport signals present or unchecked',
  });

  breakdown.push({
    criterion: 'Independent private practice',
    points: isIndependent ? rules.independentPracticeWeight : 0,
    applied: isIndependent,
    reason: isIndependent
      ? 'Independent clinic decision-maker structure'
      : 'Multi-doctor clinic group or hospital-affiliated practice',
  });

  breakdown.push({
    criterion: 'Public business contact available',
    points: hasPublicContact ? rules.publicContactWeight : 0,
    applied: hasPublicContact,
    reason: hasPublicContact
      ? 'Public phone or business email available for outreach'
      : 'No public phone or email currently verified',
  });

  const rawScore = breakdown.reduce((sum, item) => sum + item.points, 0);
  const score = Math.max(0, Math.min(100, rawScore));

  let priority: LeadPriority = 'Low';
  if (score >= rules.highPriorityThreshold) {
    priority = 'High';
  } else if (score >= rules.mediumPriorityThreshold) {
    priority = 'Medium';
  }

  return { score, priority, breakdown };
}
