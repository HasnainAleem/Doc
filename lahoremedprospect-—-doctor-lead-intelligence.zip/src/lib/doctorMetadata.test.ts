import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractMetadataFromNotes,
  formatExperienceLabel,
  hydrateDoctorRecord,
  isAvailableTodayOrSoon,
  parseExperienceYears,
  parseFeePkr,
} from './doctorMetadata';
import type { DoctorRecord } from '../types/domain';

test('parseExperienceYears parses numeric and text formats safely', () => {
  assert.equal(parseExperienceYears('15 Yrs'), 15);
  assert.equal(parseExperienceYears('11 years'), 11);
  assert.equal(parseExperienceYears('8+ yrs exp'), 8);
  assert.equal(parseExperienceYears(20), 20);
  assert.equal(parseExperienceYears('invalid'), null);
  assert.equal(parseExperienceYears(null), null);
});

test('parseFeePkr parses PKR and Rs formats', () => {
  assert.equal(parseFeePkr('Rs. 2,500'), 2500);
  assert.equal(parseFeePkr('PKR 3000'), 3000);
  assert.equal(parseFeePkr(1500), 1500);
  assert.equal(parseFeePkr('Free'), null);
  assert.equal(parseFeePkr(null), null);
});

test('formatExperienceLabel returns readable singular/plural/null strings', () => {
  assert.equal(formatExperienceLabel(1), '1 yr exp');
  assert.equal(formatExperienceLabel(14), '14 yrs exp');
  assert.equal(formatExperienceLabel(null), 'Not listed');
});

test('extractMetadataFromNotes extracts structured fields from oladoc note strings', () => {
  const notes =
    'Specialties: Dermatologist · Qualifications: MBBS, FCPS · Experience: 14 Yrs · Rating: 4.9/5 (85 reviews) · Consultation Fee: Rs. 3,000';
  const meta = extractMetadataFromNotes(notes);
  assert.equal(meta.qualifications, 'MBBS, FCPS');
  assert.equal(meta.experienceYears, 14);
  assert.equal(meta.rating, 4.9);
  assert.equal(meta.reviewCount, 85);
  assert.equal(meta.consultationFeePkr, 3000);
});

test('hydrateDoctorRecord populates defaults and recovers metadata from legacy cached records', () => {
  const legacyDoc = {
    id: 1,
    fullName: 'Dr. Test Legacy',
    speciality: 'Dermatologists',
    clinicId: null,
    clinicName: 'Gulberg Skin Care',
    practiceType: 'independent',
    phone: null,
    email: null,
    website: null,
    address: null,
    area: 'Gulberg',
    lat: 31.51,
    lng: 74.34,
    googleMapsUrl: null,
    googlePlaceId: null,
    profileUrl: null,
    socialLinks: {},
    dataSource: 'oladoc.com',
    sourceUrl: null,
    dataOrigin: 'verified',
    lastVerifiedAt: null,
    websiteClassification: 'No website found',
    leadScore: 70,
    leadPriority: 'Medium',
    leadStatus: 'New',
    opportunityValuePkr: null,
    nextFollowUpAt: null,
    notes: 'Qualifications: MBBS, MCPS · Experience: 9 Yrs · Rating: 4.8/5 (40 reviews) · Consultation Fee: Rs. 2,500',
    dedupeKey: 'test-key',
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  } as unknown as DoctorRecord;

  const hydrated = hydrateDoctorRecord(legacyDoc);
  assert.equal(hydrated.doctorStatus, 'Active Practice');
  assert.equal(hydrated.pmdcVerified, false);
  assert.equal(hydrated.experienceYears, 9);
  assert.equal(hydrated.qualifications, 'MBBS, MCPS');
  assert.equal(hydrated.rating, 4.8);
  assert.equal(hydrated.reviewCount, 40);
  assert.equal(hydrated.consultationFeePkr, 2500);
  assert.equal(hydrated.videoConsultation, false);
});

test('isAvailableTodayOrSoon detects valid schedules', () => {
  assert.equal(isAvailableTodayOrSoon('Available tomorrow · 05:00 PM'), true);
  assert.equal(isAvailableTodayOrSoon('Mon–Sat 4:00 PM – 8:00 PM'), true);
  assert.equal(isAvailableTodayOrSoon(null), false);
});
