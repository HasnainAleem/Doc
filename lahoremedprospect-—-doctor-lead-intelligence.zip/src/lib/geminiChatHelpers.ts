export type ChatbotRoleId = 'outreach_strategist' | 'website_analyst' | 'crm_advisor';

export interface ChatbotRoleConfig {
  id: ChatbotRoleId;
  label: string;
  shortLabel: string;
  description: string;
  systemInstruction: string;
  starterPrompts: string[];
}

export interface ChatTurn {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export interface GeminiHistoryEntry {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
}

export const CHATBOT_ROLES: ChatbotRoleConfig[] = [
  {
    id: 'outreach_strategist',
    label: 'Outreach Strategist',
    shortLabel: 'Outreach',
    description: 'Drafts personalized Lahore clinic outreach emails, WhatsApp follow-ups, and objection replies.',
    systemInstruction:
      'You are an Outreach Strategist for LahoreMedProspect, helping digital agency admins craft respectful, concise, high-converting email and WhatsApp outreach for doctors and private clinics in Lahore, Pakistan. Tailor pitches to medical specialities (dermatology, dentistry, cardiology, etc.) and local Lahore zones (Gulberg, DHA, Johar Town, Model Town). Never invent doctor contact info (phone/email/URLs). Keep suggestions practical and ready to copy.',
    starterPrompts: [
      'Rewrite a short cold email for a dermatologist in Gulberg with no website',
      'Give me 3 polite WhatsApp follow-ups after sending a PKR 150,000 proposal',
      'How do I respond if a clinic says they already get patients on Oladoc/Marham?',
    ],
  },
  {
    id: 'website_analyst',
    label: 'Website Audit Analyst',
    shortLabel: 'Web Audit',
    description: 'Translates technical audit gaps (SSL, mobile speed, booking, SEO) into clinic-friendly pitches.',
    systemInstruction:
      'You are a Website Audit Analyst for LahoreMedProspect. Help the admin explain technical clinic website audit findings (HTTP errors, missing HTTPS/SSL, poor mobile viewport responsiveness, slow load times, missing appointment booking CTAs, and missing local SEO schema/titles) in clear, non-jargon language focused on patient trust and OPD bookings in Lahore. Never claim an audit check ran unless provided in context.',
    starterPrompts: [
      'Explain why missing HTTPS and mobile viewport hurts a DHA dental clinic',
      'What should an online appointment booking page include for a busy Lahore clinic?',
      'Turn "Outdated website + No SEO" into a 3-bullet value pitch for a cardiologist',
    ],
  },
  {
    id: 'crm_advisor',
    label: 'CRM Pipeline Advisor',
    shortLabel: 'CRM Advisor',
    description: 'Guides follow-up timing, lead prioritization, and PKR package scoping across CRM stages.',
    systemInstruction:
      'You are a CRM Pipeline Advisor for LahoreMedProspect. Help prioritize outreach across the 10 CRM lead statuses (New, Researching, Contacted, Follow-up required, Interested, Meeting scheduled, Proposal sent, Negotiating, Converted, Not interested). Remind the admin when relevant that lead scores (0-100) measure technical digital gaps rather than a doctor’s willingness to buy. Suggest realistic next actions, follow-up cadences, and phased PKR package options.',
    starterPrompts: [
      'Suggest a 14-day follow-up cadence for "Follow-up required" high-priority leads',
      'How should I structure a phased PKR website + SEO package while Negotiating?',
      'What checklist should we send right after a clinic moves to Converted?',
    ],
  },
];

export function getChatbotRole(roleId: ChatbotRoleId): ChatbotRoleConfig {
  return CHATBOT_ROLES.find((r) => r.id === roleId) || CHATBOT_ROLES[0];
}

export function toGeminiHistory(
  turns: Array<Pick<ChatTurn, 'role' | 'text'>>
): GeminiHistoryEntry[] {
  const sanitized: GeminiHistoryEntry[] = [];
  for (const turn of turns) {
    const trimmed = (turn.text || '').trim();
    if (!trimmed) continue;
    const role = turn.role === 'model' ? 'model' : 'user';
    // Merge consecutive messages with the same role if needed so history stays strictly valid
    const prev = sanitized[sanitized.length - 1];
    if (prev && prev.role === role) {
      prev.parts.push({ text: trimmed });
    } else {
      sanitized.push({ role, parts: [{ text: trimmed }] });
    }
  }
  // Gemini chat history should start with a user turn when non-empty
  while (sanitized.length > 0 && sanitized[0].role !== 'user') {
    sanitized.shift();
  }
  return sanitized;
}

export function formatDoctorContextForChat(doctor: {
  fullName: string;
  speciality: string;
  clinicName: string;
  area: string;
  leadStatus: string;
  leadScore: number;
  leadPriority: string;
  website: string | null;
  websiteClassification: string;
  opportunityValuePkr: number | null;
}): string {
  const valueText =
    doctor.opportunityValuePkr !== null
      ? `PKR ${doctor.opportunityValuePkr.toLocaleString()}`
      : 'Not set';
  return [
    `Active Lead Context:`,
    `- Doctor: ${doctor.fullName} (${doctor.speciality})`,
    `- Clinic: ${doctor.clinicName} in ${doctor.area}, Lahore`,
    `- CRM Status: ${doctor.leadStatus} | Gap Score: ${doctor.leadScore}/100 (${doctor.leadPriority}) | Est. Deal: ${valueText}`,
    `- Website: ${doctor.website || 'None'} (${doctor.websiteClassification})`,
  ].join('\n');
}
