import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyBulkPatchToDoctors,
  toggleIdSelection,
  toggleSelectAllVisible,
} from './bulkActions';
import { buildSampleDataset } from './sampleData';

test('toggleIdSelection adds and removes IDs cleanly', () => {
  assert.deepEqual(toggleIdSelection([], 5), [5]);
  assert.deepEqual(toggleIdSelection([5, 8], 5), [8]);
  assert.deepEqual(toggleIdSelection([8], 12), [8, 12]);
});

test('toggleSelectAllVisible selects or deselects only the currently visible IDs', () => {
  const initial = [99];
  const selected = toggleSelectAllVisible(initial, [1, 2, 3]);
  assert.deepEqual(selected, [99, 1, 2, 3]);

  const deselected = toggleSelectAllVisible(selected, [1, 2, 3]);
  assert.deepEqual(deselected, [99]);
});

test('applyBulkPatchToDoctors updates status and priority for targeted records and logs activities', () => {
  const { doctors } = buildSampleDataset();
  const targetIds = [doctors[0].id, doctors[1].id];
  const untouchedId = doctors[2].id;

  const updated = applyBulkPatchToDoctors(
    doctors,
    targetIds,
    { leadStatus: 'Proposal sent', leadPriority: 'Medium' },
    'admin@clinic.pk',
    '2026-11-17T10:00:00.000Z'
  );

  assert.equal(updated[0].leadStatus, 'Proposal sent');
  assert.equal(updated[0].leadPriority, 'Medium');
  assert.equal(updated[1].leadStatus, 'Proposal sent');
  assert.equal(updated[1].leadPriority, 'Medium');
  assert.equal(updated[2].id, untouchedId);
  assert.equal(updated[2].leadStatus, doctors[2].leadStatus);
  assert.ok((updated[0].activities || []).some((a) => a.summary.includes('Proposal sent')));
});
